'use strict';
const Controller = require('egg').Controller;

class bank_account extends Controller {

    async bank_account() {

        await this.service.bankAccount.bank_account();

    }
    async man_account() {

        await this.service.bankAccount.man_account();

    }
    async man_modify_status() {

        await this.service.bankAccount.man_modify_status();

    }
    async man_modify() {

        await this.service.bankAccount.man_modify();

    }
    async bank_account_list() {
        this.ctx.body = await this.service.bankAccount.readBankAccount(this.ctx.query);
    }
}
module.exports = bank_account;
