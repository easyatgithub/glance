'use strict';
const fs = require('fs');
const Controller = require('egg').Controller;
const moment = require('moment');
class bank_sms extends Controller {

    async bank_sms() {

        const body = this.ctx.request.rawBody.replace(/(\r\n)/ig, '');
        const obj = JSON.parse(body);
        const str = obj.msg;
        const regs = [
            // 中国农业银行
            /【中国农业银行】([0-9a-zA-Z\u4e00-\u9fa5]+)于(\d{2})月(\d{2})日([\d:]{5})向您尾号(\d{4})账户完成网银转账交易人民币([\d.,]+)，余额([\d.,]+)/,
            /【中国农业银行】([0-9a-zA-Z\u4e00-\u9fa5]+)于(\d{2})月(\d{2})日([\d:]{5})向您尾号(\d{4})账户完成转存交易人民币([\d.,]+)，余额([\d.,]+)/,
            /【中国农业银行】您尾号(\d{4})账户(\d{2})月(\d{2})日([\d:]{5})完成(.*)交易人民币([\d.,]+)，余额([\d.,]+)/,
            // 招商银行
            /您账户(\d{4})于(\d{2})月(\d{2})日([\d:]{5})入账款项，人民币([\d.,]+)。(.*)/,
            /您账户(\d{4})于(\d{2})月(\d{2})日([\d:]{5})支付宝入账人民币([\d.,]+)(.*)/,
            /您账户(\d{4})于([\d]+)月([\d]+)日收到本行转入人民币([\d.,]+)，付方([0-9a-zA-Z\u4e00-\u9fa5]+)，账号尾号(\d{4})，备注：转账\[招商银行\]/,
            /您账户(\d{4})于(\d{2})月(\d{2})日他行实时转入人民币([\d.,]+)，付方([0-9a-zA-Z\u4e00-\u9fa5]+)。(.*)/,
            // 建设银行
            /([0-9a-zA-Z\u4e00-\u9fa5]+)([\d]+)月([\d]+)日([\d]+)时([\d]+)分向您尾号(\d{4})的储蓄卡账户(.*)收入人民币([\d.,]+)元,活期余额([\d.,]+)元。(.*)/,
            /您尾号(\d{4})的储蓄卡账户([\d]+)月([\d]+)日([\d]+)时([\d]+)分([\d]+)秒转账存入收入人民币([\d.,]+)元,活期余额([\d.,]+)元。(.*)/,
            // 工商银行
            /您尾号(\d{4})卡([\d]+)月([\d]+)日([\d:]{5})网上银行收入\(([0-9a-zA-Z\u4e00-\u9fa5]+)支付宝转账\)([\d.,]+)元，余额([\d.,]+)元。【工商银行】/,
            /您尾号(\d{4})卡([\d]+)月([\d]+)日([\d:]{5})(.*)收入(\(.*\))([\d.,]+)元，余额([\d.,]+)元。【工商银行】/,
            // 江西银行
            /【江西银行】您尾数(\d{4})的卡(\d{2})月(\d{2})日([\d:]{5})其他交易转入([\d.,]+)元，余额([\d.,]+)元。客服(.*)/,
        ];

        let varArr = [ 0, false ];
        for (let i = 0; i < regs.length; i++) {
            if (str !== str.replace(regs[i], '$1,$2,$3,$4,$5,$6,$7,$8,$9')) { varArr = [ i, true ]; break; }
        }
        const kind = varArr[0]; // 将用于 情况判断  推送类或者不推送类 不推送的都是负数
        const flag = varArr[1]; // 将用于匹配情况
        const newBankMsg = {
            id: '',
            create_at: obj.time,
            phone_from: obj.phone, // 从这个里面截断 13位手机号码里发来的数据就可判定为测试短信或者冒充短信
            phone_to: obj.phonum,
            bank_msg: str,
            msg_time: obj.time,
        };
        /*
    为简写约定代码  6个值  注意大金额
    val 数组  依次值  银行  人 尾号   金额   余额    时间   0值给 "0"
    */
        let val = [];
        if (flag) {
            const times = [ new Date().getFullYear() + '-' + RegExp.$2 + '-' + RegExp.$3 + ' ' + RegExp.$4 + ':00',
                new Date().getFullYear() + '-' + RegExp.$2 + '-' + RegExp.$3 + ' ' + RegExp.$4 + ':' + RegExp.$5 + ':00',
                new Date().getFullYear() + '-' + RegExp.$2 + '-' + RegExp.$3 + ' ' + RegExp.$4 + ':' + RegExp.$5 + ':' + RegExp.$6,
            ];
            switch (kind) {
            case 0:
            case 1: val = [ '农业银行', RegExp.$1, RegExp.$5, RegExp.$6, RegExp.$7, times[0] ]; break;
            case 2: val = [ '农业银行', '--', RegExp.$1, RegExp.$6, RegExp.$7, times[0] ]; break;

            case 3:
            case 4: val = [ '招商银行', '--', RegExp.$1, RegExp.$5, '0', times[0] ]; break;
            case 5:
            case 6: val = [ '招商银行', RegExp.$5, RegExp.$1, RegExp.$3, '0', new Date().getFullYear() + '-' + RegExp.$2 + '-' + RegExp.$3 + ' 00:00:00' ]; break;

            case 7: val = [ '建设银行', RegExp.$1, RegExp.$6, RegExp.$8, RegExp.$9, times[1] ]; break;
            case 8: val = [ '建设银行', '--', RegExp.$1, RegExp.$7, RegExp.$8, times[2] ]; break;

            case 9: val = [ '工商银行', RegExp.$5, RegExp.$1, RegExp.$6, RegExp.$7, times[0] ]; break;
            case 10: val = [ '工商银行', '--', RegExp.$1, RegExp.$7, RegExp.$8, times[0] ]; break;

            case 11: val = [ '江西银行', '--', RegExp.$1, RegExp.$5, RegExp.$6, times[0] ]; break;
            default: console.log(0);
            }
            newBankMsg.bank = val[0];
            newBankMsg.payee = val[1];
            newBankMsg.payee_tail = val[2];
            newBankMsg.amount = isNaN(parseFloat(val[3].replace(/,/g, ''))) ? 0 : parseFloat(val[3].replace(/,/g, ''));
            newBankMsg.balance = isNaN(parseFloat(val[4].replace(/,/g, ''))) ? 0 : parseFloat(val[4].replace(/,/g, ''));
            newBankMsg.payee_time = val[5];
            const diff_time = moment(obj.time).valueOf() - moment(val[5]).valueOf();
            newBankMsg.diff_time = diff_time > 0 ? diff_time : -diff_time;

            await this.service.bankSms.createBankMsg(newBankMsg);

        } else {
            const tmp = [ isNaN(parseFloat(RegExp.$5)) ? 0 : parseFloat(RegExp.$5), isNaN(parseFloat(RegExp.$6)) ? 0 : parseFloat(RegExp.$6) ];
            const newBankMsg = {
                id: '',
                create_at: obj.time,
                phone_from: obj.phone,
                phone_to: obj.phonum,
                bank_msg: str,
                bank: ' - -  ',
                payee: ' - -  ',
                payee_time: '2018-08-08 00:00:00',
                diff_time: 0,
                payee_tail: ' - -  ',
                amount: tmp[0],
                balance: tmp[1],
                msg_time: obj.time,
                push_status: '不推送',
            };
            await this.service.bankSms.otherMsg(newBankMsg);
        }
        this.ctx.body = 'OK';

    }

    async bank_sms_list() {

        this.ctx.body = await this.service.bankSms.readBankMsg(this.ctx.query);
    // this.ctx.body = 1
    }
    async bank_auto_value() {
        this.ctx.body = await this.service.bankSms.readAutoValue();
    }
    async sms_man_push() {
        this.ctx.body = await this.service.bankSms.sms_man_push();
    }
    async summary() {
        this.ctx.body = await this.service.bankSms.summary();
    }
    async summary_bymonth() {
        this.ctx.body = await this.service.bankSms.summary_bymonth();
    }


    async excle() {
        this.ctx.body = await this.service.bankSms.excle(this.ctx.query);
    }
    async excle_file() {
        const file = this.ctx.session.file;
        this.ctx.attachment(file);
        this.ctx.set('Content-Type', 'application/octet-stream');
        const tmp = fs.createReadStream(file);
        tmp.on('end', function() {
            fs.unlinkSync(file, function() {
            });
        });
        this.ctx.body = tmp;

    }
} // class-end

module.exports = bank_sms;
