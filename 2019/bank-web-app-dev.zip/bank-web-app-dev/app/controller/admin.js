'use strict';
const Controller = require('egg').Controller;
const captchapng = require('captchapng');
class admin extends Controller {


    async login() {

        this.ctx.body = await this.service.admin.login(this.ctx.query);
    }
    async session() {
        this.ctx.body = await this.service.admin.session();
    }
    async sign_out() {
        this.ctx.body = await this.service.admin.sign_out(this.ctx.query);
    }
    async code_png() {

        this.ctx.set({ 'Content-Type': 'image/png' });
        const system_code = parseInt(Math.random() * 9000 + 1000);
        const p = new captchapng(80, 30, system_code); // width,height,numeric captcha
        p.color(0, 0, 0, 0); // First color: background (red, green, blue, alpha)
        p.color(80, 80, 80, 255); // Second color: paint (red, green, blue, alpha)
        this.ctx.session.system_code = system_code;
        const img = p.getBase64();
        const imgbase64 = new Buffer(img, 'base64');
        this.ctx.body = imgbase64;
    }

    async modify_pwd() {
        this.ctx.body = await this.service.admin.modify_pwd(this.ctx.query);
    }
    async admin() {
        this.ctx.body = await this.service.admin.admin();
    }
    async admin_list() {
        this.ctx.body = await this.service.admin.admin_list();
    }
    async modify_admin() {
        this.ctx.body = await this.service.admin.modify_admin();
    }

    async roles_list() {
        this.ctx.body = await this.service.admin.roles_list();
    }
    async permissions_list() {
        this.ctx.body = await this.service.admin.permissions_list();
    }
    async modify_admin_roles() {
        this.ctx.body = await this.service.admin.modify_admin_roles();
    }
    async modify_roles_permission() {
        this.ctx.body = await this.service.admin.modify_roles_permission();
    }
    async admin_detail() {
        this.ctx.body = await this.service.admin.admin_detail();
    }
    async role_detail() {
        this.ctx.body = await this.service.admin.role_detail();
    }
    async roles() {
        this.ctx.body = await this.service.admin.roles();
    }
    async del_permission() {
        this.ctx.body = await this.service.admin.del_permission();
    }
    async permissions() {
        this.ctx.body = await this.service.admin.permissions();
    }
    async xxx() {
        this.ctx.body = await this.service.admin.permissions();
    }

}
module.exports = admin;
