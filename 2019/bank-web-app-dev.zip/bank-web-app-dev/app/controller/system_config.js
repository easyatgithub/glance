'use strict';

const Controller = require('egg').Controller;
class system_config extends Controller {

    async bank() {

        this.ctx.body = await this.service.systemConfig.bank();
    }
    async brand() {

        this.ctx.body = await this.service.systemConfig.brand();
    }
    async sms_config() {

        this.ctx.body = await this.service.systemConfig.sms_config();
    }
    async record() {

        this.ctx.body = await this.service.systemConfig.record();
    }
    async recordList() {

        this.ctx.body = await this.service.systemConfig.recordList();
    }
    async summaryList() {

        this.ctx.body = await this.service.systemConfig.summaryList();
    }

}

module.exports = system_config;
