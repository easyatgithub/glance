'use strict';

const Controller = require('egg').Controller;
class task extends Controller {
    async record() {

        this.ctx.body = await this.service.task.record();
    }
    async recordList() {

        this.ctx.body = await this.service.task.recordList();
    }
    async summaryList() {

        this.ctx.body = await this.service.task.summaryList();
    }
    async upload() {

        this.ctx.body = await this.service.task.upload();
    }

}

module.exports = task;
