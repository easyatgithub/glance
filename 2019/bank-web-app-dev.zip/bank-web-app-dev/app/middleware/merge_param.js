'use strict';

async function mergeParams(ctx, next) {
    ctx.reqParams = Object.assign({}, ctx.query, ctx.request.body, ctx.params);
    await next();
}

module.exports = () => {
    return mergeParams;
};
