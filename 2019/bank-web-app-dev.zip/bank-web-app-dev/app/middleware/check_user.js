'use strict';
module.exports = () => {
    return async (ctx, next) => {
        if (!ctx.currentUser) {
            ctx.status = 401;
            ctx.body = {
                status: false,
                message: 'login required',
            };
            return;
        }
        await next();
    };
}
;
