'use strict';
module.exports = () => {
    return async (ctx, next) => {
        const path = ctx.request.url;
        if (path.indexOf('/payment') > -1 || path.indexOf('/api/bank_sms') > -1 || path.indexOf('/admin/code_png') > -1 || path.indexOf('/login') > -1 || path.indexOf('/api/bank_account') > -1) {
            console.log('ok');
        } else {
            if (!ctx.session.user) {
                ctx.status = 403;
                ctx.body = { message: '请先登陆' };
                return;
            }
        }

        await next();
    };
}
;

