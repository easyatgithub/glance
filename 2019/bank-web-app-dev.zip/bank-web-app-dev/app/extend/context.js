'use strict';

module.exports = {
    copyProxyStatus(proxyRes) {
        this.response.status = proxyRes.statusCode;
        const headers = Object.assign({}, proxyRes.headers);
        delete headers['transfer-encoding'];
        this.response.set(headers);
    },
    copyProxy(proxyRes) {
        this.body = proxyRes.payload;
        this.copyProxyStatus(proxyRes);
    },
    get wpsBaseUrl() {
        return this.app.getWpsBaseUrl(this.hostname);
    },
    getProxyHeaders() {
        const headers = Object.assign(this.headers);
        delete headers['content-length'];
        delete headers['accept-encoding'];
        return headers;
    },
};
