'use strict';
const path = require('path');
module.exports = {
    requireModule(modulePath) {
        const filePath = path.join(this.baseDir, modulePath);
        return require(filePath);
    },
};
