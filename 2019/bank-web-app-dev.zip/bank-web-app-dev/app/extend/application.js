'use strict';
const path = require('path');
const PROXY = Symbol('Appplication#tcgProxy');
const LGW_REQUEST = Symbol('Application#lgwRequest');
const crypto = require('crypto');
// console.log('enter app extend');
const [ WPS20, WPS21, WPS22, WPS23, WPS24, WPS25 ] = [ 'WPS20', 'WPS21', 'WPS22', 'WPS23', 'WPS24', 'WPS25' ];
const WPS_MAPPING = {
    'www.xgllvip1.com': WPS20,
    'www.jsaoidy.com': WPS20,
    'www.xgllniu.com': WPS20,
    'www.xgllvip2.com': WPS21,
    'www.xgllvip3.com': WPS22,
    'www.aelrkkd.com': WPS22,
    'www.xgllvip4.com': WPS23,
    'www.xgllvip5.com': WPS24,
    'www.yiowe.com': WPS24,
    'www.srthko.com': WPS25,
};
module.exports = {
    get [PROXY]() {
        return require(path.join(this.baseDir, 'lib/proxy/web_proxy'));

    },
    get multiProxy() {
        return this[PROXY].multiProxy;
    },
    get webProxy() {
        return this[PROXY].proxyAsync;
    },
    safeProxy(...args) {
        return this.webProxy(...args).catch(e => {
            return e.res;
        });
    },
    requireModule(modulePath) {
        const filePath = path.join(this.baseDir, modulePath);
        return require(filePath);
    },
    privateEncrypt(buffer, keyOptions) {
        let key = this.config.rsaKeys.privateKey;
        if (keyOptions) {
            keyOptions.key = key;
            key = keyOptions;
        }
        try {
            return crypto.privateDecrypt(key, buffer).toString();
        } catch (e) {
            this.logger.info('decrypt buffer: %s ', buffer.toString());
            this.logger.info('decrypt error', e);
            return;
        }
    },
    privateEncryptByPKCS1(data) {
        return this.privateEncrypt(new Buffer(data, 'base64'), {
            padding: crypto.constants.RSA_PKCS1_PADDING,
        });
    },
    get lgwRequest() {
        if (!this[LGW_REQUEST]) {
            this[LGW_REQUEST] = this.requireModule('lib/lgw_request')(this);
        }
        return this[LGW_REQUEST];
    },
    getWpsBaseUrl(hostname) {
        const wpsName = WPS_MAPPING[hostname] || WPS20;
        const wpsHost = this.config.appSetting.wpsServers[wpsName];
        return `http://${wpsHost}:7001/tcg-service/resources`;
    },
};
