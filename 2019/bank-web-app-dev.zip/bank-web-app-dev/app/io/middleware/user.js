'use strict';
// 二次验证业务
module.exports = app => {
    return async (ctx, next) => {
        const { socket, logger } = ctx;
        // const nsp = app.io.of('/verify');
        const user = ctx.currentUser;
        const room = `user:${user.id}`;
        socket.join(room);
        logger.info(`enter room ${room}`);
        await next();
        socket.leave(room);
        logger.info(`leave room ${room}`);
    };
};
