'use strict';
module.exports = app => {
    const authUser = app.requireModule('lib/auth_user');
    const options = app.config.auth;
    return authUser(options, app);
    // console.log(`socket auth get connection`);
    // // const auth = app.middleware.auth(app.config.auth, app);
    // // return auth;
    // const lgwRequest = app.requireModule('lib/lgw_request')(app);
    // return async (ctx, next) => {
    //     if (app.config.auth.debug && ctx.query.user_id) {
    //         ctx.currentUser = { id: ctx.query.user_id };
    //         await next();
    //         return;
    //     }
    //     const token = ctx.headers.authorization;
    //     const merchant = ctx.headers.merchant || '2000cai';
    //     try {
    //         // const startTime = Date.now();
    //         const res = await lgwRequest.getUserInfo(merchant, token);
    //         // const duration = Date.now() - startTime;
    //         // console.log(`auth time: ${duration} ms`);
    //         if (res.success) {
    //             ctx.currentUser = res.value;
    //         }
    //     } catch (e) {
    //         app.logger.info(`auth fail with authorization:${token}, merchant:${merchant}`);
    //     }
    //     await next();
    // };
};
