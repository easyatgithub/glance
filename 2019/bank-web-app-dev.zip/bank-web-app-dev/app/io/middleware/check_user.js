'use strict';
module.exports = () => {
    return async (ctx, next) => {
        if (!ctx.currentUser) {
            const { app, socket, logger } = ctx;
            const nsp = app.io.of('/');
            // 踢出用户
            socket.emit('login.fail', {
                type: 'login.fail',
                data: {
                    msg: '未登录',
                },
            });
            socket.disconnect(true);
            return;
            // socket.disconnect(false);
            // nsp.adapter.remoteDisconnect(socket.id, true, err => {
            //     logger.error(err);
            // });
            // return;
        }
        await next();
    };
};