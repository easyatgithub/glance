'use strict';
const Controller = require('egg').Controller;

module.exports = app => {
    class BaseController extends Controller {
        async join() {
            const { ctx } = this;
            const { socket } = ctx;
            const message = ctx.args[0] || {};
            const { rooms } = message;
            if (!rooms) {
                return;
            }
            // socket.ent
            rooms.forEach(room => {
                socket.join(room);
            });
            socket.emit('join', { data: true });
        }
        async leave() {
            const { ctx } = this;
            const { socket } = ctx;
            const message = ctx.args[0] || {};
            const { rooms } = message;
            if (!rooms) {
                return;
            }
            // socket.ent
            rooms.forEach(room => {
                socket.leave(room);
            });
        }
    }

    return BaseController;
};
