'use strict';
module.exports = function(app) {
    const DataTypes = app.Sequelize;
    return app.model.define('system_config', {
        id: {
            type: DataTypes.INTEGER(11),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },

        config_key: {
            type: DataTypes.STRING(50),
            allowNull: false,
            defaultValue: '',
        },
        config_value: {
            type: DataTypes.STRING(200),
            allowNull: false,
            defaultValue: '',
        },

        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },

    }, {
        tableName: 'system_config',
    });
};
