/*

https://www.npmjs.com/package/egg-sequelize


http://docs.sequelizejs.com/manual/tutorial/models-definition.html
*/

'use strict';
module.exports = function(app) {
    const DataTypes = app.Sequelize;
    return app.model.define('bank_account', {
        id: {
            type: DataTypes.INTEGER(11),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },

        agent_code: {
            type: DataTypes.STRING(20),
            allowNull: true,
            defaultValue: '',
        },
        phone_number: {
            type: DataTypes.STRING(100),
            allowNull: true,
            defaultValue: '',
        },
        bank_code: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        bank_account: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        auto_seq: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        phone_status: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        payee: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        tail: {
            type: DataTypes.STRING(5),
            allowNull: true,
        },
        brand: {
            type: DataTypes.STRING(20),
            allowNull: true,
        },
        push: {
            type: DataTypes.STRING(20),
            allowNull: true,
        },
    }, {
        tableName: 'bank_account',
    });
};
