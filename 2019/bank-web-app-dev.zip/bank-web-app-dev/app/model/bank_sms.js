/*

https://www.npmjs.com/package/egg-sequelize


http://docs.sequelizejs.com/manual/tutorial/models-definition.html
*/

'use strict';
module.exports = function(app) {
    const DataTypes = app.Sequelize;
    return app.model.define('bank_sms', {
        id: {
            type: DataTypes.INTEGER(11),
            allowNull: false,
            primaryKey: true,
            autoIncrement: true,
        },
        phone_from: {
            type: DataTypes.STRING(15),
            allowNull: false,
            defaultValue: '',
        },
        phone_to: {
            type: DataTypes.STRING(15),
            allowNull: false,
            defaultValue: '',
        },
        bank_msg: {
            type: DataTypes.STRING(255),
            allowNull: false,
            defaultValue: '',
        },
        bank: {
            type: DataTypes.STRING(30),
            allowNull: false,
            defaultValue: '',
        },
        payee: {
            type: DataTypes.STRING(30),
            allowNull: false,
            defaultValue: '',
        },
        payee_time: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        diff_time: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        payee_tail: {
            type: DataTypes.STRING(10),
            allowNull: true,
        },
        amount: {
            type: DataTypes.FLOAT(9, 2),
            allowNull: true,
        },
        balance: {
            type: DataTypes.FLOAT(9, 2),
            allowNull: true,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        push_status: {
            type: DataTypes.STRING(20),
            allowNull: true,
        },
        push_result: {
            type: DataTypes.STRING(20),
            allowNull: true,
        },
        add_money_status: {
            type: DataTypes.STRING(20),
            allowNull: true,
        },
        add_money_time: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        desc_str: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        msg_time: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        brand: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
        receiver: {
            type: DataTypes.STRING(50),
            allowNull: true,
        },
    }, {
        tableName: 'bank_sms',
    });
};
