/*

v3.3.3

*/
var flag = 1; 
var t = 0; //自动刷新唯一定时器 id
var args = { 
		brand: "",
		bank: "",
		card: "",
		phone: "",
		pyee: " ",
		payee_time: null,
		created_time: null,
		push: null,
		add: null,
		income: 'income',
		phone_from:"",
};
var  autoCount = 0;  //是否是自动刷新的第二次查询   第一次不提示声音
var  lastArg ={}; //用于判断 查询条件 当条件变化了 自动刷新的首次 标识变为 0
var  lastCount = 0;
var  msgFlag = true;
var  pageBrand =[];
var  auto_value = 0;
$(function () {
	$.ajaxSettings.async = false
	search_area()
	pageInit();
	core()
	button_area();

});
function search_area(){
	var htmls = ['', '', '', '', '']
	$.get('../backend/sms_config', function (data) {
		pageBrand = JSON.parse(data.ret[1].config_value)
		auto_value = parseInt(data.ret[2].config_value)
		$.each(JSON.parse(data.ret[0].config_value), function (i, o) {
			htmls[1] += '<option value="' + o.value + '">' + o.value + '</option>'
		})
		$.each(JSON.parse(data.ret[1].config_value), function (i, o) {
			htmls[0] += '<option value="' + o.key + '">' + o.value + '</option>'
		})
		$.each(data.payee, function (i, o) {
			htmls[2] += '<option value="' + o + '">' + o + '</option>'
		})
		Object.getOwnPropertyNames(data.phone).forEach(function (val, idx, array) {
			htmls[3] += '<option value="' + val + '">' + val + '</option>'
		});
		$.each(data.payeer, function (i, o) {
			htmls[4] += '<option value="' + o + '">' + o + '</option>'
		})
		$(".arg-brand").append(htmls[0])
		$(".arg-bank").append(htmls[1])
		$(".arg-card").append(htmls[2])
		$(".arg-phone").append(htmls[3])

		$(".arg-pyee").append(htmls[4])
	}, 'json')
}
function core(){
	$.get("../backend/summary", function (data) {
		$(".summary").html("总计:当前条件下共 " + data[0] + "条收款短信,成功推送" + data[1] + "条,未推送" + data[2] + "条,推送失败" + data[3] + "条,上分失败" + data[4] + "条")
	}, 'json')
	$("#list2").on("click", 'i', function () {
		$(this).parent(2).click()
	})
}
function button_area(){
	$('.btn').click(function () {
		if ($(this).data('x') != null) {
			if ($(this).data('x') == 'all') {
				args.push = ''
				args.add = ''
				args.income = ''
				search()
			} else if ($(this).data('x') == 'income') {
				args.add = ''
				args.push = ''
				args.income = 'income'
				search()
			} else if ($(this).data('x') == 'push-success') {
				args.add = ''
				args.income = ''
				args.push = 'success'
				search()
			} else if ($(this).data('x') == 'push-fail') {
				args.add = ''
				args.income = ''
				args.push = 'fail'
				search()
			} else if ($(this).data('x') == 'add-fail') {
				args.push = ''
				args.income = ''
				args.add = 'fail'
				search()
			} else if ($(this).data('x') == 'not-push') {
				args.add = ''
				args.income = ''
				args.push = 'no'
				search()
			} else if ($(this).data('x') == 'not-office') {
				args.add = ''
				args.push = ''
				args.income = ''
				args.phone ='not-office'
				search('not-office')
			} else if ($(this).data('x') == 'today') {
				args.push = ''
				args.add = ''
				args.created_time = 'created_time'
				args.created_time_from = moment().format('YYYY-MM-DD') + " 00:00:00"
				args.created_time_to = moment().add(1, 'days').format('YYYY-MM-DD') + " 00:00:00"
				search()
			} else if ($(this).data('x') == 'yesterday') {
				args.push = ''
				args.add = ''
				args.created_time = 'created_time'
				args.created_time_from = moment().subtract(1, 'days').format('YYYY-MM-DD') + " 00:00:00"
				args.created_time_to = moment().format('YYYY-MM-DD') + " 00:00:00"
				search()
			} else if ($(this).data('x') == 'excle') {
				var obj = $('#list2').jqGrid('getGridParam').postData
				$.get('../backend/excle', obj, function (data) {
					sleep(5000)
					if (data.msg) {
						window.location.href = "/backend/excle_file"
					} else {
						alert(data.code)
					}
				}, 'json')
			} else if ($(this).data('x') == 'search') {
				var time = [$('#msgmin').val(), $('#msgmax').val(), $('#datamin').val(), $('#datamax').val()]
				if (time[0].length > 0 || time[1].length > 0) {
					if (moment(time[1]).isBefore(moment(time[1]))) {
						alert("短信时间段错误")
						$("#msgmax").val("")
					}
					args.created_time = 'created_time'
					args.created_time_from = time[0]
					args.created_time_to = time[1]
				} else{
					args["created_time"] =""
				}
				if (time[2].length > 0 || time[3].length > 0) {
					if (moment(time[3]).isBefore(moment(time[2]))) {
						alert("收款时间段错误")
						$("#datamax").val("")
					}
					args.payee_time = 'payee_time'
					args.payee_time_from = time[2]
					args.payee_time_to = time[3]
				}else{
					args["payee_time"] =""
				}
				search()
			} else if ($(this).data('x') == 'man') {
				if (flag == 0) {
					clearInterval(t)
					$(this).html('手动刷新')
					$(this).attr("title","点击后将自动刷新")

					flag = 1
				} else {
					auto_flash()
					$(this).html('自动刷新')
					$(this).attr("title","点击后将手动刷新")
					flag = 0
				}
			}
		}
	})
}
function sleep(sec) {
    var exitTime = new Date().getTime() + sec;
    while (new Date().getTime()<exitTime) {
    }
} 
function search(condetion) {
	var arr = [$(".arg-brand").val(), $(".arg-bank").val(), $(".arg-card").val(), $(".arg-phone").val(), $(".arg-pyee").val(),$(".arg-phone_from").val()]
	args.brand = arr[0] == '0' ? '' : arr[0]
	args.bank = arr[1] == '0' ? '' : arr[1]
	args.card = arr[2] == '0' ? '' : arr[2]
	args.pyee = arr[4] == '0' ? '' :  arr[4]  
	args.phone_from  = arr[5]  
	if (arr[5].length>1&&!(/\d{4,11}$/.test( arr[5]))) {
		alert("号码格式错误")
		return false;
	}
	if(condetion!='not-office') {
		args.phone = arr[3] == '0' ? '' : arr[3]
	}
	$("#list2").jqGrid('setGridParam', {
		url: '../backend/bank_sms_list',
		datatype: 'json',
		postData: args,
		page: 1
	}).trigger("reloadGrid");
	$.get("../backend/summary", function (data) {
		$(".summary").html("总计:当前条件下共 " + data[0] + "条收款短信,成功推送" + data[1] + "条,未推送" + data[2] + "条,推送失败" + data[3] + "条,上分失败" + data[4] + "条")
	}, 'json')
}
function pageInit() {
	var cellsrenderer = function (row, column, value) {
		alert(1)
		return '<div style="text-align: center; margin-top: 5px;">' + value + '</div>';
	}
	var columnsrenderer = function (value) {
		return '<div style="text-align: center; margin-top: 5px;">' + value + '</div>';
	}
	var  len=[40,80,100,800,100,90
	,50,50,60,50,60  //金额
	,60,90,100,80,80  //进度
	,80,80,100,100,200
	,200
	];
	jQuery("#list2").jqGrid({
		url: '../backend/bank_sms_list',
		datatype: "json",
		colModel: [ {
			    label: '编号',
				name: 'ID',
				index: 'id',
				align: "center",
				width: len[0]
			},
			 {
				label: '品牌',
				width: len[1],
				align: "center",
				formatter: function (cellvalue, options, rowObject) {
					    var str =""
					 	if(rowObject[1]){
							$.each(pageBrand,function(i,o){
								if(o.key==rowObject[1])  
								  str =o.value
								})
							 return str
						 }else{
							 return '--';
						 }
				}
			},
			{
				name: '短信内容',
				index: 'msg',
				width: len[2],
				align: "center",
			},
			{
				name: '_短信内容_',
				index: 'msg',
				width: len[3],
				align: "center",
				hidden:true
			},
			{
				name: '发件号码',
				index: 'phone',
				width: len[4],
				align: "center",
			},
 
			{
				label: '接收时间',
				width: len[5],
				align: "center",
				sortable:true,
				formatter: function (cellvalue, options, rowObject) {
					 	return rowObject[5].split(" ")[0]+"<br>"+rowObject[5].split(" ")[1]+"<br>";
					 
				}
			},
			{
				name: '付款人',
				index: 'pyee',
				width: len[6],
				align: "center"
			},
			{
				name: ' 收款人',
				index: 'pyee',
				width: len[7],
				align: "center",
			},
			{
				name: '银行',
				index: 'bank',
				width: len[8],
				align: "center",
				title:false,
			},
			{
				name: "银行卡",
				index: 'banktail',
				width: len[9],
				align: "center"
			},
			{
				label: '收款',
				width: len[10],
				align: "center",
				sortable:true,
				formatter: function (cellvalue, options, rowObject) {
					if (  rowObject[10] == 0 || rowObject[10] == "0") {
                        return '  - -  ';
					} else {
						return  rowObject[10] +" ";
					}
				}
			},
			{
				label: '余额',
				width: len[11],
				align: "center",
				sortable:true,
				formatter: function (cellvalue, options, rowObject) {
					if (  rowObject[11] == 0 || rowObject[11] == "0") {
                        return '  - -  ';
					} else {
						return rowObject[11]+" ";
					}
				}
			},
			{
				label: '收款时间',
				width: len[12],
				align: "center",
				sortable:true,
				formatter: function (cellvalue, options, rowObject) {
					if (  rowObject[12] == "2018-08-08 00:00:00" ) {
                    	return '  - -  ';
					} else {
						return rowObject[12].split(" ")[0]+"<br>"+rowObject[12].split(" ")[1]+"<br>";
					}
				}
			},
			{
				name: '收款手机号',
				index: 'phonum',
				width: len[13],
			},
			{
				name: '时间差',
				index: 'difftime',
				width: len[14],
				sortable:true,
				align: "center"
			},
			{
				name: '推送进度',
				index: 'push_status',
				width: len[15],
				align: "center",
				sortable: false
			},
			{
				name: '推送状态',
				index: 'push_result',
				width: len[16],
				align: "center",
				sortable: false
			},
			{
				name: '上分状态',
				index: 'add_money_status',
				width: len[17],
				align: "center"
			},
			{
				label: '上分时间',
				width: len[18],
				align: "center",
				sortable:true,
				formatter: function (cellvalue, options, rowObject) {
					if (  moment(rowObject[15] ).isValid() ) {
						return rowObject[15].split(" ")[0]+"<br>"+rowObject[15].split(" ")[1]+"<br>";
					} else {
						return '  - -  ';
					}
				}

			},
			{
				label: '操作',
				width: len[19],
				align: "center",
				formatter: function (cellvalue, options, rowObject) {
					//console.log(rowObject)
					if (rowObject[15] == '不推送' && rowObject[16] == '未推送') {
						var str = '<span type="button" clzz="btn btn-success" onclick="manOper(this,' + rowObject[0] + ',1)" style="color:blue;border:0px;">手工推送</span>'
						return str;
					} else if (   rowObject[16] == '失败') {
						 	var str = '<span type="button" clzz="btn btn-success" onclick="manOper(this,' + rowObject[0] + ',0)" style="color:blue;border:0px;">再推送一次</span>'
						return str;
					}else{
						return " ";
					}
				}
			},
			{
				label: '备注',
				width: len[20],
				align: "center",
				formatter: function (cellvalue, options, rowObject) {
					if(rowObject[19]){
						return rowObject[19];
					}else{
						return "--";
					}
				}
			}, 
		],
		onCellSelect: function (rowId, iCol, content, event) {
			 if(iCol==2){   $("#list2").showCol("_短信内容_")
							$("#list2").hideCol('短信内容')
							$("#gbox_list2").width(1648)
							msgFlag =true
			 }
			 if(msgFlag&&iCol==3){   $("#list2").hideCol("_短信内容_")
							 $("#list2").showCol('短信内容')
							 $("#gbox_list2").width(1648)
							 msgFlag =false
		  	 }
		  },
		  onSelectRow: function(id) {
			$('.ui-widget-content').each(function(id) {
				if(id%2 ==0){
					$(this).css('background', '#FCF3EE');
				 }else{
					$(this).css('background', '#FCF9E6');
				 }
			});
				$(this).find('.ui-state-highlight').css('background', '#80BFFF');
	  },
		loadComplete: function (data) {
			$("tr.jqgrow:even").css("background", "#FCF3EE");
			$("tr.jqgrow:odd").css("background", "#FCF9E6");
			$("#list2").closest(".ui-jqgrid-bdiv").css({ 'overflow-y' : 'hidden','overflow-x':'hidden' });  
			$(".ui-jqgrid-sortable").each(function (i,o){
				$(this).css("font-size","15px")
				this.style.color = "#fff";
				this.style.paddingTop = "2px"
			  switch(i){
				  case 0:
				  case 1:this.style.background = "#666"; break;
				  case 2:
				  case 3:
				  case 4:
				  case 5:
				  case 6:this.style.background = "#7487E6"; break;
				  case 7:
				  case 8:
				  case 9:
				  case 10:
				  case 11:
				  case 12:
				  case 13:this.style.background = "#F2A433"; break;
				  case 14:
				  case 15:
				  case 16:
				  case 17:
				  case 18:
				  case 19:
				  case 20:this.style.background = "#666"; break;
			  }
			})
       },
		prmNames: {
			rows: "size"
		},
		postData: args,
		rowNum: 50,
		rowList: [30, 50, 100],
        width: 1650,
        //width: 98 * window.screen.availWidth / 100,
        //      width:window.screen.availWidth-20,
         autowidth: false,
         shrinkToFit: false,

	    height: "auto",//4 * window.screen.availHeight / 9,
		pager: '#pager2',
		sortable:true,
		sortname: 'id',
		sortorder: "desc",
		mtype: "get",
		viewrecords: true,
	});
	jQuery("#list2").jqGrid('navGrid', '#pager2', {
		edit: false,
		add: false,
		del: false
	});
}
 
function manOper(th, id, cc) {
	$(th).parent().click()
	console.log(id,cc)
  if(localStorage.getItem("isAdmin")=='1'||cc==0){
	$.post('../backend/sms_man_push', {
		id: id,
		cc: cc
	}, function (data) {
		console.log(id,cc,data)
		if (data.msg) {	 
			$("#list2").jqGrid('setGridParam', {
				url: '../backend/bank_sms_list',
				datatype: 'json',
				postData: {},
				page: $('#list2').getGridParam('page')
			}).trigger("reloadGrid");  
		}
	}, 'json')
}
}
function auto_flash() {
	setTimeout(function () {
		t = setInterval(function () {
			$("#list2").jqGrid('setGridParam', {
				url: '../backend/bank_sms_list',
				datatype: 'json',
				postData:{},
				page: 1
			}).trigger("reloadGrid"); 
	 var allData = $("#list2").jqGrid('getRowData');
 	 if(t>0 &&  JSON.stringify(lastArg)==JSON.stringify(args)){ //仅第二次后会相等
		if(t>0 && allData[0].ID >lastCount ){
			$("#sound")[0].play()
			lastCount = allData[0].ID;
		 }else{
			lastCount = allData[0].ID;
		 }
	 }else{
		lastArg =args;
		lastCount = allData[0].ID;
	 }
		}, auto_value)
	}, 5000)
}