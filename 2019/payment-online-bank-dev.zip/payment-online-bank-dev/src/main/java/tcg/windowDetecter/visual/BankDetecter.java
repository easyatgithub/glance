package tcg.windowDetecter.visual;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.*;
import java.util.List;

import javax.imageio.ImageIO;

import com.wlft.payment.swing.TaskSelectPanel;
import org.apache.log4j.Logger;
import tcg.windowDetecter.constants.BankData;
import tcg.windowDetecter.contracts.BankEnum;
import tcg.windowDetecter.contracts.IImageFinder;
import tcg.windowDetecter.models.Bank;
import tcg.windowDetecter.models.BankWindowResult;

public class BankDetecter {
	private List<Bank> dataSets;
	
	private IImageFinder imageFinder;
	private ClassLoader classLoader;
	private static final Logger logger = Logger.getLogger(BankDetecter.class);

	private void initData() {
		this.dataSets = BankData.get();
	}
	
	public BankDetecter() {
		// Create Image Finder instance
		this.imageFinder = new ImageFinder();
		// Set matching method.
		this.imageFinder.setMatchingMethod(MatchingMethod.MM_CORELLATION_COEFF_NORMED);

        this.classLoader = this.getClass().getClassLoader();
        this.initData();
	}

	public BankWindowResult findWindow(BankEnum bankId, BufferedImage sourceImage, double desiredAccuracy) {
		Optional<Bank> bankOptional = dataSets.stream().filter(x -> x.getId() == bankId).findFirst();
		
		if (!bankOptional.isPresent()) {
			throw new NoSuchElementException("Bank is not exists.");
		}

		Bank bank = bankOptional.get();
		
		Optional<ImageFinderResult> templateResult = bank.getTemplateFrameImageSrc().stream()
				.map(x -> {
			        String path = bank.getSlug() + "/" + x;
			        return this.tryFind(sourceImage, null, path, desiredAccuracy);
				})
				.filter(x -> x != null)
				.findFirst();
		if (!templateResult.isPresent()) {
			return new BankWindowResult("Frame"); 
		}

		Optional<Rectangle> confirmButtonResult = bank.getConfirmButtonImageSrc().stream()
				.map(x -> {
			        String path = bank.getSlug() + "/" + x;
			        return this.tryFindSubImage(sourceImage, templateResult.get().getFoundRect(), path);
				})
				.filter(x -> x != null)
				.findFirst();
		if (!confirmButtonResult.isPresent()) {
			return new BankWindowResult("Confirm Button"); 
		}

		Optional<Rectangle> passwordTextboxResult = bank.getPasswordTextboxImageSrc().stream()
				.map(x -> {
			        String path = bank.getSlug() + "/" + x;
			        return this.tryFindSubImage(sourceImage, templateResult.get().getFoundRect(), path);
				})
				.filter(x -> x != null)
				.findFirst();
		if (!passwordTextboxResult.isPresent()) {
			return new BankWindowResult("Password Textbox"); 
		}
        
        return new BankWindowResult(
    		templateResult.get().getFoundRect(),
    		confirmButtonResult.get(),
    		passwordTextboxResult.get()
		);
	}
	
	private ImageFinderResult tryFind(BufferedImage sourceImage, Rectangle sourceRect, String templatePath, double desiredAccuracy) {
		try {
//			File file = new File(this.classLoader.getResource("/"+templatePath).getFile());
			logger.info( templatePath );
			File file = new File(System.getProperty("user.home") + "/opencv/" +templatePath);
			logger.info( "bank pacture   templatePath =  " + templatePath );
			if (!file.exists()) {
				logger.info("bank pacture file not exists ");
				throw new FileNotFoundException("File not found! (" + templatePath + ")");
			}
			return this.imageFinder.findImage(sourceImage, sourceRect, file, desiredAccuracy);
		} catch (Exception ex) {
			logger.info("bank pacture tryFind catch  " + ex.getMessage());
		}
		return null;
	}

	
	private Rectangle tryFindSubImage(BufferedImage sourceImage, Rectangle sourceRect, String templatePath) {
		try {
	    	BufferedImage subImage = sourceImage;
	        if (sourceRect != null) {
	            subImage = sourceImage.getSubimage(
	                    sourceRect.x,
	                    sourceRect.y,
	                    sourceRect.width,
	                    sourceRect.height);
	        }
//			  File file = new File(this.classLoader.getResource("/"+templatePath).getFile());
			logger.info( templatePath );
			File file = new File(System.getProperty("user.home") + "/opencv/" +templatePath);
			logger.info( "bank pacture   templatePath =  " + templatePath );
			if (!file.exists()) {
				throw new FileNotFoundException("File not found! (" + templatePath + ")");
			}
			return this.imageFinder.findSubimage(subImage, ImageIO.read(file));
		} catch (Exception ex) {
			logger.info("bank pacture tryFindSubImage catch  " + ex.getMessage());
		}
		return null;
	}
}
