package tcg.windowDetecter.visual;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

import org.opencv.core.Core;
import org.opencv.core.Core.MinMaxLocResult;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc; 

//import nu.pattern.OpenCV;
import tcg.windowDetecter.contracts.IImageFinder;
import tcg.windowDetecter.exceptions.ImageNotFoundException;

public class ImageFinder implements IImageFinder { 

    static {
//        OpenCV.loadShared();
        System.loadLibrary(org.opencv.core.Core.NATIVE_LIBRARY_NAME);
    }

    MatchingMethod matchingMethod;

    public ImageFinder() {
        this.matchingMethod = MatchingMethod.MM_SQUARE_DIFFERENCE;
    }

    /**
     * Finds any one of the template images in a source image. The method
     * iterates through the template images, performs a find operation for each
     * one of them and selects the one that produced the best accuracy. Throws
     * an exception when no image was found or the desired accuracy couldn't be
     * met.
     *
     * @param sourceImage The source image.
     * @param sourceRect The rectangle in the source image to look into. If
     * null, the find operation will look into the whole source image.
     * @param templateImages The collection of template images to look for in
     * the source image.
     * @param desiredAccuracy The desired accuracy of the find operation as a
     * number between 0 and 1.
     * @return An ImageFinderResult object that stores the rectangle of the
     * found image and desired accuracy.
     */
    public ImageFinderResult findAnyImage(BufferedImage sourceImage, Rectangle sourceRect, List<BufferedImage> templateImages, double desiredAccuracy) {
        ImageFinderResult bestResult = new ImageFinderResult(new Rectangle(100, 100, 100, 100), 0);

        for (BufferedImage templateImage : templateImages) {
            try {
                ImageFinderResult result = this.findImage(sourceImage, sourceRect, templateImage, 0);
                if (result.getAccuracy() > bestResult.getAccuracy()) {
                    bestResult = result;
                }
            } catch (UnsupportedOperationException ex) {
                // This exception will be thrown when the template
                // image is larger than the source image
            } catch (Exception ex) {
             
            }
        }

        if (bestResult.getAccuracy() < desiredAccuracy) {
            String messagePrefix = templateImages.size() == 1
                    ? "Failed to find the template image"
                    : String.format("Failed to find one of %s template images", templateImages.size());

            throw new ImageNotFoundException(
                    String.format(
                            "%s in the source image at (%s, %s, %s, %s). The best accuracy was %.2f and the desired accuracy was %.2f",
                            messagePrefix,
                            sourceRect.x,
                            sourceRect.y,
                            sourceRect.width,
                            sourceRect.height,
                            bestResult.getAccuracy(),
                            desiredAccuracy), bestResult.getFoundRect(), bestResult.getAccuracy());
        }

        return bestResult;
    }

    /**
     * Finds a template image on the screen. Throws an exception when the image
     * wasn't found or the desired accuracy couldn't be met.
     *
     * @param sourceScreenRect The rectangle on the screen to look into.
     * @param templateImage The template image to find.
     * @param desiredAccuracy The desired accuracy of the find operation as a
     * number between 0 and 1.
     * @return An ImageFinderResult object that stores the rectangle of the
     * found image and desired accuracy.
     */
    public ImageFinderResult findImage(Rectangle sourceScreenRect, BufferedImage templateImage, double desiredAccuracy) {
        try {
            BufferedImage capture = new Robot().createScreenCapture(sourceScreenRect);
            Mat sourceMat = CvHelper.convertToMat(capture);
            Mat templateMat = CvHelper.convertToMat(templateImage);
            return this.findImage(sourceMat, templateMat, desiredAccuracy);
        } catch (Exception ex) {
            throw new RuntimeException(String.format(
                    "An error ocurred while trying to find an image on screen at (%s, %s, %s, %s)",
                    sourceScreenRect.x,
                    sourceScreenRect.y,
                    sourceScreenRect.width,
                    sourceScreenRect.height), ex);
        }
    }

    /**
     * Finds a template image on the screen. Throws an exception when the image
     * wasn't found or the desired accuracy couldn't be met.
     *
     * @param sourceScreenRect The rectangle on the screen to look into.
     * @param templateImage The template image to find.
     * @param desiredAccuracy The desired accuracy of the find operation as a
     * number between 0 and 1.
     * @return An ImageFinderResult object that stores the rectangle of the
     * found image and desired accuracy.
     */
    public ImageFinderResult findImage(Rectangle sourceScreenRect, File templateImage, double desiredAccuracy) {
        try {
            BufferedImage capture = new Robot().createScreenCapture(sourceScreenRect);
            Mat sourceMat = CvHelper.convertToMat(capture);
            Mat templateMat = Imgcodecs.imread(templateImage.getAbsolutePath());
            return this.findImage(sourceMat, templateMat, desiredAccuracy);
        } catch (Exception ex) {
            throw new RuntimeException(String.format(
                    "An error ocurred while trying to find an image on screen at (%s, %s, %s, %s)",
                    sourceScreenRect.x,
                    sourceScreenRect.y,
                    sourceScreenRect.width,
                    sourceScreenRect.height), ex);
        }
    }

    /**
     * Finds a template image in a source image. Throws an exception when the
     * image wasn't found or the desired accuracy couldn't be met.
     *
     * @param sourceMat The source image.
     * @param templateMat The template image to find in the source image.
     * @param desiredAccuracy The desired accuracy of the find operation as a
     * number between 0 and 1.
     * @return An ImageFinderResult object that stores the rectangle of the
     * found image and desired accuracy.
     */
    private ImageFinderResult findImage(Mat sourceMat, Mat templateMat, double desiredAccuracy) {
        if (sourceMat.width() < templateMat.width() || sourceMat.height() < templateMat.height()) {
            throw new UnsupportedOperationException("The template image is larger than the source image. Ensure that the width and/or height of the image you are trying to find do not exceed the dimensions of the source image.");
        }

        Mat result = new Mat(sourceMat.rows() - templateMat.rows() + 1, sourceMat.rows() - templateMat.rows() + 1, CvType.CV_32FC1);
        int intMatchingMethod;

        switch (this.matchingMethod) {
            case MM_CORELLATION_COEFF_NORMED:
                intMatchingMethod = Imgproc.TM_CCOEFF_NORMED;
                break;
            case MM_CORELLATION_COEFF:
            	intMatchingMethod = Imgproc.TM_CCOEFF;
                break;
            case MM_CROSS_CORELLATION_NORMED:
                intMatchingMethod = Imgproc.TM_CCORR_NORMED;
                break;
            case MM_CROSS_CORELLATION:
                intMatchingMethod = Imgproc.TM_CCORR;
                break;
            case MM_SQUARE_DIFFERENCE_NORMED:
                intMatchingMethod = Imgproc.TM_SQDIFF_NORMED;
                break;
            case MM_SQUARE_DIFFERENCE:
                intMatchingMethod = Imgproc.TM_SQDIFF;
                break;
            default:
                intMatchingMethod = Imgproc.TM_SQDIFF_NORMED;
        }

        Imgproc.matchTemplate(sourceMat, templateMat, result, intMatchingMethod);
        MinMaxLocResult minMaxLocRes = Core.minMaxLoc(result);

        double accuracy = 0;
        Point location = null;

        if (this.matchingMethod == MatchingMethod.MM_SQUARE_DIFFERENCE_NORMED
        		|| this.matchingMethod == MatchingMethod.MM_SQUARE_DIFFERENCE_NORMED) {
            accuracy = 1 - minMaxLocRes.minVal;
            location = minMaxLocRes.minLoc;
        } else {
            accuracy = minMaxLocRes.maxVal;
            location = minMaxLocRes.maxLoc;
        }

        if (accuracy < desiredAccuracy) {
            throw new ImageNotFoundException(
                    String.format(
                            "Failed to find template image in the source image. The accuracy was %.2f and the desired accuracy was %.2f",
                            accuracy,
                            desiredAccuracy),
                    new Rectangle((int) location.x, (int) location.y, templateMat.width(), templateMat.height()),
                    accuracy);
        }

        if (!minMaxLocResultIsValid(minMaxLocRes)) {
            throw new ImageNotFoundException(
                    "Image find result (MinMaxLocResult) was invalid. This usually happens when the source image is covered in one solid color.",
                    null,
                    null);
        }

        Rectangle foundRect = new Rectangle(
                (int) location.x,
                (int) location.y,
                templateMat.width(),
                templateMat.height());

        return new ImageFinderResult(foundRect, accuracy);
    }

    /**
     * Finds a template image in a source image. Throws an exception when the
     * image wasn't found or the desired accuracy couldn't be met.
     *
     * @param sourceImage The source image.
     * @param templateImage The template image to find in the source image.
     * @param desiredAccuracy The desired accuracy of the find operation as a
     * number between 0 and 1.
     * @return An ImageFinderResult object that stores the rectangle of the
     * found image and desired accuracy.
     */
    public ImageFinderResult findImage(File sourceImage, File templateImage, double desiredAccuracy) {
        Mat sourceMat = Imgcodecs.imread(sourceImage.getAbsolutePath());
        Mat templateMat = Imgcodecs.imread(templateImage.getAbsolutePath());
        return this.findImage(sourceMat, templateMat, desiredAccuracy);
    }

    /**
     * Finds a template image in a source image. Throws an exception when the
     * image wasn't found or the desired accuracy couldn't be met.
     *
     * @param sourceImage The source image.
     * @param sourceRect The rectangle in the source image to look into. If
     * null, the find operation will look into the whole source image.
     * @param templateImage The template image to find in the source image.
     * @param desiredAccuracy The desired accuracy of the find operation as a
     * number between 0 and 1.
     * @return An ImageFinderResult object that stores the rectangle of the
     * found image and desired accuracy.
     */
    public ImageFinderResult findImage(BufferedImage sourceImage, Rectangle sourceRect, BufferedImage templateImage, double desiredAccuracy) {
        BufferedImage subImage = sourceImage;
        if (sourceRect != null) {
            subImage = sourceImage.getSubimage(
                    sourceRect.x,
                    sourceRect.y,
                    sourceRect.width,
                    sourceRect.height);
        }

        Mat sourceMat = CvHelper.convertToMat(subImage);
        Mat templateMat = CvHelper.convertToMat(templateImage);

        return this.findImage(sourceMat, templateMat, desiredAccuracy);
    }

    public ImageFinderResult findImage(BufferedImage sourceImage, Rectangle sourceRect, File templateImage, double desiredAccuracy) {
//        Mat subImage = sourceImage;
//        if (sourceRect != null) {
//        	Rect rect = new Rect(sourceRect.x, sourceRect.y, sourceRect.width, sourceRect.height);
//        	subImage = sourceImage.submat(rect);
//        }
    	BufferedImage subImage = sourceImage;
        if (sourceRect != null) {
            subImage = sourceImage.getSubimage(
                    sourceRect.x,
                    sourceRect.y,
                    sourceRect.width,
                    sourceRect.height);
        }
        Mat sourceMat = CvHelper.convertToMat(subImage);
        Mat templateMat = Imgcodecs.imread(templateImage.getAbsolutePath(), 3);

        return this.findImage(sourceMat, templateMat, desiredAccuracy);
    }

    /**
     * Returns the matching method that is being used by this ImageFinder
     * instance (MM_CORELLATION_COEFF, MM_CROSS_CORELLATION or
     * MM_SQUARE_DIFFERENCE).
     */
    public MatchingMethod getMatchingMethod() {
        return matchingMethod;
    }

    /**
     * Checks whether an OpenCV MinMaxLocResult object is valid. This object is
     * used for storing the location of the minimum and maximum values for an
     * image find operation, along with the actual values themselves.
     */
    private boolean minMaxLocResultIsValid(MinMaxLocResult minMaxLocRes) {
        if (minMaxLocRes.minVal == 1
                && minMaxLocRes.maxVal == 1
                && minMaxLocRes.maxLoc.x == 0
                && minMaxLocRes.maxLoc.y == 0
                && minMaxLocRes.minLoc.x == 0
                && minMaxLocRes.minLoc.y == 0) {

            return false;
        } else {
            return true;
        }
    }

    /**
     * Sets the matching method that will be used by this ImageFinder instance
     * for future find operations (MM_CORELLATION_COEFF, MM_CROSS_CORELLATION or
     * MM_SQUARE_DIFFERENCE).
     */
    public void setMatchingMethod(MatchingMethod matchingMethod) {
        this.matchingMethod = matchingMethod;
    }

    /**
     * Finds the a region in one image that best matches another, smaller, image.
     */
     public Rectangle findSubimage(BufferedImage im1, BufferedImage im2){
       int w1 = im1.getWidth(); int h1 = im1.getHeight();
       int w2 = im2.getWidth(); int h2 = im2.getHeight();
       assert(w2 <= w1 && h2 <= h1);
       // will keep track of best position found
       int bestX = 0; int bestY = 0; double lowestDiff = Double.POSITIVE_INFINITY;
       // brute-force search through whole image (slow...)
       for(int x = 0;x < w1-w2 && lowestDiff > 0.01;x++){
         for(int y = 0;y < h1-h2 && lowestDiff > 0.01;y++){
           double comp = compareImages(im1.getSubimage(x,y,w2,h2),im2);
           if(comp < lowestDiff){
             bestX = x; bestY = y; lowestDiff = comp;
           }
         }
       }
       // output similarity measure from 0 to 1, with 0 being identical
       System.out.println(lowestDiff);
       // return best location
       return new Rectangle(bestX, bestY, w2, h2);
//       return new int[]{bestX,bestY};
     }

     /**
     * Determines how different two identically sized regions are.
     */
     public double compareImages(BufferedImage im1, BufferedImage im2){
       assert(im1.getHeight() == im2.getHeight() && im1.getWidth() == im2.getWidth());
       double variation = 0.0;
       for(int x = 0;x < im1.getWidth();x++){
         for(int y = 0;y < im1.getHeight();y++){
            variation += compareARGB(im1.getRGB(x,y),im2.getRGB(x,y))/Math.sqrt(3);
         }
         if ((variation / ((x + 1) *im1.getHeight())) > 0.1) {
	     	return 1;
	     }
       }
       return variation/(im1.getWidth()*im1.getHeight());
     }

     /**
     * Calculates the difference between two ARGB colours (BufferedImage.TYPE_INT_ARGB).
     */
     public double compareARGB(int rgb1, int rgb2){
       double r1 = ((rgb1 >> 16) & 0xFF)/255.0; double r2 = ((rgb2 >> 16) & 0xFF)/255.0;
       double g1 = ((rgb1 >> 8) & 0xFF)/255.0;  double g2 = ((rgb2 >> 8) & 0xFF)/255.0;
       double b1 = (rgb1 & 0xFF)/255.0;         double b2 = (rgb2 & 0xFF)/255.0;
       double a1 = ((rgb1 >> 24) & 0xFF)/255.0; double a2 = ((rgb2 >> 24) & 0xFF)/255.0;
       // if there is transparency, the alpha values will make difference smaller
       return a1*a2*Math.sqrt((r1-r2)*(r1-r2) + (g1-g2)*(g1-g2) + (b1-b2)*(b1-b2));
     }
    
}
