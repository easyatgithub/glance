package tcg.windowDetecter.constants;

import java.util.ArrayList;
import java.util.List;

import tcg.windowDetecter.contracts.BankEnum;
import tcg.windowDetecter.models.Bank;

public class BankData {
	
	public static List<Bank> get() {
		List<Bank> result = new ArrayList<Bank>();
		
		result.add(new Bank(
	    		BankEnum.ICBC, 
	    		"ICBC", 
	    		new ArrayList<String>() {{
	    			add("f01.jpg");
	    			add("f02.png");
				}}, 
	    		new ArrayList<String>() {{
	    			add("c01.jpg");
	    			add("c02.png");
	    		}}, 
	    		new ArrayList<String>() {{
	    			add("p01.jpg");
	    			add("p02.png");
	    		}}
			));
		
		result.add(new Bank(
	    		BankEnum.CCB, 
	    		"CCB", 
	    		new ArrayList<String>() {{
	    			add("f01.png");
				}}, 
	    		new ArrayList<String>() {{
	    			add("c01.png");
	    		}}, 
	    		new ArrayList<String>() {{
	    			add("p01.png");
	    		}}
			));
		
		result.add(new Bank(
	    		BankEnum.PSBC, 
	    		"PSBC", 
	    		new ArrayList<String>() {{
	    			add("f01.png");
				}}, 
	    		new ArrayList<String>() {{
	    			add("c01.png");
	    		}}, 
	    		new ArrayList<String>() {{
	    			add("p01.png");
	    		}}
			));
		
		return result;
	}
}
