package tcg.windowDetecter.models;

import java.awt.Rectangle;

public class BankWindowResult {
	public Boolean found = false;
	public String nonFoundReason;
	
	private Rectangle frameRect;
	private Rectangle confirmButtonRect;
	private Rectangle passwordTextboxRect;
	
	public BankWindowResult(String nonFoundTarget) {
		this.nonFoundReason = nonFoundTarget + " not found!";
	}
	
	public BankWindowResult(
		Rectangle frameRect,
		Rectangle confirmButtonRect,
		Rectangle passwordTextboxRect
	) {
		this.found = true;
		this.frameRect = frameRect;
		this.confirmButtonRect =confirmButtonRect;
		this.passwordTextboxRect = passwordTextboxRect;
	}
	
	public Rectangle getFrameRect() {
		return this.frameRect;
	}
	
	public Rectangle getConfirmButtonRect() {
		return this.confirmButtonRect;
	}
	
	public Rectangle getPasswordTextboxRect() {
		return this.passwordTextboxRect;
	}
}
