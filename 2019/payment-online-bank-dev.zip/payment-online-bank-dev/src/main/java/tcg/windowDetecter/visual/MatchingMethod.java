package tcg.windowDetecter.visual;

public enum MatchingMethod {
    /**
     * Normalized correlation coefficient.
     */
    MM_CORELLATION_COEFF_NORMED,
    MM_CORELLATION_COEFF,
    
    /**
     * Normalized cross correlation.
     */
    MM_CROSS_CORELLATION,
    MM_CROSS_CORELLATION_NORMED,
    
    /**
     * Sum of squared differences between pixel values.
     */
    MM_SQUARE_DIFFERENCE_NORMED,
    MM_SQUARE_DIFFERENCE
}
