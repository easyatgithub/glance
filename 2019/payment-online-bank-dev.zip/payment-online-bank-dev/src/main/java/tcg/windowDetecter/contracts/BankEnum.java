package tcg.windowDetecter.contracts;

public enum BankEnum {
	ICBC,
	CCB,
	PSBC
}
