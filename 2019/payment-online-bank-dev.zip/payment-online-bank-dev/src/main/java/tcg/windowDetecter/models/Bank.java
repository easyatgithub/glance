package tcg.windowDetecter.models;

import java.util.List;

import tcg.windowDetecter.contracts.BankEnum;

public class Bank {
	private BankEnum id;
	private String slug;
	
	private List<String> templateFrameImageSrc;
	private List<String> confirmButtonImageSrc;
	private List<String> passwordTextboxImageSrc;
	
	public Bank(
		BankEnum id, 
		String slug, 
		List<String> templateFrameImageSrc, 
		List<String> confirmButtonImageSrc, 
		List<String> passwordTextboxImageSrc
	) {
		this.id = id;
		this.slug = slug;
		this.templateFrameImageSrc = templateFrameImageSrc;
		this.confirmButtonImageSrc = confirmButtonImageSrc;
		this.passwordTextboxImageSrc = passwordTextboxImageSrc;
	}
	
	public BankEnum getId() {
		return this.id;
	}
	
	public String getSlug() {
		return this.slug;
	}
	
	public List<String> getTemplateFrameImageSrc() {
		return this.templateFrameImageSrc;
	}
	
	public List<String> getConfirmButtonImageSrc() {
		return this.confirmButtonImageSrc;
	}
	
	public List<String> getPasswordTextboxImageSrc() {
		return this.passwordTextboxImageSrc;
	}
}
