package tcg.windowDetecter.contracts;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;


import tcg.windowDetecter.visual.ImageFinderResult;
import tcg.windowDetecter.visual.MatchingMethod;

public interface IImageFinder {

    ImageFinderResult findImage(Rectangle sourceScreenRect, BufferedImage templateImage, double desiredAccuracy);

    /**
     * Find one of multiple template images in the source image.
     */
    ImageFinderResult findAnyImage(BufferedImage sourceImage, Rectangle sourceRect, List<BufferedImage> templateImages, double desiredAccuracy);
    
    ImageFinderResult findImage(BufferedImage sourceImage, Rectangle sourceRect, BufferedImage templateImage, double desiredAccuracy);

    ImageFinderResult findImage(File sourceImage, File templateImage, double desiredAccuracy);
    ImageFinderResult findImage(BufferedImage sourceImage, Rectangle sourceRect, File templateImage, double desiredAccuracy);

    ImageFinderResult findImage(Rectangle sourceScreenRect, File templateImage, double desiredAccuracy);
    public Rectangle findSubimage(BufferedImage im1, BufferedImage im2);
    public MatchingMethod getMatchingMethod();

    public void setMatchingMethod(MatchingMethod matchingMethod);
}
