package com.wlft.payment.bank;

import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seimicrawler.xpath.JXDocument;

import javax.swing.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;
import static java.lang.Thread.sleep;

public class CGBOnlineBank extends OnlineBank {

    private static Logger logger = Logger.getLogger(CGBOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {
        BANK_MAPPING.put("工商银行", "中国工商银行");
        BANK_MAPPING.put("邮政储汇", "邮政");
    }
    public CGBOnlineBank(Integer id, String accountCode, String hostname, Integer port){
        super("CGB", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);

        loginByPassword();


    }

    private void loginByPassword() throws Exception{

        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);

        //this.initCGBMessageBox();
        //this.setMessage("Start 用户名登陆");

        WebElement ele,ele1,ele2,ele3 = null;
        ele2 = driver.findElement(By.id("loginId"));
        ele2.sendKeys(username);
        press(new String[]{"Tab"}, 100, 50);
//        this.setMessage("Type password");
        for(int i = 0;i < password.length(); i++) {
            press(password.substring(i,i+1).split(""), 100 + (int)(Math.random() * 100), 60);
        }

        Object[] options = {"Yes,是的", "No,取消¦"};
        JOptionPane.showOptionDialog(null, " again?", "询问 ", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options,null);
        sleep(3000);

    }


    @Override
    public void logout() throws Exception {

    }

    @Override
    public void checkBalance(BigDecimal balance) throws Exception {



        driver.switchTo().window(windowHandle);
        this.initCGBMessageBox();
        this.setMessage("Fetch balance");
        clearVerifyPopup();
        driver.executeScript("var radioObj = document.querySelectorAll('a');  radioObj[10].click(); ");
        sleep(5000);
        driver.executeScript("var  radioObj = document.querySelectorAll('a');  radioObj[35].click()");
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("available_balance")));
        WebElement ele3= driver.findElement(By.id("available_balance"));

        String  bal = ele3.getText();
        bal = bal.replaceAll(",","");

        if(bal.length()>0) {
            this.balance = new BigDecimal(bal);
        }else {
            this.balance = new BigDecimal("0.0");
        }

        if(this.balance.compareTo(balance) != 0){
            this.setMessage("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
        }else{
            this.setMessage("Balance:" + bal);
        }

    }

    void clearVerifyPopup() {

        try{
            new WebDriverWait(driver, 2).until(ExpectedConditions.visibilityOfElementLocated(By.id("lightbox")));
            driver.executeScript(" var lightbox = document.getElementById('lightbox');  lightbox.parentNode.removeChild(lightbox);");
        } catch (ScriptTimeoutException e) {
            logger.info("wait ScriptTimeoutException ", e);
        }
        catch (TimeoutException e) {
            logger.info("wait verify popup timeout ", e);
        }
        catch (NoSuchElementException e) {
            logger.info("wait verify popup NoSuchElementException", e);
        }
        catch (Exception e) {

        }
    }

    @Override
    public BigDecimal getPageBalance( ) throws  Exception{

        driver.switchTo().window(windowHandle);
        this.setMessage("Fetch balance");
        driver.executeScript("var radioObj = document.querySelectorAll('a');  radioObj[10].click(); ");
        new WebDriverWait(driver, 7).until((ExpectedCondition<Boolean>) wd ->
                ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
        driver.executeScript("var  radioObj = document.querySelectorAll('a');  radioObj[35].click()");
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("available_balance")));
        WebElement ele3= driver.findElement(By.id("available_balance"));
        String  bal = ele3.getText();
        bal = bal.replaceAll(",","");

        if(bal.length()>0) {
            this.balance = new BigDecimal(bal);
        }

        return this.balance;
    };

    public TaskLog doTransfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {
        boolean ok = false;
        boolean isBOC = bankName.equals("中国银行");
        Point position;

        TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        String imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + ".png";
        Object charge = null;
        String page_index_value ="35";
        String page_amount_id = "txt_transamount_1690";
        String page_payeename_id = "txt_payeename_1600";
        String page_transinaccparent_id = "txt_transinaccparent_1601";
        String page_charge_index = "59";
        String page_submit_id = "btn_confirm_36496";
        String page_success_id = "trans_success_div";

        if(isBOC){
            page_index_value ="34";
            page_amount_id = "txt_transamount_471";
            page_payeename_id = "txt_payeename_455";
            page_transinaccparent_id = "txt_transinaccparent_458";
            page_charge_index = "66";
            page_submit_id = "btnBocTransferConfirm";
            page_success_id = "div_transoutaccparent_3055";
        }
        try {
            this.setMessage("Start transaction");
            driver.switchTo().window(windowHandle);
            driver.executeScript("var radioObj = document.querySelectorAll('a');  radioObj[10].click(); ");
            new WebDriverWait(driver, 7).until((ExpectedCondition<Boolean>) wd ->
                    ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
            driver.executeScript("var  radioObj = document.querySelectorAll('a');  radioObj["+ page_index_value +"].click()");
            WebDriverWait wait = new WebDriverWait(driver, 60);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(page_amount_id)));
            this.setMessage("Mask fields");
            if(!isBOC){
                driver.executeScript("var way = document.querySelectorAll('#rd_trans_mode_1');for(var i = 0;i < way.length;i++){ way[i].checked = true;  }");
            }
            driver.executeScript("$('#"+ page_amount_id  +"').after('<div class=\"payment-masker\" style=\"position:absolute; left:696px;  width:100px !important; height:32px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
            driver.executeScript("$('#"+ page_transinaccparent_id +"').after('<div class=\"payment-masker\" style=\"position:absolute; left:696px;  width:100px !important; height:32px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");

            WebElement   ele3= driver.findElement(By.id(page_amount_id));
            ele3.sendKeys(amount.toString());
            ele3= driver.findElement(By.id(page_payeename_id));
            ele3.sendKeys(accountName);
            ele3= driver.findElement(By.id(page_transinaccparent_id));
            ele3.sendKeys(accountNumber);
            ele3.click();
            sleep(3000);
            if(isBOC){
                this.setMessage("Click 下一步");
                ele3 = driver.findElement(By.id("trans_tips_ca_180528"));
                ele3.click();
                driver.executeScript("document.getElementById('btnBocTransferNext').click()");
            }else{
                try{
                    this.setMessage("Click 下一步");
                    driver.executeScript("document.getElementById('txt_transinaccparent_1601').blur()");
                    sleep(1300);
                    driver.executeScript("document.getElementById('btn_nextstep_1732').click()");
                } catch (UnhandledAlertException x){
                    this.setMessage("Click 下一步");
                    driver.executeScript("document.getElementById('txt_transinaccparent_1601').blur()");
                    sleep(1300);
                    driver.executeScript("document.getElementById('btn_nextstep_1732').click()");
                }
            }

            WebDriverWait wait2 = new WebDriverWait(driver, 15);
            wait2.until(ExpectedConditions.visibilityOfElementLocated(By.id("hideMsgBox")));
            // 清除USB 弹框
            this.setMessage("Click USB 确定");
            driver.executeScript("document.getElementById('hideMsgBox').click()");
            //收集费用
            String html = driver.executeScript("var radioObj = document.querySelectorAll('.clearfix');  return radioObj["+ page_charge_index +"].innerHTML").toString();

            JXDocument body =  JXDocument.create(html);
            String xpath = "//div/span/html()";
            List<Object> res =  body.sel(xpath);
            String bal = StringUtils.join(res, ",");
            System.out.println(bal);

            if(!(bal.length()>0)||bal.equals("免费")){
                taskLog.setCharge("0.0");
            }else {
                taskLog.setCharge(bal);
            }

            taskLog.setCharge("0.0");
            //确认
            driver.executeScript("document.getElementById('"+ page_submit_id +"').click()");
            sleep(8000);
            //输入usbPassword

            for(int i = 0;i < usbPassword.length(); i++) {
                press(usbPassword.substring(i,i+1).split(""), 100 + (int)(Math.random() * 100), 60);
            }
            press(new String[]{"Enter"}, 1000, 200);

            // 循环等待人点击U盾
            WebDriverWait wait3 = new WebDriverWait(driver, 60);
            int waitCount = 5;
            sleep(5000);
            while(waitCount > 0) {
                try {
                    wait3.until(ExpectedConditions.visibilityOfElementLocated(By.id( page_success_id )));
                    logger.info("本行代码已经执行,获取到成功标识");
                    ok = true;
                    break;
                } catch (TimeoutException e) {
                    waitCount -= 1;
                    logger.info("wait element timeout exception:" + e.getMessage());
                    e.printStackTrace();
                    break;
                }
                catch (Exception e) {
                    logger.info("wait exception:" + e.getMessage());
                }

            }


        } catch(Throwable x) {
            x.printStackTrace();
        }

        if(ok) {
            imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_success_.png";
            PcUtils.saveScreen(driver, imagePath);
            taskLog.setStatus(TaskLog.SUCCESS);
            taskLog.setImg(imagePath);

        }else {
            imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png";

            taskLog.setStatus(TaskLog.FAIL);
            taskLog.setImg(imagePath);
            new Thread(new Runnable() {
                public void run() {
                    PcUtils.open("a.wav");
                }
            }).start();
            PcUtils.captureScreen(this.code, id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png");
            throw new BankException("usbPassword_error", taskLog);
        }



        return taskLog;
    }





    public boolean checkTransfer(  BigDecimal amount   ) throws Exception {
        BigDecimal  oldBalance = balance;
        getPageBalance();

        if(balance.equals(oldBalance.subtract(amount))) {
            logger.info(" 转账是正确的 ");
            return true;
        } else {
            return false;
        }

    }

    @Override
    public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {

        TaskLog tasklog = null ;
        // 1. 执行转账
        try {
            tasklog =  doTransfer( id, bankName,accountNumber, accountName,  amount, memberBankProvince, memberBankCity, memberBankBranch );

        } catch(Throwable x) {

        }
        // 2. 验证转账
        try {

            if(checkTransfer(amount)) {
                tasklog.setStatus(TaskLog.SUCCESS);
            }
            logger.info("验证转账完毕");
        } catch(Throwable x) {

        }

        return tasklog;
    }

    @Override
    public void queryTransaction() throws Exception {
        driver.switchTo().window(windowHandle);
    }


    private TaskLog fillHandle(BigDecimal id,TaskLog taskLog, String imageName) {
        String  imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_" + imageName + "_.png";
        PcUtils.saveScreen(driver, imagePath);
        taskLog.setStatus(TaskLog.FAIL);
        taskLog.setImg(imagePath);
        new Thread(new Runnable() {
            public void run() {
                PcUtils.open("a.wav");
            }
        }).start();
        return taskLog;
    }





    public   void initCGBMessageBox() throws Exception {

       // driver.executeScript("$('body').after('<div id=\"payment-online-bank-message\" style=\"position:fixed;top: 300px;padding:10px; left:10px;width:300px;height:60px;background:#000000;color:#FFFFFF;  font-size:18px;  \">init</div>')" );

    }
    public   void CGBMessageBox(String message) throws Exception {

        //driver.executeScript("$('#payment-online-bank-message').html('" + message + "');");

    }
}
