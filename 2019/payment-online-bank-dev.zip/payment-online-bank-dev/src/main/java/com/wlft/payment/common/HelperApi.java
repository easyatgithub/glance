package com.wlft.payment.common;

import com.wlft.payment.exception.HttpException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class HelperApi {

    private static Logger logger = Logger.getLogger(HelperApi.class);

    public static HttpClient httpClient = new HttpClient();

    //后台记录
    private static String BACKEND_RECORD = "http://wlft.bank-web-app.sit:7002/payment/record/";

    // 验证码服务商 2captcha
    private static String URL_IN_2CAPTCHA = "http://2captcha.com/in.php";
    private static String URL_RES_2CAPTCHA = "http://2captcha.com/res.php";
    private static String KEY_2CAPTCHA = "5e509a9dd13eced8ea4bfadd111c0944";

    public static void record(String user, String fromAcount, String toAcount, String amount, String state, String bank, String taskId, String startTime, String endTime) {
        NameValuePair[] data = {
                new NameValuePair("user", user),
                new NameValuePair("fromAcount", fromAcount),
                new NameValuePair("toAcount", toAcount),
                new NameValuePair("amount", amount),
                new NameValuePair("bank", bank),
                new NameValuePair("state", state),
                new NameValuePair("taskId", taskId),
                new NameValuePair("startTime", startTime),
                new NameValuePair("endTime", endTime)
        };
        try {
            HttpUtils.post(BACKEND_RECORD, data, "");
        } catch (Throwable e) {

        }
    }

    public static String sendBase64To2captcha(String imageBase64) throws HttpException {
        String codeId = "";
        NameValuePair[] data = {
                new NameValuePair("method", "base64"),
                new NameValuePair("key", KEY_2CAPTCHA),
                new NameValuePair("body", imageBase64)
        };

        String res = HttpUtils.post(URL_IN_2CAPTCHA, data, "");
        if (res.indexOf("|") > 0) {
            codeId = res.split("\\|")[1];
        }

        return codeId;
    }

    public static String getCodeFrom2captcha(String codeId) throws HttpException {
        String code = "";
        String res = HttpUtils.sendGet(URL_RES_2CAPTCHA, "key=" + KEY_2CAPTCHA + "&" + "action=get&id=" + codeId);

        if (res.indexOf("|") > 0) {
            code = res.split("\\|")[1];
        }

        return code;
    }
}
