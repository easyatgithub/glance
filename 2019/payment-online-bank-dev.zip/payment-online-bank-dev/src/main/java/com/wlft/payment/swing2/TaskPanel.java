package com.wlft.payment.swing2;

import static com.wlft.payment.common.FormatUtils.AMOUNT_FORMATTER;
import static com.wlft.payment.common.FormatUtils.NUMBER_FORMATTER;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.wlft.payment.common.Config;

public class TaskPanel extends JPanel {

	//	serialVersionUID
	private static final long serialVersionUID = 5459821399445649875L;
	//	log
	private static final Logger logger = Logger.getLogger(TaskPanel.class);

	private static final Integer HEIGHT = 250;
	
	//	是否自動
	private boolean isAuto;
	
	private JLabel waitingLabel = new JLabel();
	
	private JButton playButton = new JButton();
	
	private JButton pauseButton = new JButton();
	
	private JButton stopButton = new JButton();
	
	private JButton memoriesButton = new JButton();
	
	private JLabel refreshLabel = new JLabel(Config.refreshTime + "s");
	
	private JTable taskTable;
	
	private TaskDetailPanel taskDetailPanel = new TaskDetailPanel();
	
	private Integer refreshCounter = Config.refreshTime;
	
	private static final Map<String, ImageIcon> ICON_MAP = new HashMap<String, ImageIcon>();
	
	static {
		Image img = null;

		try {
			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-play-24.png"));
			ICON_MAP.put("play", new ImageIcon(img));
			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-play-24-gray.png"));
			ICON_MAP.put("dis-play", new ImageIcon(img));

			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-stop-24.png"));
			ICON_MAP.put("stop", new ImageIcon(img));
			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-stop-24-gray.png"));
			ICON_MAP.put("dis-stop", new ImageIcon(img));

			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-pause-24.png"));
			ICON_MAP.put("pause", new ImageIcon(img));
			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-pause-24-gray.png"));
			ICON_MAP.put("dis-pause", new ImageIcon(img));

			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-memories-24.png"));
			ICON_MAP.put("memories", new ImageIcon(img));
			img = ImageIO.read(TaskPanel.class.getResource("icons/icons8-memories-24-gray.png"));
			ICON_MAP.put("dis-memories", new ImageIcon(img));
		} catch (IOException e) {
			logger.error(e);
		}
	}
	
	public TaskPanel() {

		//	設定布局
		setLayout(new BorderLayout());
		
		try {
			this.initControlPanel();
			
			this.initMainPanel();
		}catch(Exception e) {
			logger.error(e);
		}
	}
	
	public void initControlPanel() throws IOException {
		JPanel panel = new JPanel();
		JLabel tempLabel = null;
		FlowLayout flowLayout = new FlowLayout(FlowLayout.LEFT, 3, 3);
		
		panel.setLayout(flowLayout);
		panel.setBorder(BorderFactory.createEtchedBorder());
		add(panel, BorderLayout.NORTH);
		
		//	waiting time
		panel.add(new JLabel("Waiting Time:"));
		panel.add(this.waitingLabel);
		this.setWaitingTime(Config.waitingTime);
		
		//	slider
		JSlider slider = new JSlider(JSlider.HORIZONTAL, 3, 15, Config.waitingTime);
		slider.setPreferredSize(new Dimension(120, 27));
		slider.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				setWaitingTime(slider.getValue());
			}
			
		});
		panel.add(slider);
		
		//	play
		playButton.setIcon(ICON_MAP.get("dis-play"));
		playButton.setEnabled(false);
		panel.add(playButton);
		
		//	pause
		pauseButton.setIcon(ICON_MAP.get("dis-pause"));
		pauseButton.setEnabled(false);
		panel.add(pauseButton);
		
		//	stop
		stopButton.setIcon(ICON_MAP.get("dis-stop"));
		stopButton.setEnabled(false);
		panel.add(stopButton);
		
		//	memories
		memoriesButton.setIcon(ICON_MAP.get("dis-memories"));
		memoriesButton.setEnabled(false);
		panel.add(memoriesButton);
		
		tempLabel = new JLabel("                                                     ");
		panel.add(tempLabel);
		
		tempLabel = new JLabel("Refresh Time:");
		panel.add(tempLabel);
		
		panel.add(refreshLabel);
	}
	
	public void initMainPanel() {
		JPanel leftPanel = new JPanel(new BorderLayout());
		JPanel rightPanel = new JPanel(new BorderLayout());
		JPanel tempPanel;
        JSplitPane splitPane = new JSplitPane();
        ButtonGroup group = new ButtonGroup();
        JRadioButton radioButton = null;
        
        leftPanel.setPreferredSize(new Dimension(PaymentFrame2.WIDTH / 4, HEIGHT));
        splitPane.setLeftComponent(leftPanel);
        splitPane.setRightComponent(rightPanel);
		add(splitPane, BorderLayout.CENTER);
        
        //  new JTable
        JTable table = this.taskTable = new JTable(new TableModel()){

            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component comp = super.prepareRenderer(renderer, row, column);

                //  Withdrawal Today column
                if(isRowSelected(row) && column != 5){
                    comp.setBackground(Config.SELECTED_COLOR);
                }else{
                    comp.setBackground(null);
                }
                return comp;
            }
        };
        //  設定欄位高度
        table.setRowHeight(30);
        table.setIntercellSpacing(new Dimension(5, 5));

        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        TableCellRenderer buttonRenderer = new JTableButtonRenderer();

        //  Pri
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        //  Request Time
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        //  Pending
        table.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(2).setPreferredWidth(60);
        //  Merchant
        table.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        table.getColumnModel().getColumn(3).setPreferredWidth(110);
        //  Amount
        table.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
        table.getColumnModel().getColumn(4).setPreferredWidth(110);
        //  Button
        table.getColumnModel().getColumn(5).setCellRenderer(buttonRenderer);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
		
		leftPanel.add(table, BorderLayout.NORTH);
		
		//	Auto / Manual
		tempPanel = new JPanel(new FlowLayout());
        leftPanel.add(tempPanel, BorderLayout.SOUTH);
		//	Auto
		radioButton = new JRadioButton("Auto");
		radioButton.setActionCommand("auto");
		radioButton.setMnemonic(KeyEvent.VK_A);
		radioButton.setSelected(true);
		radioButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				setAutoManual(e.getActionCommand() == "auto");
			}
			
		});
        group.add(radioButton);
        tempPanel.add(radioButton);
        //	Manual
		radioButton = new JRadioButton("Manual");
		radioButton.setActionCommand("manual");
		radioButton.setMnemonic(KeyEvent.VK_M);
		radioButton.setSelected(true);
		radioButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				setAutoManual(e.getActionCommand() == "auto");
			}
			
		});
        group.add(radioButton);
        tempPanel.add(radioButton);

        //	task detail panel
        rightPanel.add(this.taskDetailPanel, BorderLayout.NORTH);
	}
	
	/**
	 * 設定等待時間
	 * @param waitingTime 等待時間
	 */
	public void setWaitingTime(Integer waitingTime) {
		Config.waitingTime = waitingTime != null ? waitingTime : 3;
		this.waitingLabel.setText(Config.waitingTime < 10 ? "  " + Config.waitingTime + "s " : Config.waitingTime + "s ");
	}
	
	public void setAutoManual(boolean isAuto) {
		this.isAuto = isAuto;
	}
	
	public void reloadTaskData(){
		
	}

    private class JTableButtonRenderer implements TableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JButton button = (JButton)value;
            return button;
        }
    }

    private class TableModel extends AbstractTableModel {

        private String[] columnNames = {"Pri", "Request Time", "Pending(min.)", "Account", "Amount", ""};

        private Class<?>[] COLUMN_TYPES = {Integer.class, String.class, String.class, String.class, String.class, JButton.class};

        private JSONArray data;

        public TableModel(){
            this(new JSONArray());
        }

        public TableModel(JSONArray data){
            setData(data);
        }

        public void setData(JSONArray data){
            this.data = data != null ? data : new JSONArray();
        }

        @Override
        public int getRowCount() {
            return data.length();
        }

        @Override
        public int getColumnCount() {
            return columnNames.length;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            JSONObject rows = data.getJSONObject(rowIndex);

            switch (columnIndex){
                case 0:
                    return rows.getInt("priority");
                case 1:
                    return rows.getString("time");
                case 2:
                    return NUMBER_FORMATTER.format(rows.getInt("pendingTime"));
                case 3:
                    return rows.getString("toAcct");
                case 4:
                    return AMOUNT_FORMATTER.format(new BigDecimal(rows.getString("param1")));
                case 5:
                    return new JButton("Pay");
                default:
                    return "";
            }
        }

        @Override
        public String getColumnName(int col) {
            return columnNames[col];
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return COLUMN_TYPES[columnIndex];
        }

        public JSONObject getRow(int row){
            return data.getJSONObject(row);
        }
    }
}
