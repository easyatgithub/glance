package com.wlft.payment.swing;

import com.wlft.payment.common.Operator;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import com.wlft.payment.common.PcUtils;
import org.apache.log4j.Logger;

public class PaymentFrame extends JFrame implements WindowListener {
	
    //	serialVersionUID
	private static final long serialVersionUID = 1L;
	//	log
	private final Logger logger = Logger.getLogger(PaymentFrame.class);
	//	console log
    private final Logger consoleLogger = Logger.getLogger(getClass().getName() + ".log");
    //  file的日誌
    private static final String INFO = "info";
    //  file的錯誤日誌
    private static final String ERROR = "error";
    //  標題
    private static String TITLE = "Online Bank Helper(0624)";
    //  寬
    public static final int WIDTH = 500;
    //  高
    public static final int HEIGHT = 550;
    //  用戶資訊
    private Operator operator;
    //  主要的panel
    private JPanel mainPanel;
    //  訊息
    private JTextPane messagePane;
    //  登入頁
    private LoginPanel loginPanel;
    // 銀行卡選擇頁
    private BankSelectPanel bankSelectPanel;
    // 任務領取頁
    private TaskSelectPanel taskSelectPanel;
    //  日志页面
    private TaskLogPanel taskLogPanel;

    public PaymentFrame() {
    	
        //  設定標題
        super(TITLE);

        //  設定預設關閉的方式
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //  設定寬高
        setSize(new Dimension(WIDTH, HEIGHT));
        //  不可變形
        setResizable(false);
        //  永遠置頂
        setAlwaysOnTop(true);
        //  顯示在最左上角
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(screenSize.width - WIDTH, 0);
        //  綁定監聽器
        this.addWindowListener(this);

        //  運營人員
        this.operator = new Operator();

        //  mainPanel
        mainPanel = new JPanel(new CardLayout());
        mainPanel.setBounds(0, 0, WIDTH, HEIGHT);
        
        // 登入頁
        this.loginPanel = new LoginPanel(this.operator, this, WIDTH, HEIGHT);
        mainPanel.add(this.loginPanel, LoginPanel.nickname);
        
        // 銀行卡選擇頁
        this.bankSelectPanel = new BankSelectPanel(this.operator, this, WIDTH, HEIGHT);
        mainPanel.add(this.bankSelectPanel,BankSelectPanel.nickname);

        // 任務領取頁
        this.taskSelectPanel = new TaskSelectPanel(this.operator, this, WIDTH, HEIGHT);
        mainPanel.add(this.taskSelectPanel, TaskSelectPanel.nickname);
        
        // log頁
        this.taskLogPanel = new TaskLogPanel(this.operator, this, WIDTH, HEIGHT);
        mainPanel.add(this.taskLogPanel, TaskLogPanel.nickname);

        //	主頁
        add(mainPanel, BorderLayout.CENTER);

        //  messagePanel
        this.messagePane = new JTextPane();
        this.messagePane.setBorder(BorderFactory.createLoweredBevelBorder());
        this.messagePane.setBounds(0, 0, WIDTH, 70);

        JScrollPane scrollPane = new JScrollPane(this.messagePane, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        JPanel panel = new JPanel();
        scrollPane.setPreferredSize(new Dimension(WIDTH - 13, 70));
        panel.setPreferredSize(new Dimension(WIDTH, 70));
        panel.add(scrollPane, BorderLayout.CENTER);
        add(panel, BorderLayout.SOUTH);
    }

    public LoginPanel getLoginPanel(){
        return this.loginPanel;
    }

    public BankSelectPanel getBankSelectPanel(){
        return this.bankSelectPanel;
    }

    public TaskSelectPanel getTaskSelectPanel(){
        return this.taskSelectPanel;
    }

    public TaskLogPanel getTaskLogPanel(){
        return this.taskLogPanel;
    }

    public void show(String name){
        CardLayout c1 = (CardLayout) mainPanel.getLayout();
        c1.show(mainPanel, name);
    }

    public void windowOpened(WindowEvent e) {
    	logger.debug("windowOpened");
    }

    public void windowClosing(WindowEvent e) {
        // 关闭线程
        getTaskSelectPanel().stopRunner();
        //  操作人員登出
        operator.logout();
        //	刪除所有後端進程
        PcUtils.taskkill();
    }

    public void windowClosed(WindowEvent e) {
        logger.debug("windowClosed");
    }

    public void windowIconified(WindowEvent e) {
    	logger.debug("windowIconified");
    }

    public void windowDeiconified(WindowEvent e) {
    	logger.debug("windowDeiconified");
    }

    public void windowActivated(WindowEvent e) {
    	logger.debug("windowActivated");
    }

    public void windowDeactivated(WindowEvent e) {
    	logger.debug("windowDeactivated");
    }

    /**
     *  顯示錯誤訊息
     * @param message - 訊息
     */
    public void setErrorMessage(String message){
        this.setMessage(ERROR, message, Color.RED, null);
    }


    /**
     *  顯示錯誤訊息
     * @param message - 訊息
     */
    public void setErrorMessage(String message, Throwable throwable){
        this.setMessage(ERROR, message, Color.RED, throwable);
    }

    /**
     * 顯示訊息
     * @param message - 訊息
     */
    public void setMessage(String message){
        this.setMessage(INFO, message, Color.BLACK, null);
    }

    /**
     * 顯示訊息
     * @param message - 訊息
     */
    private void setMessage(String level, String message, Color color, Throwable throwable){
        StyledDocument doc = this.messagePane.getStyledDocument();
        Style style = this.messagePane.addStyle("Color Style", null);
        StyleConstants.setForeground(style,color);
        try {
            doc.insertString(doc.getLength(), message + "\n", style);
            if(this.isVisible()) {
            	this.messagePane.setCaretPosition(doc.getLength());
            }
            if(level.equals(INFO)){
            	consoleLogger.info(message);
            }else if(level.equals(ERROR) && throwable != null){
            	consoleLogger.error(message);
            }else{
            	consoleLogger.error(message);
            }
        }catch (BadLocationException e) {
        	logger.error(e);
        }
    }
}