package com.wlft.payment.bank;

import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;

import com.wlft.payment.exception.BankException;
import org.openqa.selenium.*;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import tcg.windowDetecter.contracts.BankEnum;
import tcgWindow.Box;
import tcgWindow.BoxPoint;

import java.awt.*;
import java.awt.event.InputEvent;
import java.io.File;
import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;
import static io.github.seleniumquery.SeleniumQuery.$;
import static java.lang.Thread.sleep;

public abstract class OnlineBank {

    //  銀行代碼
    protected String code = "";
    //  銀行卡ID
    protected Integer id;
    //  銀行卡代碼
    protected String accountCode;
    //  餘額
    protected BigDecimal balance;
    //  帳號
    protected String username;
    //  登入密碼
    protected String password;
    //  轉帳密碼
    protected String queryPassword;
    //  U盾密碼
    protected String usbPassword;
    //  Robot
    protected Robot robot;
    //  selenium
    protected RemoteWebDriver driver;
    //  main window handle
    protected String windowHandle;
    //  Default browser
    protected String browser = IE;
    // 页面驱动密码界面信息
    protected BoxPoint boxPoint;

    public static final String IE = "IEDriverServer.exe";

    public static final String FIRE_FOX = "";

    public static final String CHROME = "";

    public OnlineBank(String code, Integer id, String accountCode, String hostname, Integer port) {
        this.code = code;
        this.setId(id);
        this.setAccountCode(accountCode);
        this.createDriver(hostname, port);

        //  產生機器人
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    /**
     * 網銀登入
     */
    public abstract void login(String username, String password, String queryPassword, String usbPassword) throws Exception;

    /**
     * 網銀登出
     */
    public abstract void logout() throws Exception;

    /**
     * 確認餘額
     */
    public abstract void checkBalance(BigDecimal balance) throws Exception;

    /**
     * 查询页面餘額
     */
    public abstract BigDecimal getPageBalance() throws Exception;

    /**
     * 轉帳
     */
    public abstract TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount, String memberBankProvince, String memberBankCity, String memberBankBranch) throws Exception;

    /**
     * 查詢交易紀錄
     */
    public abstract void queryTransaction() throws Exception;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return this.id;
    }

    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    public String getAccountCode() {
        return this.accountCode;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public void setLoginInfo(String username, String password, String queryPassword, String usbPassword) {
        this.username = username == null ? username : username.trim();
        this.password = password == null ? password : password.trim();
        this.queryPassword = queryPassword == null ? queryPassword : queryPassword.trim();
        this.usbPassword = usbPassword == null ? usbPassword : usbPassword.trim();
    }

    public void open(String url) throws Exception {

        //  開啟網銀頁面
        driver.get(url);

        //  监测设备是否大写锁定
        if (PcUtils.capsLock()) {
            //  press(new String[]{"CapsLock"}, 200, 50);
        }

        try {
            //  設定螢幕座標
            driver.manage().window().setPosition(new Point(0, 0));
            //  設定螢幕大小
            driver.manage().window().setSize(new org.openqa.selenium.Dimension(1125, 830));

            //  focus window
            String currentWindow = driver.getWindowHandle();
            driver.switchTo().window(currentWindow);
            // add
        } catch (Throwable e) {

        }
    }

    public void initMessageBox() {
        String currentHandle = driver.getWindowHandle();

        ((RemoteWebDriver) driver.switchTo().window(windowHandle)).executeScript("" +
                "$(document).ready(function(){if(!$('#payment-online-bank-message').html()){" +
                "   $('body').append('<div id=\"payment-online-bank-message\" style=\"position:fixed; " +
                "top: 300px; " +
                "left:10px; " +
                "width:300px; " +
                "height:60px; " +
                "padding:10px; " +
                "background:#000000; " +
                "z-index:999;" +
                "line-height:20px; " +
                "font-size:18px; " +
                "color:#FFFFFF; " +
                "\"></div>');}" +
                "});");

        driver.switchTo().window(currentHandle);
    }

    public void initPending() {
        String currentHandle = driver.getWindowHandle();

        ((RemoteWebDriver) driver.switchTo().window(windowHandle)).executeScript(
                "window.tcgPendingFlag = false;");
        ((RemoteWebDriver) driver.switchTo().window(windowHandle)).executeScript(
                "   $('body').append('<div id=\"payment-online-bank-status\" style=\"position:fixed; " +
                        "top: 400px; " +
                        "left:10px; " +
                        "width:50px; " +
                        "height:50px; " +
                        "border-radius: 25px; " +
                        "text-align:center; " +
                        "background:#FF0000; " +
                        "line-height:50px; " +
                        "font-size:16px; " +
                        "cursor: pointer; " +
                        "z-index:999;" +
                        "color:#FFFFFF; \">Run</div>');");
        ((RemoteWebDriver) driver.switchTo().window(windowHandle)).executeScript(
                "$(window).on(\"keypress\",function(e){if(e.keyCode == 27){window.tcgPendingFlag = !window.tcgPendingFlag; $(\"#payment-online-bank-status\").text(window.tcgPendingFlag ? 'Pause': 'Run');};});");

        driver.switchTo().window(currentHandle);
    }

    /**
     * 顯示訊息
     *
     * @param message 訊息
     */
    public void setMessage(String message) {
        ((RemoteWebDriver) driver.switchTo().window(windowHandle)).executeScript("$('#payment-online-bank-message').html('" + message + "');");
    }

    protected void createDriver(String hostname, Integer port) {

        if (browser == IE) {
            String driverPath = System.getProperty("user.home") + File.separator + browser;
            System.setProperty("webdriver.ie.driver", driverPath);

            InternetExplorerOptions options = new InternetExplorerOptions();
            options.ignoreZoomSettings();
            options.requireWindowFocus();
            setProxy(options, hostname, port);
            driver = new InternetExplorerDriver(options);
            //	設定頁面載入最大的等待時間
            driver.manage().timeouts().pageLoadTimeout(90, TimeUnit.SECONDS);
            //	設定元件顯示最大的等待時間
            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
            $.driver().use(driver);
        } else if (browser == CHROME) {
            // ChromeDriver options = new ChromeDriver();
        } else if (browser == FIRE_FOX) {
            // FirefoxDriver options = new FirefoxDriver();

        }
        //  記錄該driver的windowHandle，供後續使用
        windowHandle = driver.getWindowHandle();
    }

    /**
     * 等待頁面載入完成
     */
    protected void waiting() {
        try {
            new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd ->
                    ((JavascriptExecutor) wd).executeScript("return document.readyState;").equals("complete"));
        } catch (Throwable e) {

        }
    }

    /**
     *
     */
    protected void checkPending() {
        boolean flag = true;

        while (flag) {
            Object ret = ((RemoteWebDriver) driver.switchTo().window(windowHandle)).executeScript("return window.tcgPendingFlag;");
            flag = ret.equals("true");
        }
    }

    protected void showBalance(String bal ,BigDecimal balance) {
        if (bal.length() > 0) {
            this.balance = new BigDecimal(bal);
        } else {
            this.balance = balance;// 取不到 页面余额 用系统余额设置余额 使程序能执行转账
        }
        if (this.balance.compareTo(balance) != 0) {
            setMessage("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
        } else {
            setMessage("Balance:" + bal);
        }


    }

    /**
     * 模擬滑鼠移動
     *
     * @param x - X軸
     * @param y - Y軸
     */
    public void move(Integer x, Integer y) {
        //  切回主畫面
        driver.switchTo().window(windowHandle);
        org.openqa.selenium.Point windowPosition = driver.manage().window().getPosition();
        Long outerHeight = (Long) driver.executeScript("return window.outerHeight;");  // window.innerWidth; 不一定有定义
        Long outerWidth = (Long) driver.executeScript("return window.outerWidth;");
        Long innerHeight = (Long) driver.executeScript("return window.innerHeight;");
        Long innerWidth = (Long) driver.executeScript("return window.innerWidth;");
        outerHeight = outerHeight == null ? (long) 0 : outerHeight;
        outerWidth = outerWidth == null ? (long) 0 : outerWidth;
        innerHeight = innerHeight == null ? (long) 0 : innerHeight;
        innerWidth = innerWidth == null ? (long) 0 : innerWidth;

        Integer offsetX = windowPosition.getX() + (outerWidth.intValue() - innerWidth.intValue()) - 10;
        Integer offsetY = windowPosition.getY() + (outerHeight.intValue() - innerHeight.intValue()) - 28;
        System.out.println((offsetX + x) + "," + (offsetY + y));
        robot.mouseMove(offsetX + x, offsetY + y);
    }

    /**
     * 模擬滑鼠點擊
     *
     * @param x - X軸
     * @param y - Y軸
     */
    public void click(Integer x, Integer y) {
        this.move(x, y);
        robot.mousePress(InputEvent.BUTTON1_MASK);  //模拟鼠标按下左键
        robot.mouseRelease(InputEvent.BUTTON1_MASK);    //模拟鼠标松开左键
    }

    /**
     * 模擬使用者輸入每個字元的頻率是不規律的動作
     */
    public void pressText(String text) {

        //	若是文字是空則結束
        if (text == null) {
            return;
        }

        for (int i = 0; i < text.length(); i++) {
            try {
                press(text.substring(i, i + 1).split(""), 300 + (int) (Math.random() * 100), 200);
            } catch (Exception e) {
            }
        }
    }

    /**
     * 關閉驅動
     */
    public void close() {
        if (driver != null) {
            driver.quit();
        }
    }

    /**
     * 設定代理
     *
     * @param hostname
     * @param port
     */
    protected void setProxy(MutableCapabilities options, String hostname, int port) {
        Proxy proxy = new Proxy();
        String[] noProxy = new String[]{
                "www.tcgpayment.com",
                "www.google.com",
                "translate.google.com",
                "jira.tc-gaming.co",
                "bsp.top1bsp.com",
                "windows10.microdone.cn",
                "https://ops.jeepayment.com",
                "https://e.bank.ecitic.com",
                "translate.google.com",
                "telegram",
                "www.google.com.hk",
                "http://wlft.bank-web-app.sit",
                "http://10.8.95.22:7001"
        };

        if (options instanceof InternetExplorerOptions) {
            InternetExplorerOptions o = (InternetExplorerOptions) options;
            o.ignoreZoomSettings();
            o.requireWindowFocus();
            proxy.setSslProxy(hostname + ":" + port);
            proxy.setNoProxy(String.join(";", noProxy));
            o.setProxy(proxy);
        }
    }
    /**
     * js给值并验证 最多循环3次 失败抛错
     *
     * @param putJs         - 给值的js 脚本
     * @param checkJs       - 检测值的js 脚本
     * @param expectedValue - 栏位的期望值
     */
    public void tryToPutValue(String putJs, String checkJs,String expectedValue) throws BankException {
        int count = 3;
        boolean run = true;
        String pageValue = "";
        while(run|| count >0){
            try {
                count --;
                driver.executeScript(putJs);
                driver.executeScript(checkJs).toString();
                run = driver.executeScript(checkJs).toString().equals(expectedValue);
                if(run){
                    break;
                }
            }catch (Throwable e){
                run = false;
            }
        }
        if(!run){
            throw  new BankException("EOO1-PUT-VALUE-ERROR");
        }
    }
    /**
     * 转账后的处理方法
     *
     * @param amount        - 本次转账金额
     * @param taskLog       - 日志记录
     * @param maxCharge     - 最大手续费
     */
    public TaskLog checkTransfer(  BigDecimal amount ,TaskLog taskLog,String maxCharge  ) throws Exception {
        BigDecimal  clacBalance = balance.subtract(amount);
        BigDecimal  realCharge;
        BigDecimal  oldBalance = balance;
        getPageBalance();

        if(balance.compareTo(oldBalance.subtract(amount)) < 1 ) {
            taskLog.setStatus(TaskLog.SUCCESS);
            realCharge = clacBalance.subtract(balance);
            if(realCharge.signum()>-1 && realCharge.subtract(new BigDecimal(maxCharge)).signum() == -1 ){ // BOC 目前常转的记录 最高 18元手续费
                taskLog.setCharge(realCharge.toString());
            }

        }
        return taskLog;
    }
    /**
     * 转账后的处理方法
     *
     * @param check         - 判断的条件
     * @param id            - 任务的id
     * @param taskLog       - 日志记录
     */
    public TaskLog   handleCheck(boolean check, BigDecimal id ,TaskLog taskLog) throws Exception {
        String imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_success_.png";
        if (check) {
            this.setMessage("// taskLog charge ="+ taskLog.getCharge());
            PcUtils.saveScreen(driver, imagePath);
            taskLog.setStatus(TaskLog.SUCCESS);
            taskLog.setImg(imagePath);
        }else {
            imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png";
            taskLog.setStatus(TaskLog.FAIL);
            taskLog.setImg(imagePath);
            PcUtils.sound();
            PcUtils.captureScreen(this.code, id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png");
        }

        return   taskLog;
    }
    /**
     * 等待页面元素出现
     * @param id            - 元素id
     */
    public void waitPageElement(String id,int time){
        try {
            WebDriverWait wait = new WebDriverWait(driver, time);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
        } catch (Throwable e) {
        }

    }

    /**
     * 等待页面元素出现
     * @param js           - 页面执行的js
     */
    public String  pageJS(String js){
        String respone="";
        try {
            respone = driver.executeScript(js).toString();
        } catch (Exception e) {
        }
        return  respone;
    }

    /**
     * 等待页面 变化
     * @param js           - 判断变化执行的js
     * @param js           - 判断变化应包含的关键词
     * @param waitTime     - 等待时间
     */
    public void   waitPageChange(String js,String keyWords,int waitTime) throws Exception{
        while (waitTime>0) {
            sleep(1000);
            waitTime -- ;
            if (pageJS(js).contains(keyWords)|| waitTime == 0 ) {
                break;
            }
        }
    }
    /**
     *   截屏获取页面 驱动密码框信息
     * @param bank            - 银行编码
     */
    public void getPgaeBox(BankEnum bank, double deg){
        Box box = new Box();
        this.boxPoint =  box.getPoints(bank,deg);
    }

}
