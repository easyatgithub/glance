package com.wlft.payment.common;

import com.ice.jni.registry.RegDWordValue;
import com.ice.jni.registry.Registry;
import com.ice.jni.registry.RegistryKey;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import javax.imageio.ImageIO;
import javax.sound.sampled.*;
import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Base64;
import static java.lang.Thread.sleep;

public class PcUtils {
 
	private static final Logger logger = Logger.getLogger(PcUtils.class);

    public  static void open(String arg)   {
        try {
            URL uri = ClassLoader.getSystemResource(arg);
            AudioInputStream audioIn = AudioSystem.getAudioInputStream( uri  );
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            clip.start();
            sleep(clip.getFrameLength());
        } catch (UnsupportedAudioFileException e) {
        	logger.error(e);
        } catch (IOException e) {
        	logger.error(e);
        } catch (LineUnavailableException e) {
        	logger.error(e);
        } catch (Exception e) {
        	logger.error(e);
        }
    }

    /**
         * 判斷是否開啟大寫
         * @return
         */
    public static boolean capsLock( ) {
        return Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK);
    }

    public static File saveScreen(RemoteWebDriver driver, String pathName ) {
        File screen = null;
        
        try {
        	screen = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screen,new File(Config.get("output.path") + pathName));
        } catch (Exception e) {
        	logger.error(e);
        }
        return screen;
    }

    public static void saveElementScreen(RemoteWebDriver driver, File Screen, WebElement element, String pathName) {
        try {
            int width = element.getSize().getWidth();
            int height = element.getSize().getHeight();
            BufferedImage ScreenImg = ImageIO.read(Screen);
            Point p = element.getLocation();
            BufferedImage elementImg = ScreenImg.getSubimage(p.getX(), p.getY(), width, height);
            ImageIO.write(elementImg, "png", Screen);
            FileUtils.copyFile(Screen,new File(pathName));
        } catch (Exception e) {
        	logger.error(e);
        }
    }

    public static void openFile(String pathName) {
        try {
            File file = new File(pathName);
            Desktop.getDesktop().open(file);
            Desktop.getDesktop().open(file.getParentFile());
        } catch (Exception e) {
        	logger.error(e);
        }
    }

    public static void openFileFolder(String pathName) {
        try {
            File file = new File(pathName);
            Desktop.getDesktop().open(file.getParentFile());
        } catch (Exception e) {
        	logger.error(e);
        }
    }

    public static boolean mkDirectory(String path) {
        try {
            File file = new File(path);
            
            if (!file.exists()) {
                return file.mkdirs();
            } else {
                return false;
            }
        } catch (Exception e) {
        	logger.error(e);
        }
        return false;
    }

    public static String readFile(String pathname) {
        StringBuilder builder = new StringBuilder();
        String line = null;

        try (
        	InputStreamReader isr = new InputStreamReader(new FileInputStream(new File(pathname)), "UTF-8");
        	BufferedReader br = new BufferedReader(isr)
        ){
            while((line = br.readLine()) != null) {
                builder.append(line + "\n");
            }
            return builder.toString();
        } catch(Exception e) {
        	logger.error(e);
            return null;
        }
    }

    /**
     * 將訊息寫入檔案
     * @param pathname - 檔案名稱
     * @param str - 訊息
     */
    public static void writeFile(String pathname,String str) {
        try (
        	FileOutputStream outSTr = new FileOutputStream(new File(pathname));
        	BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outSTr, "UTF-8"))
        ) {
            writer.write(str);
        } catch (Exception e) {
        	logger.error(e);
        }
    }

    /**
     * 關閉所有背景IE
     */
    public static void taskkill(){
        try {
            Runtime runtime = Runtime.getRuntime();
            runtime.exec(" taskkill /f /im IEDriverServer.exe");
        } catch (Exception e) {
        	logger.error(e);
        }
    }
    
    public static void extract(String fileName, String name) {
        if (new File(fileName).exists()) {
            return;
        }
        
        try(InputStream inputStream = PcUtils.class.getResourceAsStream("/" + name)) {
            Files.copy(inputStream, Paths.get(fileName), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
        	logger.error(e);
        }
    }
    
    public static File captureScreen(String folder,String fileName) throws Exception {
    	 
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle screenRectangle = new Rectangle(screenSize);
        Robot robot = new Robot();
        BufferedImage image = robot.createScreenCapture(screenRectangle);
        
        //	截图保存的路径 
        File screenFile = new File(Config.get("output.path") + "\\" + folder);
        
        //	如果路径不存在,则创建  
        if (!screenFile.getParentFile().exists()) {  
            screenFile.getParentFile().mkdirs();  
        } 
        
        //	判断文件是否存在，不存在就创建文件
        if(!screenFile.exists()&& !screenFile .isDirectory()) {
            screenFile.mkdir();
        }
        
        File f = new File(screenFile,fileName);
        ImageIO.write(image, "png", f);
        
        return new File(Config.get("output.path") + "\\" + folder + "\\" + fileName);     
    }

    public static String encodeImgageToBase64(String imagePath){
    	String base64Image = "";
    	File file = new File(imagePath);
    	
    	try (FileInputStream imageInFile = new FileInputStream(file)) {
    		byte imageData[] = new byte[(int) file.length()];
    		imageInFile.read(imageData);
    		base64Image = Base64.getEncoder().encodeToString(imageData);
    	} catch (Exception e) {
        	logger.error(e);
    	}
    	
        return base64Image;
    }

    /**
     * 获取电脑 进程列表
     */
    public static void getPressName() {
        long start = System.currentTimeMillis();
        logger.info(start);
        Process process = null;
        try {
            process = Runtime.getRuntime().exec("cmd.exe   /c   tasklist ");
            BufferedReader input = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = " ";
            while ((line = input.readLine()) != null) {
                logger.info(line);
            }
            input.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        long end = System.currentTimeMillis();
        logger.info("run time 程序运行时间： "+(end-start)+"ms");
    }
    public static void sound(){
        new Thread(new Runnable() {
            public void run() {
                PcUtils.open("a.wav");
            }
        }).start();
    }

    public static BufferedImage  getScreenBufferedImage(){
        Robot robot = null;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle screenRectangle = new Rectangle(screenSize);
        BufferedImage image = robot.createScreenCapture(screenRectangle);
        try{
            DateFormat format = new SimpleDateFormat("yyyyMMddhhmmss");
            ImageIO.write(image, "png", new File(Config.get("output.path") + "\\click_" +  format.format(System.currentTimeMillis() )));
        }catch (Exception e){

        }
        return image;
    }

    public static void  clickScreen(int x,int y){
        Robot robot = null;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
        if( x>0 && y>0 ) {
            robot.mouseMove(x, y);
            robot.mousePress(InputEvent.BUTTON1_MASK);
            robot.mouseRelease(InputEvent.BUTTON1_MASK);
        }
    }
    public static void adjustIEsetting( ) { // modify regedit about IE
        try {
            RegistryKey subKey = Registry.HKEY_CURRENT_USER.openSubKey("SOFTWARE");
            subKey = subKey.openSubKey("Microsoft\\Internet Explorer");
            subKey = subKey.createSubKey("Zoom", "");
            subKey.setValue(new RegDWordValue(subKey, "ZoomFactor", 4, 0x000124f8));// 75%

            subKey = Registry.HKEY_CURRENT_USER.openSubKey("SOFTWARE");
            subKey = subKey.openSubKey("Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones");

            subKey.createSubKey("1", "").setValue(new RegDWordValue(subKey, "2500", 4, 0x00000003));
            subKey.createSubKey("2", "").setValue(new RegDWordValue(subKey, "2500", 4, 0x00000003));
            subKey.createSubKey("3", "").setValue(new RegDWordValue(subKey, "2500", 4, 0x00000003));
            subKey.createSubKey("4", "").setValue(new RegDWordValue(subKey, "2500", 4, 0x00000003));
            subKey.closeKey();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}