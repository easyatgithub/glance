package com.wlft.payment;


import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seimicrawler.xpath.JXDocument;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import static io.github.seleniumquery.SeleniumQuery.$;

public class Test {

    public static final String IE = "IEDriverServer.exe";

    public static void main1(String[] args) throws Exception {


         String bal = "1,100,274.50,0.00";
         bal = bal.substring(0,bal.indexOf(".")+2);
        System.out.println(bal);


    }
    
    public static void main3(String[] args) {
    	String[] noProxy = new String[]{
                "www.tcgpayment.com",
                "www.google.com",
                "translate.google.com",
                "jira.tc-gaming.co",
                "bsp.top1bsp.com",
                "windows10.microdone.cn",
                "https://ops.jeepayment.com",
                "https://e.bank.ecitic.com",
                "translate.google.com",
                "telegram",
                "www.google.com.hk",
                "http://wlft.bank-web-app.sit",
                "http://10.8.95.22:7001"
        };
    	System.out.println(String.join(";", noProxy));
    }
    
    public static void main(String[] args) throws Exception {
        RemoteWebDriver driver;

        String driverPath = System.getProperty("user.home") + File.separator + IE;
        System.setProperty("webdriver.ie.driver", driverPath);

        //	Option setting
        InternetExplorerOptions options = new InternetExplorerOptions();
        options.ignoreZoomSettings();
        options.requireWindowFocus();
        driver = new InternetExplorerDriver(options);
        driver.manage().timeouts().pageLoadTimeout(91,TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(4,TimeUnit.SECONDS);
        $.driver().use(driver);
        
        //	Open page
        driver.get("http://www.wlft-team.com/test/index.html");
        
        WebDriverWait wait = new WebDriverWait(driver, 3);
        WebElement SearchText = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type='button']")));
        SearchText.click();
        //Object a = driver.executeScript("$(\"input[type='button']\").click()");
        //System.out.println(a);
    }

    public static void xx(String[] args) {

        Date s =new Date();
        SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        System.out.println(sdf.format(s));


        String html ="<tbody><tr class=\"list_table_content\"><td height=\"25\" align=\"center\" class=\"text_content\">1</td><td align=\"center\" class=\"text_content\">活期</td><td align=\"center\" class=\"text_content\"><a href=\"javascript:goDetail('6223356001985724','00017')\">00017</a></td><td align=\"center\" class=\"text_content\">人民币</td><td align=\"center\" class=\"text_content\">0.00</td><td align=\"center\" class=\"text_content\">0.00</td><td align=\"center\" class=\"text_content\">广西北部湾银行柳州分行营业部</td><td align=\"center\" class=\"text_content\">2018/02/27</td><td align=\"center\" class=\"text_content\"></td></tr>\n" +
                "</tbody>";
        System.out.println("html"+ html);
        JXDocument body =  JXDocument.create(html);//kabao-main

        String xpath = "//tr[1]/text()";
        List<Object> res =  body.sel(xpath);
        String bal = StringUtils.join(res, ",");
        bal = bal.replaceAll(",","");
        System.out.println("banlance "+ bal);
    }

}
