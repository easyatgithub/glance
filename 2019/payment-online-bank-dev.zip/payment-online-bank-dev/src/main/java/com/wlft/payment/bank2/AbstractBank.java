package com.wlft.payment.bank2;

public abstract class AbstractBank {

}
