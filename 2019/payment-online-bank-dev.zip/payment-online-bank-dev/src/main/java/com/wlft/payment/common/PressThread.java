package com.wlft.payment.common;


import static com.github.supermoonie.winio.VirtualKeyBoard.press;

// 输入驱动密码框时 总是密码还没输完后面代码就执行了 于是采用等待子线程完成的方式
public class PressThread extends  Thread{
    public String text ="";
    public  PressThread(String text){
        this.text= text;
    }
    public void run()
    {
        try {
            for (int i = 0; i < text.length(); i++) {
                press(text.substring(i, i + 1).split(""), 300 + (int) (Math.random() * 100), 200);
            }
            Thread.sleep(1000);
        } catch (Exception e)  {
            e.printStackTrace();
        }
    }
}