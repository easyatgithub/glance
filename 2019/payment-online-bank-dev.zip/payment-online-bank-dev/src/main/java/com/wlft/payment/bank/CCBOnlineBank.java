package com.wlft.payment.bank;

import javax.swing.*;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import com.wlft.payment.common.PressThread;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;
import tcg.windowDetecter.contracts.BankEnum;

import static java.lang.Thread.sleep;
import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;

public class CCBOnlineBank extends OnlineBank {
    private static Logger logger = Logger.getLogger(CCBOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {

        BANK_MAPPING.put("中国建设银行", "getBankInfo('ccb','中国建设银行')");
        BANK_MAPPING.put("工商银行", "getBankInfo('102100099996','中国工商银行') ");
        BANK_MAPPING.put("中国农业银行", "getBankInfo('103100000026','中国农业银行')");
        BANK_MAPPING.put("中国银行", "getBankInfo('104000000000','中国银行')");
        BANK_MAPPING.put("交通银行", "getBankInfo('301290000007','交通银行')");
        BANK_MAPPING.put("招商银行", "getBankInfo('308584000013','招商银行')");
        BANK_MAPPING.put("中国民生银行", "getBankInfo('305100000013','中国民生银行')");
        BANK_MAPPING.put("邮政储蓄", "getBankInfo('403100000004','邮政储蓄银行')");
        BANK_MAPPING.put("中信银行", "getBankInfo('302100011000','中信银行')");
        BANK_MAPPING.put("中国光大银行", "getBankInfo('303100000006','光大银行')");
        BANK_MAPPING.put("兴业银行", "getBankInfo('309391000011','兴业银行')");
        BANK_MAPPING.put("华夏银行", "getBankInfo('304100040000','华夏银行')");
        BANK_MAPPING.put("广发银行", "getBankInfo('306581000003','广发银行')");
        BANK_MAPPING.put("平安银行", "getBankInfo('307584007998','平安银行')");
        BANK_MAPPING.put("上海银行", "getBankInfo('325290000012','上海银行')");
        BANK_MAPPING.put("江苏银行", "getBankInfo('313301099999','江苏银行");
        BANK_MAPPING.put("华夏银行", "getBankInfo('304','华夏银行')");
        BANK_MAPPING.put("渤海银行", "getBankInfo('318110000014','渤海银行','3')");
        BANK_MAPPING.put("重庆银行股份有限公司", "getBankInfo('313653000013','重庆银行股份有限公司','3')");
        BANK_MAPPING.put("城市信用社", "getBankInfo('401','城市信用社','2')");
        BANK_MAPPING.put("广西北部湾银行", "getBankInfo('313611001018','广西北部湾银行股份有限公司','3')");
        BANK_MAPPING.put("上海浦东发展银行", "getBankInfo('310290000013','上海浦东发展银行','3')");
        BANK_MAPPING.put("西安银行", "getBankInfo('313791000015','西安银行','3')");

    }

    public CCBOnlineBank(Integer id, String accountCode, String hostname, Integer port) {
        super("CCB", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);

        //  初始化訊息框
        initMessageBox();
        // 这个 enter 可以清理代理弹框
        press(new String[]{"Enter"}, 100, 50);

        setMessage("Start 用户名登陆");
        // 赋值 用户名
        String js = "document.getElementById('fQRLGIN').contentDocument.getElementById('USERID').value='" + username + "'";
        driver.executeScript(js);
        js = "document.getElementById('fQRLGIN').contentDocument.getElementById('USERID').focus()";
        driver.executeScript(js);
        press(new String[]{"Tab"}, 100, 50);
        setMessage("Type password");
        // 输入 登陆密码
        pressText(password);
        // 输入密码后的全屏截图
        PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        // 获取页面密码(只有这个银行是个 input)
        String  pagePassword =  driver.executeScript(" return $('body').contents().find('#fQRLGIN').contents().find('#LOGPASS').val()").toString();

        // 密码正确的时 自动登陆
        if(pagePassword.equals(password)){
            logger.info("password is right and start login");
            press(new String[]{"Enter"}, 100, 50);
        }else{
            logger.info("password is error show msg");
            setMessage("password is  error please try login again ");
            return;
        }

        // 等待离开登陆页面
        int count = 30;
        while (true) {
            try{
                count -- ;
                sleep(1000);
                if (driver.getCurrentUrl().indexOf("login.jsp") == -1 || count == 0 ) {
                    break;
                }
            }catch(Throwable e){
                sleep(1000);
                driver.switchTo().alert().accept();
                break;
            }
        }


        driver.switchTo().window(windowHandle);
        // 读取新页面是否有 转账标签
        // 有则是进入新页 无则是认证或错误页面
        String tagOfTansfer  = pageJS("return  document.getElementById('MENUV6030104').innerHTML ");
        // 如果是进入的USBkey 认证页面
        if (driver.getCurrentUrl().indexOf("B2CMainPlat") > 0 && tagOfTansfer.length()< 2 ) {
            try {
                initMessageBox();
                setMessage(" auto input USBkey " );
                driver.manage().timeouts().setScriptTimeout(2, TimeUnit.SECONDS);
                driver.executeScript(" document.getElementById('mainfrm').contentDocument.getElementById('SafeTypeU').click()  ");
                sleep(300);
                driver.executeScript(" document.getElementById('mainfrm').contentDocument.getElementById('btnNext').click()  ");

            } catch (Throwable e) {
                logger.info(e.getMessage());
            }
            // 等待并输入密码
            sleep(10000);
            getPgaeBox(BankEnum.CCB,0.7);
            PcUtils.clickScreen(boxPoint.passwordX,boxPoint.passwordY);

            pressText(usbPassword);
            PcUtils.sound();
            sleep(2000);
            PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
            press(new String[]{"Enter"}, 100, 50);
            // 等待操作员按下 与页面刷新
            // 离开认证页面
            waitPageChange("return  document.getElementById('MENUV6030104').innerHTML ","a",60);
        }// end if

    }

    @Override
    public void logout() throws Exception {
        driver.executeScript(" $('#logout_a').click()");
        driver.switchTo().alert().accept();
        this.close();
    }
    public String getBal() {
        driver.executeScript("document.getElementById('MENUV6030104').click();");
        driver.switchTo().frame("txmainfrm");
        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("backnone")));
        driver.switchTo().window(windowHandle);
        String bal = driver.executeScript("return  document.getElementById('txmainfrm').contentDocument.getElementsByClassName('backnone')[0].innerText").toString();
        bal = bal.replaceAll(",", "");
        logger.info("bal = " + bal);
        return bal;
    }
    @Override
    public void checkBalance(BigDecimal balance) throws Exception {
        initMessageBox();
        setMessage("Fetch balance");
        //  跳回最外層，以保證之後的操作是正確的
        driver.switchTo().window(windowHandle);
        // 设置页面定时刷新 函数
        setAutoFlush();
        String bal = getBal();
        this.balance = new BigDecimal(bal);
        if (this.balance.compareTo(balance) != 0) {
            setMessage("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
        } else {
            setMessage("Balance:" + bal);
        }
    }

    @Override
    public BigDecimal getPageBalance() throws Exception {
        setMessage("Fetch balance");
        driver.switchTo().window(windowHandle);
        String bal = getBal();
        driver.executeScript("localStorage.setItem('run','run')");
        setMessage("Fetch balance = " + bal);
        this.balance = new BigDecimal(bal);
        return this.balance;
    }

    @Override
    public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount, String memberBankProvince, String memberBankCity, String memberBankBranch) throws Exception {

        String charge;
        TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        driver.switchTo().window(windowHandle);
        driver.executeScript("localStorage.setItem('run','false')");
        setMessage("Start transaction");
        // change page
        driver.executeScript("document.getElementById('MENUV6030104').click();");
        driver.switchTo().frame("txmainfrm");
        waitPageElement("TR_SKZHMC",15);

        driver.switchTo().window(windowHandle);
        driver.switchTo().frame("txmainfrm");
        //金额
        driver.executeScript("document.getElementById('txtTranAmt').value='" + amount + "'");
        //账户名
        driver.executeScript("document.getElementsByName('DELAY_FLAG')[0].click() ");
        String js = "document.getElementById('TR_SKZHMC').children(2).children(0).children(0).children(1).value='" + accountName + "';";
        String checkJs =      "return document.getElementById('TR_SKZHMC').children(2).children(0).children(0).children(1).value";
        tryToPutValue(js,checkJs,accountName);
        //账户号
        js = "document.getElementById('TR_SKZH').children(2).children(0).children(0).children(1).value='" + accountNumber +  "';";
        checkJs ="return document.getElementById('TR_SKZH').children(2).children(0).children(0).children(1).value";
        tryToPutValue(js,checkJs,accountNumber);

        logger.info("page value end");
        // 触发账户名
        driver.executeScript("document.getElementById('TR_SKZHMC').children(2).children(0).children(0).children(1).focus();");
        press(new String[]{"0"}, 200, 50);
        press(new String[]{"Backspace"}, 200, 50);
        click(30, 300);
        driver.switchTo().frame("txmainfrm");
        driver.executeScript("document.getElementById('TR_SKZHMC').children(2).children(0).children(0).children(1).blur();");

        // 触发账户
        driver.executeScript("document.getElementById('TR_SKZH').children(2).children(0).children(0).children(1).focus();");
        click(30, 300);
        driver.switchTo().frame("txmainfrm");
        driver.executeScript("document.getElementById('TR_SKZH').children(2).children(0).children(0).children(1).blur();");

        // 触发金额
        driver.executeScript("document.getElementById('txtTranAmt').focus();");
        driver.executeScript("document.getElementById('txtTranAmt').blur();");
        logger.info("page  amount triger end");
        // record page value
        logger.info("=============================>>>>record get back of page value");
        logger.info(driver.executeScript( "return  document.getElementById('TR_SKZHMC').children(2).children(0).children(0).children(1).value"));
        logger.info(driver.executeScript(  "return document.getElementById('TR_SKZH').children(2).children(0).children(0).children(1).value"));
        logger.info(driver.executeScript( "return document.getElementById('txtTranAmt').value"));

        // need mask
        driver.executeScript("$('#TR_SKZHMC').children(2).children(0).children(0).children(1).after('<div class=\"payment-masker\" style=\"position:absolute; left:55px; top:2px; width:100px; height:22px; display: inline-block; z-index: 100;background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div> ')");
        driver.executeScript("$('#TR_SKZH').children(2).children(0).children(0).children(1).after('<div class=\"payment-masker\" style=\"position:absolute; left:55px; top:2px; width:100px; height:22px; display: inline-block; z-index: 100;background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div> ')");
        driver.executeScript("$('.payment-masker').on('click', function(){var ans = prompt('Please enter password', ''); if(ans == 5201314){$('.payment-masker').remove();}})");

        // 转账加急方式
        driver.executeScript("document.getElementsByName('DELAY_FLAG')[0].click() ");

        //下一步
        pageJS("document.getElementById('subBut').click()");
        driver.switchTo().window(windowHandle);
        //sleep(4000);
        driver.switchTo().frame("txmainfrm");
        waitPageElement("MEMO",5);
        driver.switchTo().window(windowHandle);
        charge = pageJS("return document.getElementById('txmainfrm').contentDocument.getElementsByClassName('font_money')[1].innerText");

        logger.  info("get page charge = " + charge);

        charge = charge.split(";")[1]; //"FormatAmt("1.00");1.00"
        taskLog.setCharge(charge);
        logger.info("charge = " + charge);
        setMessage("get page charge = " + charge);
        // wait 提交
        // USB or SMS    短信验证码 bug
        String  way = pageJS("return document.getElementById('txmainfrm').contentDocument.getElementsByClassName('second_td')[0].innerHTML");
        if(!way.equals("选择认证方式")){
            logger.info("way = " + way);
            Object[] options = {"Yes,是的", "No,取消¦"}; // CCB  SMScode or  USE bey
            int sel =JOptionPane.showOptionDialog(null, " finish input some thing  ?", "询问 ", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options,null);
            if(sel != JOptionPane.YES_OPTION){
                return null;
            }
        }else{// auto run BY usb
            setMessage("get page charge = " + charge +" will auto run password " );
            driver.manage().timeouts().setScriptTimeout(2, TimeUnit.SECONDS);
            try{
                logger.info("before click");
                driver.executeScript("document.getElementById('txmainfrm').contentDocument.getElementsByClassName('btn')[7].click()");
                logger.info("end click");
            }catch (Throwable e){
                logger.info("js to click button record error" + e.getMessage());
            }
        }
        sleep(9000);
        logger.info("USBkey  USBkey password  start ");
        PcUtils.captureScreen(this.code, "page_driver_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        getPgaeBox(BankEnum.CCB,0.7);
        PcUtils.clickScreen(boxPoint.passwordX,boxPoint.passwordY);
        pressText(usbPassword);
        sleep(3000); // time to cancle
        PcUtils.captureScreen(this.code, "password_usb_2" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        press(new String[]{"Enter"}, 200, 50);

        // 循环等待 操作人员按下
        String tag = "";
        int waitTime = 20;
        while (waitTime>0) {
            try {
                waitTime--;
                sleep(1000);
                logger.info("setting showINFO item div show ");
                tag = driver.executeScript("return document.getElementById('txmainfrm').contentDocument.getElementsByClassName('four_column_table_padLR')[0].innerHTML").toString();
                if (tag.indexOf("凭证号") > 1) {
                    break;
                }
            } catch (Throwable x) {
                logger.info(" CCB wait successful cath  Throwable");
            }
        }
        try{ // 截图都是在发送请求的界面上 需要等待这个过程 截图截到有信息的页面
            driver.switchTo().frame("txmainfrm");
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("four_column_table_padLR")));
        }catch (Throwable e){
            logger.info("WAIT resultTab item TABLE show ");
        }
        PcUtils.captureScreen(this.code, "page_ccb_showINFO_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        //  检测
        taskLog = checkTransfer(amount,taskLog,"10.00");
        return handleCheck(taskLog.getStatus().equals(TaskLog.SUCCESS) || tag.indexOf("凭证号") > 1 ,id,taskLog) ;
    }

    public boolean checkTransfer(  BigDecimal amount   ) throws Exception {
        BigDecimal  oldBalance = balance;
        getPageBalance();

        if(balance.compareTo(oldBalance.subtract(amount)) < 1 ) {
            logger.info("transfer is true 转账是正确的 ");
            return true;
        } else {
            logger.info("transfer is false 转账是错误的  ");
            return false;
        }

    }
    @Override
    public void queryTransaction() throws Exception {

        //  跳回最外層，以保證之後的操作是正確的
        driver.switchTo().window(windowHandle);
    }

    private void setAutoFlush() {
        String js = " localStorage.setItem('run','run'); ";
        js += "setInterval(function(){";
        js += " if(localStorage.getItem('run') == 'run'){";
        js += " document.getElementById('MENUV6030104').click();";
        js += " }";
        js += " },160000) ";
        driver.executeScript(js);
    }
}
