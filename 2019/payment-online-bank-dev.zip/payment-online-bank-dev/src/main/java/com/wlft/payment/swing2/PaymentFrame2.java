package com.wlft.payment.swing2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;

import org.apache.log4j.Logger;

import com.wlft.payment.common.Operator;
import com.wlft.payment.swing.PaymentFrame;

public class PaymentFrame2 extends JFrame implements WindowListener, ActionListener {

	//	serialVersionUID
	private static final long serialVersionUID = 7061953269295384453L;
	//	log
	private final Logger logger = Logger.getLogger(PaymentFrame.class);
    //  標題
    private static String TITLE = "Online Bank Helper(v2.0.0)";
    //  寬
    public static final int WIDTH = 770;
    //  高
    public static final int HEIGHT = 550;
    //  用戶資訊
    private Operator operator = new Operator();
    
    //	Menu
    private JMenuBar menuBar = new JMenuBar();
    //	Menu map
    private Map<String, JMenuItem> menuItemMap = new HashMap<String, JMenuItem>();
    
    private InfoPanel infoPanel;
    
    private TaskPanel taskPanel;
    
    private LogPanel logPanel;
    
    public PaymentFrame2() {
    	
        //  設定標題
        super(TITLE);
        //  設定預設關閉的方式
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //  設定寬高
        setSize(new Dimension(WIDTH, HEIGHT));
        //	設定布局
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.blue);
        //  不可變形
        setResizable(false);
        //  永遠置頂
        setAlwaysOnTop(true);
        //  顯示在最左上角
        //Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        //setLocation(screenSize.width - WIDTH, 0);
        //  綁定監聽器
        this.addWindowListener(this);

        //  運營人員
        this.operator = new Operator();
        
        //	set layout
		//this.setLayout(new GridLayout(2, 5, 5, 5));
        
        //	初始化選單
        this.initMenu();

        getContentPane().add(this.infoPanel = new InfoPanel(null, null, new BigDecimal(0), new BigDecimal(0)), BorderLayout.NORTH);
        getContentPane().add(this.taskPanel = new TaskPanel(), BorderLayout.CENTER);
        getContentPane().add(this.logPanel = new LogPanel(), BorderLayout.SOUTH);
    }

	private void initMenu() {
        JMenu menu;
        JMenuItem menuItem;
        Integer menuItemWidth = 150;
        
        this.setJMenuBar(menuBar);
        
        //	File
        menu = new JMenu("File");
        menu.setMnemonic(KeyEvent.VK_F);
        menuBar.add(menu);
        //	File / Login
        menuItem = new JMenuItem("Login");
        menuItem.addActionListener(this);
        menuItem.setPreferredSize(new Dimension(menuItemWidth, menuItem.getPreferredSize().height));
        menuItemMap.put("Login", menuItem);
        menu.add(menuItem);
        //	File / Logout
        menuItem = new JMenuItem("Logout");
        menuItem.setEnabled(false);
        menuItem.addActionListener(this);
        menuItemMap.put("Logout", menuItem);
        menu.add(menuItem);
        //	File separator
        menu.addSeparator();
        //	File / Setting
        menuItem = new JMenuItem("Setting");
        menuItem.addActionListener(this);
        menuItemMap.put("Setting", menuItem);
        menu.add(menuItem);
        //	File separator
        menu.addSeparator();
        //	File / Exit
        menuItem = new JMenuItem("Exit");
        menuItem.addActionListener(this);
        menuItemMap.put("Exit", menuItem);
        menu.add(menuItem);
        
        //	Bank
        menu = new JMenu("Bank");
        menu.setMnemonic(KeyEvent.VK_B);
        menuBar.add(menu);
        //	Bank / Select
        menuItem = new JMenuItem("Select");
        menuItem.setEnabled(false);
        menuItem.addActionListener(this);
        menuItem.setPreferredSize(new Dimension(menuItemWidth, menuItem.getPreferredSize().height));
        menuItemMap.put("Select", menuItem);
        menu.add(menuItem);
        
        //	Help
        menu = new JMenu("Help");
        menu.setMnemonic(KeyEvent.VK_H);
        menuBar.add(menu);
        //	Help / About
        menuItem = new JMenuItem("About");
        menuItem.addActionListener(this);
        menuItem.setPreferredSize(new Dimension(menuItemWidth, menuItem.getPreferredSize().height));
        menuItemMap.put("About", menuItem);
        menu.add(menuItem);
    }
    
	private void initCenterPart() {
    	JPanel centerPanel = new JPanel();
    	JPanel panel = null;
    	JLabel label = null;
    	JSplitPane jSplitPane = null;
    	JPanel childLeftPanel = new JPanel();
    	JPanel childRightPanel = new JPanel();
    	
    	centerPanel.setLayout(new GridLayout(2, 1));
    	centerPanel.setPreferredSize(new Dimension(WIDTH, HEIGHT - 200));
    	getContentPane().add(centerPanel, BorderLayout.CENTER);
    	
    	panel = new JPanel();
    	panel.setLayout(new GridBagLayout());
    	panel.setBackground(Color.red);
    	panel.add(new JLabel("Waiting Time:"));
    	
    	centerPanel.add(panel);
    	
    	panel = new JPanel();
    	panel.setBackground(Color.blue);
    	centerPanel.add(panel);
    	
    	childLeftPanel.add(new JLabel("123"));
    	childLeftPanel.setBackground(Color.red);
    	childRightPanel.add(new JLabel("123"));
    	childRightPanel.setBackground(Color.red);
    	jSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, childLeftPanel, childRightPanel);
    	jSplitPane.setDividerLocation(0.2);
    	panel.add(jSplitPane, BorderLayout.CENTER);
	}
    
	@Override
	public void windowActivated(WindowEvent arg0) {
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		
	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getActionCommand());
		if(e.getActionCommand().equals("Login")) {
			
		}else if(e.getActionCommand().equals("Logout")) {
			
		}else if(e.getActionCommand().equals("Setting")) {
			
		}else if(e.getActionCommand().equals("Exit")) {
			this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
		}else if(e.getActionCommand().equals("Select")) {
			
		}else if(e.getActionCommand().equals("About")) {
			
		}
	}

}
