package com.wlft.payment.bank;

import com.wlft.payment.common.Config;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seimicrawler.xpath.JXDocument;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;
import static io.github.seleniumquery.SeleniumQuery.$;
import static java.lang.Thread.sleep;

public class BOCOnlineBank extends OnlineBank {

    private static Logger logger = Logger.getLogger(BOCOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {
        BANK_MAPPING.put("工商银行", "中国工商银行");
        BANK_MAPPING.put("邮政储汇", "邮政");
    }
    public BOCOnlineBank(Integer id, String accountCode, String hostname, Integer port){
        super("BOC", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);
        loginByPassword();
    }

    private void loginByPassword() throws Exception{

        initBOCMessageBox();
        BOCMessageBox("Start 用户名登陆");
        String js = "";
        WebElement ele,ele1,ele2,ele3 = null;
        ele2 = driver.findElement(By.id("txt_username_79443"));

        sleep(2000);
        ele2.sendKeys("a");
        sleep(1000);
        String  isA = ele2.getText();
        if(isA.equals("A")){
            press(new String[]{"CapsLock"}, 200, 50);
        }
        ele2.clear();
        sleep(2000);
        ele2.sendKeys(username);
        press(new String[]{"Tab"}, 100, 50);
        setMessage("Type password");

        pressText(password);
        // 全屏截图
        PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        // 登录
        driver.executeScript("document.getElementById('btn_login_79676').click()" );

        WebDriverWait wait = new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nav")));

    }


    @Override
    public void logout() throws Exception {

    }
    public String getBal() throws Exception {
        setMessage("Fetch balance");
        driver.executeScript(" document.getElementsByTagName('a')[10].click()  ");
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='main']/div[@id='subMenu']/dl[2]/dt/a")));
        driver.executeScript(" document.getElementsByTagName('a')[35].click()  ");
        waitPageElement("available_balance",30);
        WebElement ele3= driver.findElement(By.id("available_balance"));

        String  bal = ele3.getText();
        bal = bal.replaceAll(",","");
        logger.info("get page balance = " + bal);
        return bal;

    }
    @Override
    public void checkBalance(BigDecimal balance) throws Exception {
        driver.switchTo().window(windowHandle);
        initBOCMessageBox();
        setMessage("Fetch balance");
        clearVerifyPopup();
        String bal = getBal();
        if(bal.length()>0) {
            this.balance = new BigDecimal(bal);
        }else {
            this.balance = new BigDecimal("0.0");
        }

        if(this.balance.compareTo(balance) != 0){
            this.setMessage("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
        }else{
            this.setMessage("Balance:" + bal);
        }

    }

    void clearVerifyPopup() {

        try{
            new WebDriverWait(driver, 2).until(ExpectedConditions.visibilityOfElementLocated(By.id("lightbox")));
            driver.executeScript(" var lightbox = document.getElementById('lightbox');  lightbox.parentNode.removeChild(lightbox);");
        } catch (ScriptTimeoutException e) {
            logger.info("wait ScriptTimeoutException ", e);
        }
        catch (TimeoutException e) {
            logger.info("wait verify popup timeout ", e);
        }
        catch (NoSuchElementException e) {
            logger.info("wait verify popup NoSuchElementException", e);
        }
        catch (Exception e) {

        }
    }

    @Override
    public BigDecimal getPageBalance( ) throws  Exception{

        driver.switchTo().window(windowHandle);
        String bal = getBal();
        if(bal.length()>0) {
            this.balance = new BigDecimal(bal);
        }

        return this.balance;
    }


    @Override
    public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {
        boolean ok = false;
        boolean isBOC = bankName.equals("中国银行");
        TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        // 内部转账 和 跨行转账 的页面元素 id 值
        String page_index_value = isBOC ? "34":"35";
        String page_amount_id = isBOC ?"txt_transamount_471":"txt_transamount_1690";
        String page_payeename_id = isBOC ? "txt_payeename_455":"txt_payeename_1600";
        String page_transinaccparent_id = isBOC ? "txt_transinaccparent_458" :"txt_transinaccparent_1601";
        String page_submit_id = isBOC ?"btnBocTransferConfirm": "btn_confirm_36496";
        String page_success_id = isBOC ? "div_transoutaccparent_3055":"trans_success_div";
        String page_way_id = isBOC ? "rd_exec_3955_1":"rd_trans_mode_1";

        setMessage("Start transaction");
        logger.info("Start transaction");
        driver.switchTo().window(windowHandle);
        driver.executeScript(" document.getElementsByTagName('a')[10].click()  ");

        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='main']/div[@id='subMenu']/dl[2]/dt/a")));

        driver.executeScript(" document.getElementsByTagName('a')[" + page_index_value +"].click()  ");

        waitPageElement(page_amount_id,20);
        setMessage("Mask fields");
        driver.executeScript(" document.getElementById('rd_choose_security_tool_17637_2').checked = true  ");
        driver.executeScript("$('#"+ page_amount_id  +"').after('<div class=\"payment-masker\" style=\"position:absolute; left:620px;  width:100px !important; height:102px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#"+ page_transinaccparent_id +"').after('<div class=\"payment-masker\" style=\"position:absolute; left:96px;  width:100px !important; height:32px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#"+ page_amount_id  +"').after(\"<input  id='payment_point' style='width:10px'/>\")");
        // clear
        driver.executeScript("$('#ajaxLoading').hide()");
        setMessage("start click page_amount_id ");

        // amount
        WebElement   ele3= driver.findElement(By.id(page_amount_id));
        ele3.sendKeys(amount.toString());
        // name
        String js = "$('#"+ page_payeename_id  +"').val('" + accountName + "')";
        String checkJs =     "return $('#"+ page_payeename_id  +"').val()";
        tryToPutValue(js,checkJs,accountName);
        driver.executeScript("$('#"+ page_payeename_id  +"').focus()");
        press(new String[]{"0"}, 100, 50);
        press(new String[]{"Backspace"}, 100, 50);

        //bank
        driver.findElement(By.id(page_transinaccparent_id)).sendKeys(accountNumber);

        sleep(1300);
        press(new String[]{"Tab"}, 100, 50);
        setMessage(" start set way ");
        // way
        driver.executeScript(" document.getElementById('" + page_way_id + "').checked = true  ");
        // 认证默认值会变 需要js选中
        driver.executeScript(" document.getElementById('rd_choose_security_tool_17637_2').checked = true  ");
        // record page value
        logger.info("=============================>>>>record get back of page value");
        logger.info(driver.executeScript( "return $('#"+ page_payeename_id  +"').val()"));
        logger.info(driver.executeScript( "return $('#"+ page_transinaccparent_id  +"').val()"));
        logger.info(driver.executeScript( "return $('#"+ page_amount_id  +"').val()"));
        sleep(3000);
        setMessage("Click 下一步");
        if(isBOC){
            ele3 = driver.findElement(By.id("trans_tips_ca_180528"));
            ele3.click();
            driver.executeScript("document.getElementById('btnBocTransferNext').click()");
        }else{
            try{
                driver.executeScript("document.getElementById('txt_transinaccparent_1601').click()");
                driver.executeScript("document.getElementById('txt_transinaccparent_1601').blur()");
                driver.executeScript(" document.getElementById('rd_choose_security_tool_17637_2').checked = true  ");
                sleep(1300);
                driver.executeScript("document.getElementById('btn_nextstep_1732').click()");
            } catch (UnhandledAlertException x){
                setMessage("Click 下一步");
                driver.executeScript("document.getElementById('txt_transinaccparent_1601').click()");
                driver.executeScript("document.getElementById('txt_transinaccparent_1601').blur()");
                driver.executeScript(" document.getElementById('rd_choose_security_tool_17637_2').checked = true  ");
                sleep(1300);
                driver.executeScript("document.getElementById('btn_nextstep_1732').click()");
            }
        }
        waitPageElement("hideMsgBox",15);
        // 清除USB 弹框
        setMessage("Click USB 确定");
        logger.info("Click USB 确定");
        driver.executeScript("document.getElementById('hideMsgBox').click()");
        //收集费用
        String bal;
        if(isBOC){
            bal = driver.executeScript("   return  document.getElementById('divConfirm').children[0].children[5].children[1].innerText  +' '").toString().trim();
        } else {
            bal = driver.executeScript("   return  document.getElementById('civilTransferConfirm').children[0].children[1].children[6].children[1].innerText +' '").toString().trim();
        }

        setMessage(" get charge ="+ bal);
        logger.info("get charge ="+ bal);
        if(!(bal.length()>0)||bal.equals("免费")){
            taskLog.setCharge("0.0");
        }else {
            taskLog.setCharge(bal);
        }


        //确认
        driver.executeScript("document.getElementById('"+ page_submit_id +"').click()");
        // boc driver easy to fail
        sleep(8000);
        //输入usbPassword
        PcUtils.captureScreen(this.code, "page_driver_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        pressText(usbPassword);
        sleep(5000);
        PcUtils.captureScreen(this.code, "page_password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");

        press(new String[]{"Enter"}, 1000, 200); //

        // 循环等待人点击U盾
        try {
            WebDriverWait wait3 = new WebDriverWait(driver, 30); // BOC 页面就最多 20秒的倒计时
            int waitCount = 6;
            boolean success = false;
            sleep(5000);
            while(waitCount > 0) {
                try {
                    waitCount --;
                    sleep(2000);
                    wait3.until(ExpectedConditions.visibilityOfElementLocated(By.id( page_success_id )));
                    logger.info("本行代码已经执行,获取到成功标识");
                    ok = true;
                    break;
                } catch (TimeoutException e) {
                    logger.info("wait element timeout exception: waitCount=" + waitCount + e.getMessage());
                    break;
                } catch (Exception e) {
                    logger.info("wait exception:" + e.getMessage());
                }
            }

        } catch(Throwable x) {
            x.printStackTrace();
        }
        PcUtils.captureScreen(this.code, "page_BOC_showINFO_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        //  检测
        taskLog = checkTransfer(amount,taskLog,"20.00");
        return handleCheck(taskLog.getStatus().equals(TaskLog.SUCCESS) ||  ok,id,taskLog) ;
    }

    @Override
    public void queryTransaction() throws Exception {
        driver.switchTo().window(windowHandle);
    }

    public   void initBOCMessageBox() throws Exception {

        driver.executeScript("$('body').after('<div id=\"payment-online-bank-message\" style=\"position:fixed;top: 300px;padding:10px; left:10px;width:300px;height:60px;background:#000000;color:#FFFFFF;  font-size:18px;  \">init</div>')" );

    }
    public   void BOCMessageBox(String message) throws Exception {

        driver.executeScript("$('#payment-online-bank-message').html('" + message + "');");

    }

}
