package com.wlft.payment.bank;

import com.wlft.payment.common.Config;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.math.BigDecimal;
import java.util.Date;     
import java.util.HashMap;
import java.util.Map;

import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;
import static java.lang.Thread.sleep;

public class CMBCOnlineBank extends OnlineBank {

    private static Logger logger = Logger.getLogger(CMBCOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static { 
    	 BANK_MAPPING.put("工商银行", "中国工商银行");
    	 BANK_MAPPING.put("邮政储汇", "邮政");
    }
    public CMBCOnlineBank(Integer id, String accountCode, String hostname, Integer port){
        super("CMBC", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);

        loginByPassword();
 

    }

    private void loginByPassword() throws Exception{


        //  設定登錄帳號、密碼、交易密碼、U盾密碼

        username ="cuocuocuo";
        password ="ms365894";
        queryPassword ="146557";
        usbPassword ="955525";

        //  初始化訊息框
        initMessageBox();
        press(new String[]{"Enter"}, 100, 50);
        //  focus window
        //  clearPage(driver); 
        this.setMessage("Start 用户名登陆");
        try{
            driver.executeScript("$('.slmorkh2>a').click()");
            driver.executeScript("$('#writeUserId').val('" + username + "').focus()" );
            sleep(1000);
            press(new String[]{"Enter"}, 100, 50);
        }catch (Throwable e){

        }
        press(new String[]{"Enter"}, 100, 50);
        for(int i = 0;i < password.length(); i++) {
            System.out.println(i);
            sleep(1000);
            press(password.substring(i,i+1).split(""), 100 + (int)(Math.random() * 100), 60);
        }
        sleep(3000);
        driver.executeScript("$('#loginButton').click()");

        String tip = driver.executeScript("return $('#jsonError').text()").toString();
        System.out.println(tip);
        //if(tip.indexOf("当前页面已超时")>-1){
            System.out.println(tip);
            driver.executeScript("$('#writeUserId').val('" + username + "').focus()" );
            System.out.println("need login again");
            press(new String[]{"Tab"}, 100, 50);
            for(int i = 0;i < password.length(); i++) {
                System.out.println(i);
                sleep(1000);
                press(password.substring(i,i+1).split(""), 100 + (int)(Math.random() * 100), 60);
            }
        //}

        driver.executeScript("$('#loginButton').click()");
        sleep(5000);
      
    }

  
    @Override
    public void logout() throws Exception {

    }

    @Override
    public void checkBalance(BigDecimal balance) throws Exception {
        initMessageBox();
        setMessage("Fetch balance");
        driver.switchTo().window(windowHandle);
        WebDriverWait wait = new WebDriverWait(driver, 60);
        try{
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("welcomeMainContent")));
        }catch (Throwable e){
            logger.info("依旧找不到");
            sleep(3000);
        }
        String bal =driver.executeScript("return  $('.v-binding:eq(14)').text()" ).toString();
        bal = bal.replaceAll(",","");
        if(bal.length()>0) {
        	 this.balance = new BigDecimal(bal);
        }else {
            this.balance = new BigDecimal("0.0");
        }
        if(this.balance.compareTo(balance) != 0){
            setMessage("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
        }else{
            setMessage("Balance:" + bal);
        }
        logger.info("get banlance=" + bal);
    }
     
 
    
    @Override
    public BigDecimal getPageBalance( ) throws  Exception{
        setMessage("Fetch balance");
        driver.switchTo().window(windowHandle);
        driver.executeScript("$('.nav_n>li:eq(0)>a').click()");
        WebDriverWait wait = new WebDriverWait(driver, 60);
        try{
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("welcomeMainContent")));
        }catch (Throwable e){
            logger.info("依旧找不到");
            sleep(3000);
        }
        String bal =driver.executeScript("return  $('.v-binding:eq(14)').text()" ).toString();
        bal = bal.replaceAll(",","");
        if(bal.length()>0) {
            this.balance = new BigDecimal(bal);
        }
        return this.balance;
    };
     
    public TaskLog doTransfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {
    	int step = 0;        
    	org.openqa.selenium.Point position;

    	TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        String imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + ".png";
        Object charge = null;
        accountNumber = accountNumber.trim();
        try {
        //  初始化pending
        this.initPending();
        this.setMessage("Start transaction");
        driver.switchTo().window(windowHandle);
        //  跳轉至轉帳頁面
        driver.executeScript("$('.nav_n>li:eq(2)>a').click()" );
        sleep(3000);
        driver.executeScript("$('#parentMenu2>li:eq(0)>a').click()");
        //  waiting
        try{
            new WebDriverWait(driver, 7).until((ExpectedCondition<Boolean>) wd ->
                    ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));
        }catch (Throwable e){

        }
        sleep(3000);

        //  初始化pending
        this.initPending(); 
        this.setMessage("Mask fields");
        driver.executeScript("$('#Amount').val(1).blur()");
        driver.executeScript("$('.biaocss>tbody>tr:eq(4)>td>input').val('苗之润');");
        driver.executeScript("$('.biaocss>tbody>tr:eq(5)>td>input').val('6216606300008459115').blur();");
            driver.executeScript("$('#Amount').focus()");
            press(new String[]{"0"}, 50, 50);
            press(new String[]{"Backspace"}, 50, 50);
            this.click(10,10);
        driver.executeScript("$('.biaocss>tbody>tr:eq(4)>td>input').focus()");
            press(new String[]{"0"}, 50, 50);
            press(new String[]{"Backspace"}, 50, 50);
        press(new String[]{"Tab"}, 50, 200);
        this.click(10,10);
        driver.executeScript("$('.biaocss>tbody>tr:eq(5)>td>input').focus()");
            press(new String[]{"0"}, 50, 50);
            press(new String[]{"Backspace"}, 50, 50);
            press(new String[]{"Tab"}, 50, 200);
        this.click(10,10);
            driver.executeScript("$('#Amount').focus()");
            press(new String[]{"0"}, 100, 50);
            press(new String[]{"Backspace"}, 100, 50);
            press(new String[]{"Tab"}, 1000, 200);
            this.click(10,10);
        System.out.println("end value");
        sleep(3000);

         //下一步
        driver.executeScript("$('.biaocss:eq(1)>tbody>tr>td>input').trigger('click')");


        sleep(3000);
            // 等待时间

            driver.executeScript("$(\"#safetyProveId>span>input[name='SafetyTool']:eq(1)\").click()");

           try {
               charge = driver.executeScript("return  $('.ceng:eq(1)').html() ");
            } catch (Exception e){

           }
        
        
 
          if(charge == null ){
        	   taskLog.setCharge("0.0");
          } else {
        	  String tmp = charge.toString();
              tmp = tmp.split("元")[0];
              taskLog.setCharge(tmp);
         }

           logger.info(charge);  // 0.00元
        } catch(Throwable x) {
        	    		
        }
        System.out.println(charge);
        // queryPassword
        for (int i =0;i<=7;i++){
         //   press(new String[]{"Tab"}, 100, 50);
        }
        for(int i = 0;i < queryPassword.length(); i++) {
            System.out.println(i+100);
            sleep(1000);
            press(queryPassword.substring(i,i+1).split(""), 100 + (int)(Math.random() * 100), 60);
        }

        // queryPassword end
        // 提交
        driver.executeScript("$('.anniucss:eq(13)').click()");
        // successpage

     if(charge.toString().length() >0) {
        	imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_success_.png";
            PcUtils.saveScreen(driver, imagePath);
            taskLog.setStatus(TaskLog.SUCCESS);
            taskLog.setImg(imagePath);
      }else {
            imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png";
            taskLog.setStatus(TaskLog.FAIL);
            taskLog.setImg(imagePath);
            new Thread(new Runnable() {
                public void run() {
                    PcUtils.open("a.wav");
                }
            }).start();
            PcUtils.captureScreen(this.code, id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png");
            throw new BankException("usbPassword_error", taskLog);
        }

        return taskLog;
    }

    public boolean checkTransfer(  BigDecimal amount   ) throws Exception {
   	 BigDecimal  oldBalance = balance;
   	 getPageBalance(); 
   	 
   	 if(balance.equals(oldBalance.subtract(amount))) {
         logger.info(" 转账是正确的 ");
   		    return true;	
    	 } else {
    		return false;
    	 }
   	
   }
   
   @Override 
   public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {
   
   	TaskLog tasklog = null ;
    // 1. 执行转账
   	try {
       
   		tasklog =  doTransfer( id, bankName,accountNumber, accountName,  amount, memberBankProvince, memberBankCity, memberBankBranch );
   		
   	} catch(Throwable x) {
   		
    } 	
    // 2. 验证转账     	
   	try {
   		
   		if(checkTransfer(amount)) {
           	 tasklog.setStatus(TaskLog.SUCCESS);	
        }
   		logger.info("验证转账完毕");
       } catch(Throwable x) {
       
    }
   	
   	return tasklog;
   }

    @Override
    public void queryTransaction() throws Exception { 
        driver.switchTo().window(windowHandle);
    }

 
    private TaskLog fillHandle(BigDecimal id,TaskLog taskLog, String imageName) {
        String  imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_" + imageName + "_.png";
        PcUtils.saveScreen(driver, imagePath);
        taskLog.setStatus(TaskLog.FAIL);
        taskLog.setImg(imagePath);
        new Thread(new Runnable() {
            public void run() {
                PcUtils.open("a.wav");
            }
        }).start();
        return taskLog;
    }


}
 