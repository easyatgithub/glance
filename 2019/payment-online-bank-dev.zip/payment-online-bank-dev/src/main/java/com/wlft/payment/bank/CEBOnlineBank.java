package com.wlft.payment.bank;

import com.wlft.payment.common.Config;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.SXApi;

import org.apache.commons.io.FileUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;
import org.apache.commons.lang3.StringUtils; 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seimicrawler.xpath.JXDocument;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;
import static io.github.seleniumquery.SeleniumQuery.$;
import static java.lang.Thread.sleep;

import java.awt.image.BufferedImage;
import java.io.File;

public class CEBOnlineBank extends OnlineBank {
 

    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {
    	 BANK_MAPPING.put("工商银行", "中国工商银行");  
    	 BANK_MAPPING.put("邮政储汇", "邮政");  
    }
    public CEBOnlineBank(Integer id, String accountCode, String hostname, Integer port){
        super("CEB", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);
 
        loginByPassword();
 

    }

    private void loginByPassword() throws Exception{


        username = "bxtuiutb";
        password = "zz800525";
        queryPassword = "147258";
        usbPassword ="800525";
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);
        System.out.println(username);
        System.out.println(password);
        System.out.println(queryPassword);
        System.out.println(usbPassword);
        //  初始化訊息框
        this.initMessageBox(); 

        //  focus window
        //  clearPage(driver); 
        this.setMessage("Start 用户名登陆");
        String js = "";
        js = "$('#logType').click()";	 
        //5.CEB.012(2)
        driver.executeScript(js );


        js = "$('#skey').val('"+username+"').focus().click()";	
        driver.executeScript(js ); 
        press(new String[]{"Tab"}, 100, 50);
        this.setMessage("Type password");
        
        press(new String[]{"a","Backspace"}, 1000, 50);
 	    
 	   if( PcUtils.capsLock()){ 
      	   press(new String[]{"CapsLock"}, 500, 50);
      	 sleep(3000);
         }
 	    
        for(int i = 0;i < password.length(); i++) {
        	System.out.println(PcUtils.capsLock());
        	
        	press(password.substring(i,i+1).split(""), 100 + (int)(Math.random() * 100), 60);
        	
        }
         
        //手动登陆
        Object[] options = {"Yes,是的", "No,取消¦"};
     
        //driver.executeScript( "$('.loginbtn').click()");
        JOptionPane.showOptionDialog(null, " again?", "询问 ", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options,null);
        sleep(3000);
        this.click(410, 190); 
        this.click(410, 240); 
        this.click(510, 240);
        sleep(4000);
        
    }

  
    @Override
    public void logout() throws Exception {

    }

    @Override
    public void checkBalance(BigDecimal balance) throws Exception {
    	 //  初始化訊息框
         this.initMessageBox(); 
    	 setMessage("Fetch balance");
         
         driver.switchTo().window(windowHandle);
         driver.switchTo().frame("mainFrame");

         String  html = $("body").html();
         
         JXDocument body =  JXDocument.create(html);//kabao-main

         String xpath = "//form/table[@class='mar13']/tbody/tr[2]/td[2]/table/tbody/tr[2]/td/table[@class='txt02']/tbody/tr[4]/td[2]/table/tbody/tr/td/span[@class='txt11']/html()";
         List<Object> res =  body.sel(xpath);
         String bal = StringUtils.join(res, ",");
        
         bal = bal.replaceAll(",","");
         
         if(bal.length()>0) {
         	 this.balance = new BigDecimal(bal);
         }

         if(this.balance.compareTo(balance) != 0){
             setMessage("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
         }else{
             setMessage("Balance:" + bal);
         }

    }
    
    @Override
    public BigDecimal getPageBalance( ) throws  Exception{
    	
    	org.openqa.selenium.Point position;
        
    	setMessage("Fetch balance");
      
        return this.balance;
    };
     
    public TaskLog doTransfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {
    	int step = 0;        
    	org.openqa.selenium.Point position;

    	TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        String imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + ".png";

       try { 
    	    
        //  初始化pending
        this.initMessageBox();
        this.initPending(); 
    
        this.setMessage("Start transaction");

        //  跳轉至轉帳頁面 
        
        this.click(410, 190); 
        this.click(410, 240); 
        this.click(510, 240);
        sleep(4000);

        this.setMessage("Mask fields");

        driver.switchTo().window(windowHandle);
        driver.switchTo().frame("mainFrame");
        
        driver.executeScript( "body=1");
        driver.executeScript( " document.getElementById('Amount').value = '" + amount + "'  ");
         
        driver.executeScript( " document.getElementById('AcNo2').value = '" + accountNumber + "'  ");
        driver.executeScript( " document.getElementById('AcNo2Name').value = '" + accountName + "'  "); 
        
        
        driver.executeScript(  "var portals = document.getElementsByName('verificationMode');for(var i = 0; i < portals.length; i++) { if(i==1){  portals[i].click();} }");
       
        System.out.println("account");
        this.click(510, 500);//
        sleep(2000);
        press(new String[]{"Enter"}, 300, 500);
        sleep(5000);
        System.out.println("passs");
        this.click(510, 705);//  
        press(new String[]{"a","Backspace"}, 1000, 50);
 	    
  	    if( PcUtils.capsLock()){ 
       	   press(new String[]{"CapsLock"}, 500, 50);
       	 sleep(3000);
          }
  	    
         for(int i = 0;i < queryPassword.length(); i++) {
         	System.out.println(PcUtils.capsLock());
         	press(queryPassword.substring(i,i+1).split(""), 100 + (int)(Math.random() * 100), 60);
         	
         }
          
        sleep(5000);
        System.out.println("btn");
        this.click(545, 775);//  
         
        sleep(5000);
         
        
        System.out.println("aaaaa");
        position = driver.findElement(By.id("Amount")).getLocation(); 

        System.out.println("bbbbbb");
        this.click(position.getX(), position.getY());
        this.click(510, 440);//  
        press(new String[]{"Enter"}, 300, 500);
        this.click(510, 540);//  
        press(new String[]{"Enter"}, 300, 500);
        
        driver.executeScript("$('#Amount').after('<div class=\"payment-masker\" style=\"position:absolute; left:255px; top:20px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#AcNo2').after('<div class=\"payment-masker\" style=\"position:absolute; left:255px; top:20px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#recAccountOpenBank').after('<div class=\"payment-masker\" style=\"position:absolute; left:255px; top:14px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        
        driver.executeScript(  "var select = document.getElementById('BankCode');for (var i = 0; i < select.options.length; i++){ if (select.options[i].text == '农业银行'){console.log(1); select.options[i].selected = true;  break;}} ");
        
       
        
        //  加入移除遮照的事件
        // driver.executeScript("$('.payment-masker').on('click', function(){var ans = prompt('Please enter password', ''); if(ans == 5201314){$('.payment-masker').remove();}})");


        driver.executeScript(" $('#recAccountOpenBank').click();");
          
        sleep(3000);
        
        driver.executeScript("$('#queryBank').val('"+ (BANK_MAPPING.get(bankName) != null ? BANK_MAPPING.get(bankName) : bankName) + "')");
        driver.executeScript("$('#query').click()");
        
        position = driver.findElement(By.id("Amount")).getLocation(); 
         
        this.click(position.getX()-45, position.getY()-273);
        // 卡号点击
        this.click(position.getX()+310, position.getY()-140);
        press(new String[]{"Enter"}, 300, 500);
        driver.executeScript("$('#nextBut').click()");
        this.setMessage("Click 下一步");
       
        // 验证码+ 手短信 大概几分钟就等几分钟哦
        
        sleep(120000);
        // 需要 判斷 成功 界面元素
        
        // 截图信息 
        
        try{  
            driver.switchTo().frame("perbank-content-frame");
            driver.switchTo().frame("content-frame");
            driver.executeScript("$('#tijiao').trigger('click')");
            
            String tijiao = driver.executeScript("return $('#tijiao').html()").toString();
            position = driver.findElement(By.id("tijiao")).getLocation();
            
            
            tijiao = driver.executeScript("return $('#tijiao').trigger('click')").toString();
  
            driver.switchTo().frame("perbank-content-frame");
            driver.switchTo().frame("content-frame");
             
            new WebDriverWait(driver, 7).until((ExpectedCondition<Boolean>) wd ->
                    ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));

         } catch (Exception e){
            
            taskLog =  fillHandle(id,taskLog,"value_error");
            throw new BankException("赋值页面错误", taskLog);
         }

         //取得 费用 charge
         Object charge = null;     // 没有取到就是 0 因为空指针异常 不要抛出 bank 异常
           try { 
                charge = driver.executeScript("return $('#Fee-Money').text() ");
                
            } catch (Exception e){
            	
           }
        
        
 
          if(charge == null ){
            
        	   taskLog.setCharge("0.0");
        	   
          } else {  
            
        	  String tmp = charge.toString(); //  String tmp = "（手续费：7.50元）"
            
        	  if(tmp.length()>1) {
            	tmp = tmp.substring(5);
           	    tmp = tmp.replaceAll("元）","");
                taskLog.setCharge(tmp);
              } else {
            	  taskLog.setCharge("0.0");
              }           
         }
          
       
        
        } catch(Throwable x) {
        	    		
        } 	
        
       if(step == 1) {
          
    	   sleep(8000);  // 睡眠时间越长 越安全
          
    	   press(new String[]{"a","Backspace"}, 1000, 50);
    	   sleep(500);
           if( PcUtils.capsLock()){
        	   press(new String[]{"CapsLock"}, 200, 50);
           } 
           
          press(password.split(""), 1000, 50);  // at lest 100ms and  rund val
          press(new String[]{"Enter"}, 1000, 50);
         
          //呼叫: 开启 声音提示操作人员按下 OK
          new Thread(new Runnable() {
              public void run() {
                  PcUtils.open("a.wav");
              }
          }).start();
         
  		
  	   }

 
        // 循环等待   30秒内 操作人员按下
        String tag = "";
        String successInfo = "";
         int waitTime = 30;
        
        while(true) {
        	try {
        		sleep(1000);
        		waitTime --;
        		if(waitTime==0) {
        			break;
        		}

                if(tag.length()>0) {
                	break;
                }
        		
        	}catch(Throwable e) {
        		
        	}
        }
 
          
        
     if(tag.length() > 0 && successInfo.length() > 0) {
        	 
        	imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_success_.png";
            PcUtils.saveScreen(driver, imagePath);
            taskLog.setStatus(TaskLog.SUCCESS);
            taskLog.setImg(imagePath);   
            
        }else {  
            imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png";
            
            taskLog.setStatus(TaskLog.FAIL);
            taskLog.setImg(imagePath);
            new Thread(new Runnable() {
                public void run() {
                    PcUtils.open("a.wav");
                }
            }).start();
            PcUtils.captureScreen(this.code, id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_usbPassword_error_.png");
            throw new BankException("usbPassword_error", taskLog);
        }
       
         
        
        return taskLog;
    }
    public boolean checkTransfer(  BigDecimal amount   ) throws Exception {
   	 BigDecimal  oldBalance = balance;
   	 getPageBalance(); 
   	 
   	 if(balance.equals(oldBalance.subtract(amount))) {
   		    return true;	
    	 } else {
    		return false;
    	 }
   	
   }
   
   @Override 
   public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {
   
   	TaskLog tasklog = null ;
    // 1. 执行转账
   	try {
       
   		tasklog =  doTransfer( id, bankName,accountNumber, accountName,  amount, memberBankProvince, memberBankCity, memberBankBranch );
   		
   	} catch(Throwable x) {
   		
    } 	
    // 2. 验证转账     	
   	if(tasklog.getStatus().equals(TaskLog.SUCCESS)){
   		try {
   	   		if(checkTransfer(amount)) {
   	           	 tasklog.setStatus(TaskLog.SUCCESS);	
   	        } else {
   	        	tasklog.setStatus(TaskLog.FAIL);
   	        }
   	       } catch(Throwable x) {
   	    	tasklog.setStatus(TaskLog.FAIL);
   	    }
   	}
   	
   	
   	return tasklog;
   }

    @Override
    public void queryTransaction() throws Exception { 
        driver.switchTo().window(windowHandle);
    }

 
    private TaskLog fillHandle(BigDecimal id,TaskLog taskLog, String imageName) {
        String  imagePath =  "\\" + this.code + "\\" + id +"_" + DATE_TIME_FORMATTER2.format(taskLog.getTime())      + "_" + imageName + "_.png";
        PcUtils.saveScreen(driver, imagePath);
        taskLog.setStatus(TaskLog.FAIL);
        taskLog.setImg(imagePath);
        new Thread(new Runnable() {
            public void run() {
                PcUtils.open("a.wav");
            }
        }).start();
        return taskLog;
    }


    public   void clearPage(RemoteWebDriver driver) throws Exception {
        boolean run = true;
        int     runCount = 0;
        while(run){
            try{
                sleep(700);
                runCount++;
                WebElement element  =driver.findElement(By.id("onemap"));
                if(element != null){
                    driver.executeScript( "oneclick();");
                    driver.executeScript( "twoclick();");
                    driver.executeScript( "$('#threemap area').click()");
                    sleep(2000);

                    run = false;
                }else{
                    run = false;
                }
                if(runCount ==1){
                    run = false;
                    break;
                }
            }catch (Exception e){
                run = false;
                break;
            }

        }
    }
    
    public   void clearPage2(RemoteWebDriver driver) throws Exception {
        boolean run = true;
        int     runCount = 0;
        while(run){
            try{
                sleep(700);
                runCount++;
                WebElement element  =driver.findElement(By.id("onemap"));
                if(element != null){
                    driver.executeScript( "$('#threemap area:eq(1)').click()");
                    sleep(2000);

                    run = false;
                }else{
                    run = false;
                }
                if(runCount ==1){
                    run = false;
                    break;
                }
            }catch (Exception e){
                run = false;
                break;
            }

        }
    }
   
    public   void clearPageAdv(RemoteWebDriver driver) throws Exception {
    	// 有界面才点击
        int     runCount = 0;
        while(true){
            try{
                sleep(700);
                runCount++;
                 
                 click(870, 80);
                   
                if(runCount ==1){
                    break;
                }
            }catch (Throwable e){
                break;
            }

        }
    }
}
 