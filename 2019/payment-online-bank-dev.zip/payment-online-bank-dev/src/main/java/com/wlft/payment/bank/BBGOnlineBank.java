package com.wlft.payment.bank;

import javax.swing.*;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;

import static java.lang.Thread.sleep;
import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;

public class BBGOnlineBank extends OnlineBank {

    private static Logger logger = Logger.getLogger(BBGOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {

        BANK_MAPPING.put("工商银行", "102100099996|中国工商银行");
        BANK_MAPPING.put("中国农业银行", "103100000026|中国农业银行");
        BANK_MAPPING.put("中国银行", "104100000004|中国银行总行");
        BANK_MAPPING.put("中国建设银行", "105100000017|中国建设银行");
        BANK_MAPPING.put("交通银行", "301290000007|交通银行");
        BANK_MAPPING.put("中信银行", "302100011000|中信银行");
        BANK_MAPPING.put("中国光大银行", "303100000006|中国光大银行");
        BANK_MAPPING.put("华夏银行", "304100040000|华夏银行");
        BANK_MAPPING.put("中国民生银行", "305100000013|中国民生银行");
        BANK_MAPPING.put("广发银行", "306581000003|广发银行股份有限公司");
        BANK_MAPPING.put("平安银行", "307584007998|平安银行（原深圳发展银行）");
        BANK_MAPPING.put("招商银行", "308584000013|招商银行");
        BANK_MAPPING.put("兴业银行", "309391000011|兴业银行");
        BANK_MAPPING.put("上海浦东发展银行", "310290000013|上海浦东发展银行");
        BANK_MAPPING.put("北京银行", "313100000013|北京银行");
        BANK_MAPPING.put("天津银行", "313110000017|天津银行");
        BANK_MAPPING.put("河北银行股份有限公司", "313121006888|河北银行股份有限公司");
        BANK_MAPPING.put("唐山银行", "313124000018|唐山银行");
        BANK_MAPPING.put("秦皇岛银行", "313126001022|秦皇岛银行");
        BANK_MAPPING.put("邯郸市商业银行", "313127000013|邯郸市商业银行");
        BANK_MAPPING.put("邢台银行", "313131000016|邢台银行");
        BANK_MAPPING.put("保定银行", "313134000011|保定银行");
        BANK_MAPPING.put("张家口市商业银行", "313138000019|张家口市商业银行");
        BANK_MAPPING.put("承德银行", "313141052422|承德银行");
        BANK_MAPPING.put("沧州银行", "313143005157|沧州银行");
        BANK_MAPPING.put("衡水银行", "313148053964|衡水银行");
        BANK_MAPPING.put("晋商银行网上银行", "313161000017|晋商银行网上银行");
        BANK_MAPPING.put("阳泉市商业银行", "313163000004|阳泉市商业银行");
        BANK_MAPPING.put("长治银行", "313164000006|长治银行");
        BANK_MAPPING.put("晋城银行", "313168000003|晋城银行");
        BANK_MAPPING.put("晋中银行", "313175000011|晋中银行");
        BANK_MAPPING.put("内蒙古银行", "313191000011|内蒙古银行");
        BANK_MAPPING.put("包商银行股份有限公司", "313192000013|包商银行股份有限公司");
        BANK_MAPPING.put("乌海银行", "313193057846|乌海银行");
        BANK_MAPPING.put("鄂尔多斯银行", "313205057830|鄂尔多斯银行");
        BANK_MAPPING.put("盛京银行", "313221030008|盛京银行");
        BANK_MAPPING.put("大连银行", "313222080002|大连银行");
        BANK_MAPPING.put("鞍山市商业银行", "313223007007|鞍山市商业银行");
        BANK_MAPPING.put("丹东银行清算中心", "313226009000|丹东银行清算中心");
        BANK_MAPPING.put("锦州银行", "313227000012|锦州银行");
        BANK_MAPPING.put("葫芦岛银行", "313227600018|葫芦岛银行");
        BANK_MAPPING.put("营口银行", "313228000276|营口银行");
        BANK_MAPPING.put("营口沿海银行股份有限公司", "313228060009|营口沿海银行股份有限公司");
        BANK_MAPPING.put("阜新银行结算中心", "313229000008|阜新银行结算中心");
        BANK_MAPPING.put("辽阳银行股份有限公司", "313231000013|辽阳银行股份有限公司");
        BANK_MAPPING.put("朝阳银行", "313234001089|朝阳银行");
        BANK_MAPPING.put("吉林银行", "313241066661|吉林银行");
        BANK_MAPPING.put("哈尔滨银行结算中心", "313261000018|哈尔滨银行结算中心");
        BANK_MAPPING.put("龙江银行", "313261099913|龙江银行");
        BANK_MAPPING.put("南京银行", "313301008887|南京银行");
        BANK_MAPPING.put("江苏银行股份有限公司", "313301099999|江苏银行股份有限公司");
        BANK_MAPPING.put("江苏长江商行", "313312300018|江苏长江商行");
        BANK_MAPPING.put("杭州银行", "313331000014|杭州银行");
        BANK_MAPPING.put("宁波东海银行", "313332040018|宁波东海银行");
        BANK_MAPPING.put("宁波银行", "313332082914|宁波银行");
        BANK_MAPPING.put("宁波通商银行股份有限公司", "313332090019|宁波通商银行股份有限公司");
        BANK_MAPPING.put("温州银行", "313333007331|温州银行");
        BANK_MAPPING.put("湖州银行", "313336071575|湖州银行");
        BANK_MAPPING.put("绍兴银行", "313337009004|绍兴银行");
        BANK_MAPPING.put("金华银行股份有限公司", "313338009688|金华银行股份有限公司");
        BANK_MAPPING.put("浙江稠州商业银行", "313338707013|浙江稠州商业银行");
        BANK_MAPPING.put("台州银行", "313345001665|台州银行");
        BANK_MAPPING.put("浙江泰隆商业银行", "313345010019|浙江泰隆商业银行");
        BANK_MAPPING.put("浙江民泰商业银行", "313345400010|浙江民泰商业银行");
        BANK_MAPPING.put("福建海峡银行", "313391080007|福建海峡银行");
        BANK_MAPPING.put("厦门银行", "313393080005|厦门银行");
        BANK_MAPPING.put("泉州银行", "313397075189|泉州银行");
        BANK_MAPPING.put("南昌银行", "313421087506|南昌银行");
        BANK_MAPPING.put("九江银行股份有限公司", "313424076706|九江银行股份有限公司");
        BANK_MAPPING.put("赣州银行", "313428076517|赣州银行");
        BANK_MAPPING.put("上饶银行", "313433076801|上饶银行");
        BANK_MAPPING.put("青岛银行", "313452060150|青岛银行");
        BANK_MAPPING.put("齐商银行", "313453001017|齐商银行");
        BANK_MAPPING.put("枣庄银行", "313454000016|枣庄银行");
        BANK_MAPPING.put("东营银行", "313455000018|东营银行");
        BANK_MAPPING.put("烟台银行", "313456000108|烟台银行");
        BANK_MAPPING.put("潍坊银行", "313458000013|潍坊银行");
        BANK_MAPPING.put("济宁银行", "313461000012|济宁银行");
        BANK_MAPPING.put("泰安银行", "313463000993|泰安银行");
        BANK_MAPPING.put("莱商银行", "313463400019|莱商银行");
        BANK_MAPPING.put("威海市商业银行", "313465000010|威海市商业银行");
        BANK_MAPPING.put("德州银行", "313468000015|德州银行");
        BANK_MAPPING.put("临商银行", "313473070018|临商银行");
        BANK_MAPPING.put("日照银行", "313473200011|日照银行");
        BANK_MAPPING.put("郑州银行", "313491000232|郑州银行");
        BANK_MAPPING.put("中原银行", "313491099996|中原银行");
        BANK_MAPPING.put("洛阳银行", "313493080539|洛阳银行");
        BANK_MAPPING.put("平顶山银行", "313495081900|平顶山银行");
        BANK_MAPPING.put("焦作中旅银行", "313501080608|焦作中旅银行");
        BANK_MAPPING.put("汉口银行", "313521000011|汉口银行");
        BANK_MAPPING.put("湖北银行", "313521006000|湖北银行");
        BANK_MAPPING.put("华融湘江银行", "313551070008|华融湘江银行");
        BANK_MAPPING.put("长沙银行", "313551088886|长沙银行");
        BANK_MAPPING.put("广州银行", "313581003284|广州银行");
        BANK_MAPPING.put("珠海华润银行清算中心", "313585000990|珠海华润银行清算中心");
        BANK_MAPPING.put("广东南粤银行股份有限公司", "313591001001|广东南粤银行股份有限公司");
        BANK_MAPPING.put("东莞银行", "313602088017|东莞银行");
        BANK_MAPPING.put("广西北部湾银行", "313611001018|广西北部湾银行");
        BANK_MAPPING.put("柳州银行", "313614000012|柳州银行");
        BANK_MAPPING.put("桂林银行股份有限公司", "313617000018|桂林银行股份有限公司");
        BANK_MAPPING.put("海南银行股份有限公司", "313641099995|海南银行股份有限公司");
        BANK_MAPPING.put("成都银行", "313651099999|成都银行");
        BANK_MAPPING.put("重庆银行股份有限公司", "313653000013|重庆银行股份有限公司");
        BANK_MAPPING.put("攀枝花市商业银行", "313656000019|攀枝花市商业银行");
        BANK_MAPPING.put("泸州市商业银行", "313657092617|泸州市商业银行");
        BANK_MAPPING.put("德阳银行", "313658000014|德阳银行");
        BANK_MAPPING.put("绵阳市商业银行", "313659000016|绵阳市商业银行");
        BANK_MAPPING.put("遂宁商行", "313662000015|遂宁商行");
        BANK_MAPPING.put("乐山市商业银行", "313665092924|乐山市商业银行");
        BANK_MAPPING.put("宜宾市商业银行", "313671000017|宜宾市商业银行");
        BANK_MAPPING.put("南充市商业银行", "313673093259|南充市商业银行");
        BANK_MAPPING.put("达州银行", "313675090019|达州银行");
        BANK_MAPPING.put("贵阳银行", "313701098010|贵阳银行");
        BANK_MAPPING.put("贵州银行", "313701099012|贵州银行");
        BANK_MAPPING.put("富滇银行", "313731010015|富滇银行");
        BANK_MAPPING.put("曲靖市商业银行", "313736000019|曲靖市商业银行");
        BANK_MAPPING.put("玉溪市商业银行", "313741095715|玉溪市商业银行");
        BANK_MAPPING.put("西藏银行", "313770000016|西藏银行");
        BANK_MAPPING.put("西安银行", "313791000015|西安银行");
        BANK_MAPPING.put("长安银行", "313791030003|长安银行");
        BANK_MAPPING.put("兰州银行股份有限公司", "313821001016|兰州银行股份有限公司");
        BANK_MAPPING.put("甘肃银行", "313821050016|甘肃银行");
        BANK_MAPPING.put("青海银行", "313851000018|青海银行");
        BANK_MAPPING.put("宁夏银行", "313871000007|宁夏银行");
        BANK_MAPPING.put("石嘴山银行", "313872097457|石嘴山银行");
        BANK_MAPPING.put("乌鲁木齐银行", "313881000002|乌鲁木齐银行");
        BANK_MAPPING.put("昆仑银行", "313882000012|昆仑银行");
        BANK_MAPPING.put("新疆汇和银行（清算行）", "313898100016|新疆汇和银行（清算行）");
        BANK_MAPPING.put("天津滨海农村商业银行股份有限公司", "314110000011|天津滨海农村商业银行股份有限公司");
        BANK_MAPPING.put("大连农村商业银行", "314222001893|大连农村商业银行");
        BANK_MAPPING.put("吉林双阳农村商业银行股份有限公司", "314241013003|吉林双阳农村商业银行股份有限公司");
        BANK_MAPPING.put("无锡农村商业银行", "314302066666|无锡农村商业银行");
        BANK_MAPPING.put("江阴农商银行", "314302200018|江阴农商银行");
        BANK_MAPPING.put("江南农村商业银行", "314304099999|江南农村商业银行");
        BANK_MAPPING.put("苏州银行", "314305006665|苏州银行");
        BANK_MAPPING.put("太仓农商行", "314305106644|太仓农商行");
        BANK_MAPPING.put("昆山农村商业银行", "314305206650|昆山农村商业银行");
        BANK_MAPPING.put("吴江农村商业银行", "314305400015|吴江农村商业银行");
        BANK_MAPPING.put("常熟农村商业银行", "314305506621|常熟农村商业银行");
        BANK_MAPPING.put("张家港农村商业银行", "314305670002|张家港农村商业银行");
        BANK_MAPPING.put("广州农村商业银行", "314581000011|广州农村商业银行");
        BANK_MAPPING.put("顺德农村商业银行", "314588000016|顺德农村商业银行");
        BANK_MAPPING.put("江门融和农村商业银行股份有限公司", "314589000018|江门融和农村商业银行股份有限公司");
        BANK_MAPPING.put("海口联合农村商业银行", "314641000014|海口联合农村商业银行");
        BANK_MAPPING.put("成都农村商业银行股份有限公司", "314651000000|成都农村商业银行股份有限公司");
        BANK_MAPPING.put("重庆农村商业银行", "314653000011|重庆农村商业银行");
        BANK_MAPPING.put("恒丰银行", "315456000105|恒丰银行");
        BANK_MAPPING.put("浙商银行", "316331000018|浙商银行");
        BANK_MAPPING.put("天津农商银行", "317110010019|天津农商银行");
        BANK_MAPPING.put("渤海银行", "318110000014|渤海银行");
        BANK_MAPPING.put("徽商银行", "319361000013|徽商银行");
        BANK_MAPPING.put("北京昌平包商村镇银行股份有限公司", "320100018169|北京昌平包商村镇银行股份有限公司");
        BANK_MAPPING.put("北京怀柔融兴村镇银行", "320100023015|北京怀柔融兴村镇银行");
        BANK_MAPPING.put("天津津南村镇银行股份有限公司", "320110000028|天津津南村镇银行股份有限公司");
        BANK_MAPPING.put("河间融惠村镇银行有限责任公司", "320144300038|河间融惠村镇银行有限责任公司");
        BANK_MAPPING.put("清徐惠民村镇银行有限责任公司", "320161006008|清徐惠民村镇银行有限责任公司");
        BANK_MAPPING.put("内蒙古和林格尔包商村镇银行有限责任公司", "320191003012|内蒙古和林格尔包商村镇银行有限责任公司");
        BANK_MAPPING.put("固阳包商村镇银行股份有限公司", "320192200018|固阳包商村镇银行股份有限公司");
        BANK_MAPPING.put("赤峰市红山玉龙村镇银行有限责任公司", "320194001004|赤峰市红山玉龙村镇银行有限责任公司");
        BANK_MAPPING.put("赤峰市元宝山玉龙村镇银行有限责任公司", "320194002007|赤峰市元宝山玉龙村镇银行有限责任公司");
        BANK_MAPPING.put("喀喇沁玉龙村镇银行有限责任公司", "320194700008|喀喇沁玉龙村镇银行有限责任公司");
        BANK_MAPPING.put("宁城包商村镇银行有限责任公司", "320194800017|宁城包商村镇银行有限责任公司");
        BANK_MAPPING.put("莫力达瓦包商村镇银行有限责任公司", "320196601004|莫力达瓦包商村镇银行有限责任公司");
        BANK_MAPPING.put("鄂温克包商村镇银行有限责任公司", "320197105004|鄂温克包商村镇银行有限责任公司");
        BANK_MAPPING.put("兴安盟科尔沁包商村镇银行有限公司", "320198000017|兴安盟科尔沁包商村镇银行有限公司");
        BANK_MAPPING.put("西乌珠穆沁包商惠丰村镇银行有限责任公司", "320201700012|西乌珠穆沁包商惠丰村镇银行有限责任公司");
        BANK_MAPPING.put("乌兰察布市集宁包商村镇银行有限责任公司", "320203000109|乌兰察布市集宁包商村镇银行有限责任公司");
        BANK_MAPPING.put("化德包商村镇银行有限责任公司", "320203600016|化德包商村镇银行有限责任公司");
        BANK_MAPPING.put("达尔罕茂明安联合旗包商村镇银行股份有限公", "320204500017|达尔罕茂明安联合旗包商村镇银行股份有限公");
        BANK_MAPPING.put("准格尔旗包商村镇银行有限责任公司", "320205300017|准格尔旗包商村镇银行有限责任公司");
        BANK_MAPPING.put("乌审旗包商村镇银行有限责任公司", "320205700011|乌审旗包商村镇银行有限责任公司");
        BANK_MAPPING.put("大连金州联丰村镇银行股份有限公司", "320222000014|大连金州联丰村镇银行股份有限公司");
        BANK_MAPPING.put("九台龙嘉村镇银行股份有限公司", "320241000010|九台龙嘉村镇银行股份有限公司");
        BANK_MAPPING.put("长春朝阳和润村镇银行股份有限公司", "320241001166|长春朝阳和润村镇银行股份有限公司");
        BANK_MAPPING.put("榆树融兴村镇银行", "320241017017|榆树融兴村镇银行");
        BANK_MAPPING.put("巴彦融兴村镇银行", "320261020018|巴彦融兴村镇银行");
        BANK_MAPPING.put("延寿融兴村镇银行", "320261052015|延寿融兴村镇银行");
        BANK_MAPPING.put("讷河融兴村镇银行有限责任公司", "320264229811|讷河融兴村镇银行有限责任公司");
        BANK_MAPPING.put("拜泉融兴村镇银行", "320265205014|拜泉融兴村镇银行");
        BANK_MAPPING.put("桦南融兴村镇银行有限责任公司", "320272100017|桦南融兴村镇银行有限责任公司");
        BANK_MAPPING.put("桦川融兴村镇银行", "320272338019|桦川融兴村镇银行");
        BANK_MAPPING.put("宁安融兴村镇银行有限责任公司", "320275127816|宁安融兴村镇银行有限责任公司");
        BANK_MAPPING.put("江苏惠山民泰村镇银行", "320302000014|江苏惠山民泰村镇银行");
        BANK_MAPPING.put("江苏南通如皋包商村镇银行股份有限公司", "320306200013|江苏南通如皋包商村镇银行股份有限公司");
        BANK_MAPPING.put("江苏如东融兴村镇银行", "320306303012|江苏如东融兴村镇银行");
        BANK_MAPPING.put("江苏邗江民泰村镇银行", "320312091015|江苏邗江民泰村镇银行");
        BANK_MAPPING.put("江苏仪征包商村镇银行有限责任公司", "320312900017|江苏仪征包商村镇银行有限责任公司");
        BANK_MAPPING.put("宁波海曙国民村镇银行", "320332000015|宁波海曙国民村镇银行");
        BANK_MAPPING.put("象山国民村镇银行", "320332100016|象山国民村镇银行");
        BANK_MAPPING.put("浙江桐乡民泰村镇银行", "320335400016|浙江桐乡民泰村镇银行");
        BANK_MAPPING.put("浙江景宁银座村镇银行", "320343800019|浙江景宁银座村镇银行");
        BANK_MAPPING.put("浙江龙泉民泰村镇银行", "320343900011|浙江龙泉民泰村镇银行");
        BANK_MAPPING.put("安义融兴村镇银行", "320421007514|安义融兴村镇银行");
        BANK_MAPPING.put("乐平融兴村镇银行", "320422100011|乐平融兴村镇银行");
        BANK_MAPPING.put("东营莱商村镇银行股份有限公司", "320455000019|东营莱商村镇银行股份有限公司");
        BANK_MAPPING.put("鄄城包商村镇银行有限责任公司", "320475918197|鄄城包商村镇银行有限责任公司");
        BANK_MAPPING.put("偃师融兴村镇银行", "320493107012|偃师融兴村镇银行");
        BANK_MAPPING.put("新安融兴村镇银行", "320493302510|新安融兴村镇银行");
        BANK_MAPPING.put("漯河市郾城包商村镇银行有限责任公司", "320504000014|漯河市郾城包商村镇银行有限责任公司");
        BANK_MAPPING.put("湖北荆门掇刀包商村镇银行股份有限公司", "320532000013|湖北荆门掇刀包商村镇银行股份有限公司");
        BANK_MAPPING.put("应城融兴村镇银行", "320535204511|应城融兴村镇银行");
        BANK_MAPPING.put("洪湖融兴村镇银行", "320537303517|洪湖融兴村镇银行");
        BANK_MAPPING.put("株洲县融兴村镇银行", "320552105518|株洲县融兴村镇银行");
        BANK_MAPPING.put("耒阳融兴村镇银行", "320554706519|耒阳融兴村镇银行");
        BANK_MAPPING.put("武冈包商村镇银行有限责任公司", "320555600014|武冈包商村镇银行有限责任公司");
        BANK_MAPPING.put("深圳宝安融兴村镇银行", "320584001000|深圳宝安融兴村镇银行");
        BANK_MAPPING.put("广西上林国民村镇银行", "320611000067|广西上林国民村镇银行");
        BANK_MAPPING.put("广西银海国民村镇银行", "320623000015|广西银海国民村镇银行");
        BANK_MAPPING.put("合浦国民村镇银行", "320623100016|合浦国民村镇银行");
        BANK_MAPPING.put("平果国民村镇银行", "320626400049|平果国民村镇银行");
        BANK_MAPPING.put("广西钦州钦南国民村镇银行", "320631100016|广西钦州钦南国民村镇银行");
        BANK_MAPPING.put("广西浦北国民村镇银行", "320631500019|广西浦北国民村镇银行");
        BANK_MAPPING.put("防城港防城国民村镇银行", "320633000027|防城港防城国民村镇银行");
        BANK_MAPPING.put("东兴国民村镇银行", "320633100011|东兴国民村镇银行");
        BANK_MAPPING.put("海南保亭融兴村镇银行", "320641008517|海南保亭融兴村镇银行");
        BANK_MAPPING.put("邛崃国民村镇银行有限责任公司", "320651001015|邛崃国民村镇银行有限责任公司");
        BANK_MAPPING.put("新都桂城村镇银行有限责任公司", "320651012005|新都桂城村镇银行有限责任公司");
        BANK_MAPPING.put("成都青白江融兴村镇银行有限责任公司", "320651013008|成都青白江融兴村镇银行有限责任公司");
        BANK_MAPPING.put("重庆九龙坡民泰村镇银行", "320653000137|重庆九龙坡民泰村镇银行");
        BANK_MAPPING.put("重庆市沙坪坝融兴村镇银行", "320653000153|重庆市沙坪坝融兴村镇银行");
        BANK_MAPPING.put("重庆市大渡口融兴村镇银行", "320653056012|重庆市大渡口融兴村镇银行");
        BANK_MAPPING.put("中江融兴村镇银行有限责任公司", "320658200017|中江融兴村镇银行有限责任公司");
        BANK_MAPPING.put("广元市包商贵民村镇银行有限责任公司", "320661300010|广元市包商贵民村镇银行有限责任公司");
        BANK_MAPPING.put("遂宁安居融兴村镇银行", "320662047017|遂宁安居融兴村镇银行");
        BANK_MAPPING.put("武隆融兴村镇银行", "320669509516|武隆融兴村镇银行");
        BANK_MAPPING.put("阆中融兴村镇银行有限责任公司", "320674300000|阆中融兴村镇银行有限责任公司");
        BANK_MAPPING.put("重庆市酉阳融兴村镇银行", "320687400019|重庆市酉阳融兴村镇银行");
        BANK_MAPPING.put("重庆彭水民泰村镇银行", "320687500011|重庆彭水民泰村镇银行");
        BANK_MAPPING.put("息烽包商黔隆村镇银行有限责任公司", "320701000011|息烽包商黔隆村镇银行有限责任公司");
        BANK_MAPPING.put("贵阳花溪建设村镇银行有限责任公司", "320701000038|贵阳花溪建设村镇银行有限责任公司");
        BANK_MAPPING.put("毕节发展村镇银行有限责任公司", "320709000026|毕节发展村镇银行有限责任公司");
        BANK_MAPPING.put("会宁会师村镇银行", "320824275019|会宁会师村镇银行");
        BANK_MAPPING.put("天水麦积融兴村镇银行有限责任公司", "320825010014|天水麦积融兴村镇银行有限责任公司");
        BANK_MAPPING.put("平凉崆峒融兴村镇银行有限责任公司", "320833000013|平凉崆峒融兴村镇银行有限责任公司");
        BANK_MAPPING.put("宁夏贺兰回商村镇银行有限责任公司", "320871000018|宁夏贺兰回商村镇银行有限责任公司");
        BANK_MAPPING.put("新疆绿洲国民村镇银行", "320881000011|新疆绿洲国民村镇银行");
        BANK_MAPPING.put("克拉玛依金龙国民村镇银行", "320882000013|克拉玛依金龙国民村镇银行");
        BANK_MAPPING.put("哈密红星国民村镇银行", "320884000025|哈密红星国民村镇银行");
        BANK_MAPPING.put("昌吉国民村镇银行", "320885099990|昌吉国民村镇银行");
        BANK_MAPPING.put("库车国民村镇银行", "320891300000|库车国民村镇银行");
        BANK_MAPPING.put("伊犁国民村镇银行", "320898000010|伊犁国民村镇银行");
        BANK_MAPPING.put("奎屯国民村镇银行", "320898100019|奎屯国民村镇银行");
        BANK_MAPPING.put("石河子国民村镇银行", "320902800016|石河子国民村镇银行");
        BANK_MAPPING.put("重庆三峡银行", "321667090019|重庆三峡银行");
        BANK_MAPPING.put("上海农村商业银行", "322290000011|上海农村商业银行");
        BANK_MAPPING.put("北京中关村银行", "323100000012|北京中关村银行");
        BANK_MAPPING.put("吉林亿联银行", "323241000016|吉林亿联银行");
        BANK_MAPPING.put("华瑞银行", "323290000016|华瑞银行");
        BANK_MAPPING.put("苏宁银行", "323301000019|苏宁银行");
        BANK_MAPPING.put("浙江网商银行", "323331000001|浙江网商银行");
        BANK_MAPPING.put("温州民商银行股份有限公司", "323333000013|温州民商银行股份有限公司");
        BANK_MAPPING.put("华通银行", "323391060018|华通银行");
        BANK_MAPPING.put("湖南三湘银行", "323551000015|湖南三湘银行");
        BANK_MAPPING.put("深圳前海微众银行", "323584000888|深圳前海微众银行");
        BANK_MAPPING.put("梅州客商银行", "323596001013|梅州客商银行");
        BANK_MAPPING.put("四川新网银行", "323651066666|四川新网银行");
        BANK_MAPPING.put("重庆富民银行", "323653010015|重庆富民银行");
        BANK_MAPPING.put("上海银行", "325290000012|上海银行");
        BANK_MAPPING.put("中信百信银行", "326100010008|中信百信银行");
        BANK_MAPPING.put("北京农村商业银行", "402100000018|北京农村商业银行");
        BANK_MAPPING.put("自治区联社", "402191009992|自治区联社");
        BANK_MAPPING.put("辽宁省农村信用社联合社运营管理部", "402221010013|辽宁省农村信用社联合社运营管理部");
        BANK_MAPPING.put("吉林农村信用社", "402241000015|吉林农村信用社");
        BANK_MAPPING.put("江苏省农村信用社联合社", "402301099998|江苏省农村信用社联合社");
        BANK_MAPPING.put("鄞州银行", "402332010004|鄞州银行");
        BANK_MAPPING.put("安徽省农村信用社联合社", "402361018886|安徽省农村信用社联合社");
        BANK_MAPPING.put("福建省农村信用社", "402391000068|福建省农村信用社");
        BANK_MAPPING.put("农村信用社", "402421099990|农村信用社");
        BANK_MAPPING.put("山东省农联社", "402451000010|山东省农联社");
        BANK_MAPPING.put("河南省农信联社", "402491000026|河南省农信联社");
        BANK_MAPPING.put("湖北农信", "402521000032|湖北农信");
        BANK_MAPPING.put("武汉农村商业银行", "402521090019|武汉农村商业银行");
        BANK_MAPPING.put("湖南省农村信用社", "402551080008|湖南省农村信用社");
        BANK_MAPPING.put("广东省农信", "402581090008|广东省农信");
        BANK_MAPPING.put("深圳农商行", "402584009991|深圳农商行");
        BANK_MAPPING.put("东莞农村商业银行", "402602000018|东莞农村商业银行");
        BANK_MAPPING.put("广西农村信用社（合作银行）", "402611099974|广西农村信用社（合作银行）");
        BANK_MAPPING.put("海南省农村信用社", "402641000014|海南省农村信用社");
        BANK_MAPPING.put("四川省联社", "402651020006|四川省联社");
        BANK_MAPPING.put("贵州省农村信用社联合社", "402701002999|贵州省农村信用社联合社");
        BANK_MAPPING.put("云南省农村信用社", "402731057238|云南省农村信用社");
        BANK_MAPPING.put("陕西信合", "402791000010|陕西信合");
        BANK_MAPPING.put("甘肃省农村信用社联合社", "402821000015|甘肃省农村信用社联合社");
        BANK_MAPPING.put("黄河农村商业银行", "402871099996|黄河农村商业银行");
        BANK_MAPPING.put("邮政储蓄", "403100000004|中国邮政储蓄银行");
        BANK_MAPPING.put("汇丰银行(中国)有限公司上海分行", "501290000012|汇丰银行(中国)有限公司上海分行");
        BANK_MAPPING.put("东亚银行（中国）有限公司", "502290000006|东亚银行（中国）有限公司");
        BANK_MAPPING.put("花旗银行", "531290088881|花旗银行");
        BANK_MAPPING.put("友利银行", "593100000020|友利银行");
        BANK_MAPPING.put("新韩银行中国", "595100000007|新韩银行中国");
        BANK_MAPPING.put("企业银行", "596110000013|企业银行");
        BANK_MAPPING.put("韩亚银行", "597100000014|韩亚银行");
        BANK_MAPPING.put("华侨永亨银行（中国）有限公司", "621290000011|华侨永亨银行（中国）有限公司");
        BANK_MAPPING.put("中德银行", "717110000010|中德银行");
        BANK_MAPPING.put("厦门国际银行", "781393010011|厦门国际银行");
        BANK_MAPPING.put("富邦华一银行", "787290000019|富邦华一银行");

    }
    public BBGOnlineBank(Integer id, String accountCode, String hostname, Integer port){
        super("BBG", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);

        //  初始化訊息框
        initBBGMessageBox();
        sleep(3000);
        loginByPassword();

    }

    private void loginByPassword() throws Exception{

        BBGMessageBox("Start 用户名登陆");
        String js  = "chooseType(1);";
        driver.executeScript(js );
        sleep(700);
        js = " document.getElementById('customerAlias').value = '" + username +"'";
        driver.executeScript(js );
        sleep(700);
        js = "document.getElementById('customerAlias').focus();";
        driver.executeScript(js );
        press(new String[]{"Tab"}, 100, 50);
        BBGMessageBox("Type password");
        pressText(password);
        press(new String[]{"Tab"}, 100, 50);
        BBGMessageBox("Please enter code");
        WebElement code = driver.findElement(By.id("verifyCode"));
        click(code.getLocation().x,code.getLocation().y);
        // 等待页面 登陆
        waitPageChange("return  document.getElementById('mainFrame').getAttribute('id')","mainFrame" ,60);
        waiting();
    }


    @Override
    public void logout() throws Exception {

    }
    public String getBal() throws Exception {
        driver.switchTo().window(windowHandle);
        driver.executeScript("linkTo('001002_AccountQuery_Jump.do');" );
        driver.switchTo().frame("mainFrame");
        waitPageElement("btnQueryOneCard",15);
        driver.switchTo().window(windowHandle);
        pageJS("f1 = document.getElementById('mainFrame').contentDocument;f1.getElementById('btnQueryOneCard').click()" );
        sleep(2000);
        String  bal = driver.executeScript(" list = f1.getElementsByClassName('text_content');return list[15].innerHTML +' '").toString().trim();
        bal = bal.replaceAll(",","");
        logger.info("get banlance=" + bal);
        return  bal;
    }
    @Override
    public void checkBalance(BigDecimal balance) throws Exception {
        initBBGMessageBox();
        BBGMessageBox("Fetch balance");
        String bal = getBal();
        if(bal.length()>1) {
            this.balance = new BigDecimal(bal);
        }else {
            this.balance = balance;
        }
        if(this.balance.compareTo(balance) != 0){
            BBGMessageBox("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
        }else{
            BBGMessageBox("Balance:" + bal);
        }
        logger.info("get banlance=" + bal);
    }



    @Override
    public BigDecimal getPageBalance( ) throws  Exception{

        BBGMessageBox("Fetch balance");
        String bal = getBal();
        if(bal.length()>0) {
            this.balance = new BigDecimal(bal);
        }
        return this.balance;
    }


    @Override
    public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount,String memberBankProvince,String memberBankCity,String memberBankBranch ) throws Exception {
        TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        String imagePath =  "";
        Object charge = null;

        BBGMessageBox("Start transaction");
        driver.switchTo().window(windowHandle);
        driver.executeScript("linkTo('002002_ExternalTransfer.do');" );
        sleep(6000);
        // 获取窗体对象
        driver.executeScript("f1 = document.getElementById('mainFrame').contentDocument; " );
        // 行内0 (跨行1)
        driver.executeScript("boxes = f1.getElementsByName('transferMethod');for(i=0;i<boxes.length;i++){if(boxes[i].value == '1'){boxes[i].click();break;}}");
        sleep(100);
        driver.executeScript("boxes = f1.getElementsByName('trade_type');for(i=0;i<boxes.length;i++){if(boxes[i].value == '2'){boxes[i].click();break;}}");
        driver.executeScript("f1.getElementById('recAccName').focus()");
        // bank
        driver.executeScript("f1 = document.getElementById('mainFrame').contentWindow;		 f1.queryBank();");
        sleep(7000);
        String js="f1 = document.getElementById('mainFrame').contentWindow.frames[0];f1.bankSelect('"+  BANK_MAPPING.get(bankName)  + "')";
        driver.executeScript(js);
        // bank end
        // 获取窗体对象
        driver.executeScript("f1 = document.getElementById('mainFrame').contentDocument; " );
        //金额
        driver.executeScript("f1.getElementById('txtTranAmt').value ='"+ amount+"'");
        driver.executeScript("f1.getElementById('txtTranAmt').focus()");
        driver.executeScript("f1.getElementById('txtTranAmt').blur()");
        // 收款账户号
        js = "f1.getElementById('recAccount').value ='"+ accountNumber+"'";
        String checkJs =   "return f1.getElementById('recAccount').value";
        tryToPutValue(js,checkJs,accountNumber);
        // 收款账户名
        js = "f1.getElementById('recAccName').value ='"+ accountName+"'";
        checkJs ="return f1.getElementById('recAccName').value ";
        tryToPutValue(js,checkJs,accountName);
        // record page value
        logger.info("=============================>>>>record get back of page value");
        logger.info(driver.executeScript(  "return f1.getElementById('recAccName').value "));
        logger.info(driver.executeScript(  "return f1.getElementById('recAccount').value"));
        logger.info(driver.executeScript(  "return f1.getElementById('txtTranAmt').value"));

        BBGMessageBox("clicked 下一步");
        sleep(300);
        driver.executeScript("f1.getElementById('nextButton').click()");
        sleep(3000);
        driver.executeScript("f1 = document.getElementById('mainFrame').contentDocument; " );
        charge = driver.executeScript("list = f1.getElementById('inputForm').getElementsByClassName('text_important');return list[1].innerText ").toString();
        BBGMessageBox("get 手 续 费 :" + charge );
        BBGMessageBox("auto put password"  );
        // 这里可能需要 改为农业银行一样 插入一个input 框进行 focus
        this.click(500,300);
        press(new String[]{"Tab"}, 1000, 200);
        press(new String[]{"Tab"}, 1000, 200);
        press(new String[]{"Tab"}, 1000, 200);
        pressText(queryPassword);
        press(new String[]{"Tab"}, 1000, 200);
        BBGMessageBox("please enter code"  );
        Object[] options = {"Yes,是的", "No,取消¦"};
        JOptionPane.showOptionDialog(null, " finish code ?", "询问 ", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options,null);

        driver.executeScript("f1 = document.getElementById('mainFrame').contentDocument;f1.getElementById('submitButton').click()");
        sleep(15000);
        // 完成提交 完成手动点击确定
        // 输入 交易密码
        pressText(usbPassword);
        press(new String[]{"Enter"}, 1000, 200);
        // 循环等待
        WebDriverWait wait = new WebDriverWait(driver, 12);
        int waitCount = 20;
        while(waitCount > 0) {
            try {
                waitCount --;
                sleep(1000);
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("transferId")));
                logger.info("本行代码已经执行,获取到成功标识");
                break;
            } catch (TimeoutException e) {
                logger.info("wait element timeout exception:" + e.getMessage());

            }
            catch (Exception e) {
                logger.info("wait exception:" + e.getMessage());
            }

        }

        charge = pageJS("return $('#showFee').text() ");

        if(charge == null ){
            taskLog.setCharge("0.0");
        } else {
            String tmp = charge.toString();
            tmp = tmp.split("元")[0];
            taskLog.setCharge(tmp);
        }
        logger.info(charge);  // 0.00元(免费)

        taskLog = checkTransfer(amount,taskLog,"10.00");
        return handleCheck(charge.toString().length() >0,id,taskLog) ;

    }

    @Override
    public void queryTransaction() throws Exception {
        driver.switchTo().window(windowHandle);
    }


    public   void initBBGMessageBox() throws Exception {
        String js = "";
        js+="var msgDiv=document.createElement('div');";
        js+="msgDiv.id='payment-msg';";
        js+="msgDiv.innerHTML='init';";
        js+="msgDiv.style.color='white';";
        js+="msgDiv.style.width='150px';";
        js+="msgDiv.style.padding='30px';";
        js+="msgDiv.style.height='50px';";
        js+="msgDiv.style.position='absolute';";
        js+="msgDiv.style.left='10px';";
        js+="msgDiv.style.top='30px';";
        js+="msgDiv.style.backgroundColor='black';";
        js+="document.body.appendChild(msgDiv);";
        driver.executeScript(js);
    }
    public   void BBGMessageBox(String message) throws Exception {
        driver.executeScript("document.getElementById('payment-msg').innerHTML ='" + message +"'");
    }
}
 