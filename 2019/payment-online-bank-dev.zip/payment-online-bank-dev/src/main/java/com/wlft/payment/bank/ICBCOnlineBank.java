package com.wlft.payment.bank;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import java.util.concurrent.TimeUnit;

import com.wlft.payment.common.PressThread;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.exception.BankException;
import org.openqa.selenium.*;
import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.seimicrawler.xpath.JXDocument;
import tcg.windowDetecter.contracts.BankEnum;

import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;
import static io.github.seleniumquery.SeleniumQuery.$;
import static java.lang.Thread.sleep;

public class ICBCOnlineBank extends OnlineBank {

    private static Logger logger = Logger.getLogger(ICBCOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {
        BANK_MAPPING.put("工商银行", "setBankInfo(102,'中国工商银行')");
        BANK_MAPPING.put("中国农业银行", "setBankInfo(103,'中国农业银行')");
        BANK_MAPPING.put("中国银行", "setBankInfo(104,'中国银行')");
        BANK_MAPPING.put("中国建设银行", "setBankInfo(105,'中国建设银行')");
        BANK_MAPPING.put("交通银行", "setBankInfo(301,'交通银行')");
        BANK_MAPPING.put("中信银行", "setBankInfo(302,'中信银行')");
        BANK_MAPPING.put("中国光大银行", "setBankInfo(303,'中国光大银行')");
        BANK_MAPPING.put("华夏银行", "setBankInfo(304,'华夏银行')");
        BANK_MAPPING.put("中国民生银行", "setBankInfo(305,'中国民生银行')");
        BANK_MAPPING.put("广发银行", "setBankInfo(306,'广发银行')");
        BANK_MAPPING.put("平安银行", "setBankInfo(307,'平安银行')");
        BANK_MAPPING.put("招商银行", "setBankInfo(308,'招商银行')");
        BANK_MAPPING.put("兴业银行", "setBankInfo(309,'兴业银行')");
        BANK_MAPPING.put("上海浦东发展银行", "setBankInfo(310,'上海浦东发展银行')");
        BANK_MAPPING.put("城市商业银行", "setBankInfo(313,'城市商业银行')");
        BANK_MAPPING.put("农村商业银行", "setBankInfo(314,'农村商业银行')");
        BANK_MAPPING.put("恒丰银行", "setBankInfo(315,'恒丰银行')");
        BANK_MAPPING.put("浙商银行", "setBankInfo(316,'浙商银行')");
        BANK_MAPPING.put("渤海银行", "setBankInfo(318,'渤海银行')");
        BANK_MAPPING.put("邮政储蓄", "setBankInfo(403,'邮政储汇')");
    }

    public ICBCOnlineBank(Integer id, String accountCode, String hostname, Integer port) {
        super("ICBC", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);
        loginByPassword();
    }

    private void loginByPassword() throws Exception {
        int count = 60;
        // 如果有登陆前的map 引导 则清理
        clearPage(driver);
        //  初始化訊息框
        initMessageBox();
        setMessage("Start 用户名登陆");
        driver.switchTo().frame("ICBC_login_frame");
        try {
            new WebDriverWait(driver, 7).until((ExpectedCondition<Boolean>) wd ->
                    ((JavascriptExecutor) wd).executeScript("return $('#logonCardNum').val()").equals(""));
        } catch (Throwable e) {

        }
        // 输入用户名
        String js = "$('#logonCardNum').val('" + username + "').focus().click()";
        driver.executeScript(js);
        press(new String[]{"Tab"}, 100, 50);
        // 输入密码
        setMessage("Type password");
        pressText(password);
        // 输入密码后的全屏截图
        PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        // 等待操作员页面输入验证码 后登陆
        setMessage("Wait code value and login");
        // 60 秒内等待输入验证码与 登陆
        driver.switchTo().window(windowHandle);
        while (true) {
            sleep(1000);
            count -- ;
            if ( driver.executeScript("return document.getElementById('ICBC_login_frame')+1").toString().length() < 6  || count == 0 ) {
                logger.info(" NEW PAGE  ");
                break;
            }
        }
        driver.switchTo().window(windowHandle);
        // 如果是进入的USBkey 认证页面
        if (driver.getCurrentUrl().indexOf("ICBCINBSReqServlet") > 0) {
            try {
                initMessageBox();
                setMessage("USBkey = " + usbPassword);
                driver.manage().timeouts().setScriptTimeout(2, TimeUnit.SECONDS);
                driver.executeScript(" $('body').find('#ebdp-pc4promote-menu-level1-text-2').trigger('click')");
                sleep(1100);
                driver.executeScript("     document.getElementById('integratemainFrame').contentDocument.getElementById('queding').click()   "); //   driver.findElement(By.id("queding")).click();

            } catch (Throwable e) {

            }
            sleep(11000);
            getPgaeBox(BankEnum.PSBC,0.7);
            PcUtils.clickScreen(boxPoint.passwordX,boxPoint.passwordY);
            pressText(usbPassword);
            PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
            sleep(2000);
            press(new String[]{"Enter"}, 100, 50);
            // 等待人员操作 按下 15 秒  in this time to get the button
            count = 15;
            while (true) {
                try {
                    sleep(1000);
                    count--;
                    if ( count == 0) {
                        break;
                    }
                    driver.executeScript("$('body').contents().find('#integratemainFrame').contents().find('#queding').click()");
                    logger.info("  $('body').contents().find('#integratemainFrame').contents().find('#queding').click() ");
                } catch (Throwable e) {

                }
            }
            // 页面再次刷新 准备离开认证页面
            waitPageChange("return  window.location.href","frame_index" ,60);
        } // end if 完成认证

        // 清理登陆后的map 引导
        clearPage2(driver);
        // 清理登陆后的 广告
        clearPageAdv(driver);
        sleep(3000);

        // 为查询余额做准备
        driver.switchTo().window(windowHandle);
        driver.executeScript("$('#PBL201786r').click()");
        sleep(2000);
        driver.switchTo().frame("perbank-content-frame");

    }


    @Override
    public void logout() throws Exception {

    }
    public String getBal() throws Exception {
        setMessage("Fetch balance");
        driver.switchTo().window(windowHandle);
        driver.switchTo().frame("perbank-content-frame");
        driver.switchTo().frame("content-frame");
        String html = $("body").html();
        JXDocument body = JXDocument.create(html);//kabao-main
        String xpath = "//table/tbody/tr/td[2]/table/tbody/tr/td/div/div[@class='kabao-block']/div/div[@class='kabao-list']/div[@class='kabao-main']/div[@id='li_1']/div[@class='kabao-main-item-box']/div[@class='kabao-main-item-center']/div/div/table/tbody/tr/td[3]/span/html()";
        List<Object> res = body.sel(xpath);
        String bal = StringUtils.join(res, ",");
        //  用户在某些设定中显示有了美元... 获取大的值如 274.50,0.00
        bal = bal.substring(0, bal.indexOf(".") + 3);
        bal = bal.replaceAll(",", "");
        return  bal;
    }
    @Override
    public void checkBalance(BigDecimal balance) throws Exception {
        String bal = getBal();
        showBalance(bal,balance);
        logger.info("get banlance=" + bal);
    }



    @Override
    public BigDecimal getPageBalance() throws Exception {

        driver.switchTo().window(windowHandle);
        driver.executeScript("$('#PBL201786r').click()");
        driver.switchTo().window(windowHandle);
        initMessageBox();
        String bal = getBal();
        if (bal.length() > 0) {
            logger.info("找到餘額 bal= " + bal);
            this.balance = new BigDecimal(bal);
        }
        return this.balance;

    }

    public boolean isRequireMobile() throws Exception {
        driver.switchTo().window(windowHandle);
        driver.switchTo().frame("perbank-content-frame");
        driver.switchTo().frame("content-frame");
        logger.info("开始手机检测");
        String mobile = driver.executeScript("return $('#getSMSCode').text()+' '").toString();
        if(mobile.length()>2) {
            logger.info("是手机验证哦,info="+ mobile);
            driver.executeScript("$('#otherMedium').click()");
            sleep(500);
            driver.executeScript("$('#ebdp-pc4promote-floattip0').click()");
            return true;
        } else {
            return false;
        }
    }

    @Override
    public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount, String memberBankProvince, String memberBankCity, String memberBankBranch) throws Exception {

        TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        int count = 5;

        //  初始化pending
        initPending();
        setMessage("Start transaction");
        //  跳轉至轉帳頁面
        driver.executeScript("$('#PBL200811r').click()");
        driver.switchTo().window(windowHandle);
        driver.switchTo().frame("perbank-content-frame");
        //  waiting
        waiting();
        //  初始化pending
        initMessageBox();
        initPending();
        setMessage("Mask fields");
        driver.switchTo().frame("perbank-content-frame");
        driver.switchTo().frame("content-frame");
        driver.executeScript("$('#recNameShow').after('<div class=\"payment-masker\" style=\"position:absolute; left:25px; top:10px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#recAcctShow').after('<div class=\"payment-masker\" style=\"position:absolute; left:30px; top:0px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#bankListShow').after('<div class=\"payment-masker\" style=\"position:absolute; left:30px; top:-14px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        //  加入移除遮照的事件
        // driver.executeScript("$('.payment-masker').on('click', function(){var ans = prompt('Please enter password', ''); if(ans == 5201314){$('.payment-masker').remove();}})");
        driver.executeScript("$('#remitAmtInput').val('" + amount + "').focus().click()");

        String js = "$('#recNameShow').val('" + accountName + "')";
        String checkJs =     "return $('#recNameShow').val()";
        tryToPutValue(js,checkJs,accountName);

        js ="$('#recAcctShow').val('" + accountNumber + "').focus().click()";
        checkJs =     "return $('#recAcctShow').val()";
        tryToPutValue(js,checkJs,accountNumber);


        logger.info("=============================>>>>record get back of page value");
        logger.info(driver.executeScript( "return $('#recNameShow').val()"));
        logger.info(driver.executeScript( "return $('#recAcctShow').val()"));
        logger.info(driver.executeScript( "return $('#remitAmtInput').val()"));
        logger.info("set bank " + BANK_MAPPING.get(bankName) );
        js =  BANK_MAPPING.get(bankName);
        if(js != null){
            driver.executeScript(BANK_MAPPING.get(bankName));
        } else {
            logger.info("js  null");
            driver.switchTo().window(windowHandle);
            int cc = 3;
            while (cc>0){
                driver.executeScript(" document.getElementById(\"perbank-content-frame\").contentWindow.document.getElementById(\"content-frame\").contentWindow.setBankInfo(313,'城市商业银行')");
                if(bankName.contains("安徽农金") || bankName.contains("安徽省农村信用社")){
                    driver.executeScript(" document.getElementById(\"perbank-content-frame\").contentWindow.document.getElementById(\"content-frame\").contentWindow.setBankInfo(402,'农村信用合作社')");
                    bankName = "安徽省农村信用社联合社资金清算中心（不转汇）";

                }
                if(memberBankBranch.contains("淮南通商银行")){
                    driver.executeScript(" document.getElementById(\"perbank-content-frame\").contentWindow.document.getElementById(\"content-frame\").contentWindow.setBankInfo(314,'农村商业银行')");
                    memberBankBranch = memberBankBranch.replaceAll("银行","农村商业银行股份有限公司");
                    bankName = memberBankBranch;
                }
                cc--;
                sleep(1000);
            }

            sleep(3000);
            driver.switchTo().frame("perbank-content-frame");
            driver.switchTo().frame("content-frame");

            // js 触发查询
            driver.executeScript(" $('#findType_KeyWord').click()");
            sleep(3000);
            memberBankBranch = memberBankBranch.replaceAll("营业部","");
            if(bankName.contains("安徽农金") || bankName.contains("安徽省农村信用社")){
                memberBankBranch = "安徽省农村信用社联合社资金清算中心（不转汇）";
                bankName = memberBankBranch;
            }
            bankName  = bankName.trim();
            memberBankBranch = memberBankBranch.trim(); // 一定不要有空格
            driver.executeScript("$('#searchKeyWord').val('"+memberBankBranch+"')");
            sleep(1000);

            driver.executeScript("$('.search-btn').click()");
            logger.info("focus end ");
            sleep(1500);
            js  =  "var all = $('#recOpenNetShow').find('option');";
            js += "$.each(all,function(i,o){  if(o.innerText.indexOf('"+bankName+"')>-1){   o.selected=true; } }) ";
            driver.executeScript(js);

        }
        driver.executeScript("$('#remitAmtInput').blur()");
        driver.executeScript("$('#recAcctShow').focus().click()");
        sleep(2000);
        this.setMessage("Click 下一步");

        try {
            driver.switchTo().window(windowHandle);
            driver.executeScript(" $('body').contents().find('#perbank-content-frame').contents().find('#content-frame').contents().find('#tijiao').trigger('click')");
            logger.info("提交了 下一步 按钮");
            driver.switchTo().frame("perbank-content-frame");
            driver.switchTo().frame("content-frame");
            waiting();
        } catch (Exception e) {
            throw new BankException("赋值页面错误", taskLog);
        }

        String charge = driver.executeScript("return $('#Fee-Money').text() +' '").toString(); //"（手续费：7.50元）"
        setMessage(" get charge = " + charge);
        if (charge.length() > 1) {
            charge = charge.substring(5);
            charge = charge.replaceAll("元）", "");
            taskLog.setCharge(charge);
        }
        // 是否显示手机验证
        if (isRequireMobile()) {
            sleep(2000);
        }
        try {
            logger.info("try to click this count = " + count);
            driver.switchTo().window(windowHandle);
            driver.manage().timeouts().setScriptTimeout(2, TimeUnit.SECONDS);
            driver.executeScript(" $('body').contents().find('#perbank-content-frame').contents().find('#content-frame').contents().find('#queren').trigger('click')");
        } catch (Throwable x) {
            x.printStackTrace();
        }

        logger.info("step ====  1");
        sleep(12000);  // 睡眠时间越长 越安全 等待后 输入密码 有些驱动需要手动点击 驱动的确认按钮
        getPgaeBox(BankEnum.PSBC,0.7);
        PcUtils.clickScreen(boxPoint.passwordX,boxPoint.passwordY);

        PcUtils.captureScreen(this.code, "page_driver_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        pressText(usbPassword);
        PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        press(new String[]{"Enter"}, 1000, 50);
        //呼叫: 开启 声音提示操作人员按下 OK
        PcUtils.sound();


        String tag = "";
        int waitTime = 20;
        while (waitTime > 0) {
            try {
                waitTime--;
                sleep(1000);
                driver.switchTo().window(windowHandle);
                // 全屏截图
                PcUtils.captureScreen(this.code, "page_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
                driver.switchTo().frame("perbank-content-frame");
                driver.switchTo().frame("content-frame");
                PcUtils.captureScreen(this.code, "page_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
                tag = driver.findElement(By.className("middleFontSize")).getText();
                logger.info("tag=" + tag);
                if (tag.length() > 0) {
                    break;
                }

            } catch (Throwable e) {
                // 全屏截图
                PcUtils.captureScreen(this.code, "page_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
            }
        }
        // 多等待一下 再切 infrme 能减少拿不到 标识的错误
        driver.switchTo().window(windowHandle);
        driver.switchTo().frame("perbank-content-frame");
        WebDriverWait wait = new WebDriverWait(driver, 15 );
        PcUtils.captureScreen(this.code, "page_ICBC_showINFO_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        PcUtils.writeFile("C://tmp/my_ICBC_html_"+ DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) +".log",$("body").html());
        try{ // 7-10
            wait.until(ExpectedConditions.presenceOfElementLocated(By.id("content-frame"))); // this code bug
            driver.switchTo().frame("content-frame");
            driver.switchTo().window(windowHandle);
            tag += driver.executeScript("return  '1'+ $('body').contents().find('#perbank-content-frame').contents().find('#content-frame').contents().find('.middleFontSize').text()").toString();
        }catch (Throwable e){
            logger.info("wait again error");
            logger.info(e.getMessage());
        }
        logger.info("tag");
        logger.info(tag);
        setMessage("tag = " + tag);
        logger.info("old balance=" + balance);
        taskLog = checkTransfer(amount,taskLog,"10.00");
        return handleCheck(taskLog.getStatus().equals(TaskLog.SUCCESS) ||  tag.length() > 1 ,id,taskLog) ;
    }

    @Override
    public void queryTransaction() throws Exception {
        driver.switchTo().window(windowHandle);
    }


    private TaskLog fillHandle(BigDecimal id, TaskLog taskLog, String imageName) {
        String imagePath = "\\" + this.code + "\\" + id + "_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_" + imageName + "_.png";
        PcUtils.saveScreen(driver, imagePath);
        taskLog.setStatus(TaskLog.FAIL);
        taskLog.setImg(imagePath);
        new Thread(new Runnable() {
            public void run() {
                PcUtils.open("a.wav");
            }
        }).start();
        return taskLog;
    }


    public boolean clearPage(RemoteWebDriver driver) {
        boolean map = false;
        try {
            //WebElement element  =driver.findElement(By.id("onemap"));
            if (driver.executeScript("return $('#onemap').length").toString().equals("1")) {
                map = true;
                logger.info(" have map before loginPage  有登录前的 map ");
                driver.executeScript("oneclick();");
                logger.info("  oneclick(); ");
                driver.executeScript("twoclick();");
                logger.info("  twoclick(); ");
                driver.executeScript("$('#threemap area').click()");
                logger.info("  $('#threemap area').click() ");
                sleep(2000);
            } else {
                System.out.println(" no map before loginPage  没有登录前的 map ");
                logger.info(" no map before loginPage  没有登录前的 map ");
            }
        } catch (Throwable e) {
            logger.info(" no map before loginPage  没有登录前的 map ");
        }
        return map;
    }

    // 网站导向图示
    public void clearPage2(RemoteWebDriver driver) throws Exception {
        try {
            sleep(700);
            driver.executeScript("$('#threemap area:eq(1)').click()");
            sleep(2000);
        } catch (Exception e) {

        }
    }

    // 清理广告页面
    public void clearPageAdv(RemoteWebDriver driver) throws Exception {

        driver.switchTo().frame("ICBC_window_flot_frame");

        try {
            new WebDriverWait(driver, 2).until(ExpectedConditions.visibilityOfElementLocated(By.id("content-frame")));
            driver.switchTo().frame("content-frame");
            driver.executeScript(" removeAll()");
        } catch (ScriptTimeoutException e) {
            logger.info("wait ScriptTimeoutException ", e);
        } catch (TimeoutException e) {
            logger.info("wait verify div timeout ", e);
        } catch (NoSuchElementException e) {
            logger.info("wait verify div NoSuchElementException", e);
        } catch (Exception e) {

        }

    }
}
