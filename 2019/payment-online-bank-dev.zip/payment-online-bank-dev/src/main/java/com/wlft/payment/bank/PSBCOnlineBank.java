package com.wlft.payment.bank;

import javax.swing.*;
import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.math.BigDecimal;

import com.wlft.payment.common.PressThread;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;
import tcg.windowDetecter.contracts.BankEnum;

import static java.lang.Thread.sleep;
import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;


public class PSBCOnlineBank extends OnlineBank {

    private static Logger logger = Logger.getLogger(PSBCOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {
        BANK_MAPPING.put("工商银行", "中国工商银行");
        BANK_MAPPING.put("邮政储汇", "邮政");
    }

    public PSBCOnlineBank(Integer id, String accountCode, String hostname, Integer port) {
        super("PSBC", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);
        loginByPassword();

    }

    private void loginByPassword() throws Exception {
        //  初始化訊息框
        initMessageBox();
        setMessage("Start 用户名登陆");
        logger.info("login PSBC ");
        driver.executeScript("$('#logType').click()");
        driver.executeScript("$('#logonId').val('" + username + "').focus().click()");

        press(new String[]{"Tab"}, 100, 50);

        setMessage("Type password");
        pressText(password);
        // 输入密码后的全屏截图
        PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");

        setMessage("Wait code value");
        waitPageChange("return  window.location.href","index.html" ,60);
    }


    @Override
    public void logout() throws Exception {

    }
    public String getBal() {
        driver.executeScript("setInterval(function(){ $('#zhezhaoDiv').remove();},3000)");
        driver.executeScript("$('#firsrMenu').children('li:eq(2)').click();");
        waitPageElement("balance",60);
        // CHECK BLANCE
        WebElement balanceElement = driver.findElement(By.id("balance"));
        String bal = balanceElement.getText();
        bal = bal.replaceAll(",", "");
        logger.info("get banlance=" + bal);
        return bal;
    }
    @Override
    public void checkBalance(BigDecimal balance) throws Exception {

        setMessage("Fetch balance");
        driver.switchTo().window(windowHandle);
        // 设置页面定时刷新 函数
        setAutoFlush();
        showBalance(getBal(),balance);

    }


    @Override
    public BigDecimal getPageBalance() throws Exception {
        setMessage("Fetch balance");
        driver.switchTo().window(windowHandle);
        String bal = getBal();
        // 设置页面定时刷新
        driver.executeScript("localStorage.setItem('run','true')");
        if (bal.length() > 0) {
            this.balance = new BigDecimal(bal);
        }
        return this.balance;
    }
    public boolean checkTransfer(BigDecimal amount){
        boolean flag = false;
        try{
            BigDecimal oldBalance = balance;
            getPageBalance();
            if (balance.compareTo(oldBalance.subtract(amount)) < 1) {
                logger.info("transfer is true 转账是正确的 ");
                flag =  true;
            } else {
                logger.info("transfer is false 转账是错误的  ");
                flag =  false;
            }
        }catch (Throwable e){
            logger.info("checkTransfer   catch Throwable  ");
        }
        return flag;
    }
    @Override
    public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount, String memberBankProvince, String memberBankCity, String memberBankBranch) throws Exception {

        TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        String imagePath;
        String charge;
        int count = 3;
        //  初始化pending
        initPending();
        setMessage("Start transaction");
        driver.executeScript("localStorage.setItem('run','false')");
        //  跳轉至轉帳頁面
        driver.executeScript("$('#firsrMenu').children('li:eq(2)').click();");
        driver.switchTo().window(windowHandle);
        waiting();
        waitPageElement("recAccountName",15);
        logger.info("page can see start");
        //  初始化pending
        initMessageBox();
        initPending();
        setMessage("Mask fields");
        logger.info("start transfer Mask fields");
        driver.executeScript("$('#recAccountshow').after('<div class=\"payment-masker\" style=\"position:absolute; left:255px; top:20px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#recAccountName').after('<div class=\"payment-masker\" style=\"position:absolute; left:255px; top:20px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#recAccountOpenBank').after('<div class=\"payment-masker\" style=\"position:absolute; left:255px; top:14px; width:100px; height:22px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");

        //  加入移除遮照的事件
        // driver.executeScript("$('.payment-masker').on('click', function(){var ans = prompt('Please enter password', ''); if(ans == 5201314){$('.payment-masker').remove();}})");
        driver.executeScript("localStorage.setItem('run','not')");
        driver.executeScript("$('#transferSum').val('" + amount + "').focus().click()");
        driver.executeScript("$(\"#transferSum\").after(\"<input  id='payment_point' style='width:10px'/>\")");
        driver.executeScript("var rec = $('#recAccountshow');rec.val('" + accountNumber + "');dealRcvAcc(rec[0]);");
        sleep(500);
        driver.executeScript("$('#recAccountshow').focus();");
        sleep(500);

        driver.executeScript("$('#recAccountshow').blur();$('#recAccountName').val('" + accountName + "').focus().click()");

        String js = "$('#transferSum').val('" + amount + "').focus().click()";
        String checkJs =   "return $('#transferSum').val()";
        tryToPutValue(js,checkJs,amount.toString());

        js = "$('#recAccountshow').blur();$('#recAccountName').val('" + accountName + "').focus().click()";
        checkJs ="return $('#recAccountName').val()";
        tryToPutValue(js,checkJs,accountName);
        // record page value
        logger.info("=============================>>>>record get back of page value");
        logger.info(driver.executeScript( "return $('#recAccountName').val()"));
        logger.info(driver.executeScript( "return $('#recAccountshow').val();"));
        logger.info(driver.executeScript( " return $('#transferSum').val();"));



        click(10, 10);
        // set bank
        //driver.findElement(By.id("payment_point")).sendKeys("1");
        String ss = driver.executeScript("return $('#recAccountOpenBank').val()").toString();//检测银行段是否有值
        logger.info(" start set bank ss = "+ ss);
        if (ss.length() < 3) {
            driver.executeScript(" $('#recAccountOpenBank').click();");//进行点击
            sleep(3000);
            while (true) {
                count--;
                driver.executeScript("$('#queryBank').val('" + (BANK_MAPPING.get(bankName) != null ? BANK_MAPPING.get(bankName) : bankName) + "')");//输入信息
                sleep(1000);
                String check = driver.executeScript(" return 1+$('#queryBank').val()").toString();
                if (check.length() > 2 || count == 0) {
                    logger.info(" bank had set count=" + count);
                    break;
                }
            }
            driver.executeScript("$('#query').click()");//查询
            sleep(700);
            String s = driver.executeScript("return $('#reList').find('li').html()").toString(); //选择第一个
            s = s.substring(s.indexOf("javascript:") + 11, s.indexOf(");") + 2); // 获取其中js 代码
            driver.executeScript(s);
        }
        //set bank end
        imagePath = "\\" + this.code + "\\" + id + "_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_check_value2_.png";
        PcUtils.saveScreen(driver, imagePath);
        //下一步
        driver.executeScript("$('#nextBut').click()");
        setMessage("please enter code and not click 确认");

        // some time here have a div

        // driver.executeScript("setInterval(function(){if($('#zhezhaoDiv').length==1){$('#zhezhaoDiv').remove();}},3000)");
        pageJS("setInterval(function(){ $('#zhezhaoDiv').remove();},3000)");

        Object[] options = {"Yes,是的", "No,取消¦"};
        int sel = JOptionPane.showOptionDialog(null, " finish code ?", "询问 ", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, null);
        if (sel != JOptionPane.YES_OPTION) {
            return null;
        }
        logger.info("start auto click 确认 ");
        setMessage("start auto click 确认 ");
        driver.executeScript("$(\"button[data-toggle='submit']\").click()");
        // 等待驅動密碼框
        sleep(3500);

        PcUtils.captureScreen(this.code, "page_driver_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        getPgaeBox(BankEnum.PSBC,0.7);
        PcUtils.clickScreen(boxPoint.passwordX,boxPoint.passwordY);
        pressText(usbPassword);
        logger.info("end enter usbPasswrd");
        press(new String[]{"Enter"}, 200, 200);
        sleep(5000);
        // 循环等待人点击U盾
        //呼叫: 开启 声音提示
        PcUtils.sound();

        WebDriverWait wait = new WebDriverWait(driver, 2);
        int waitCount = 20;  // 3 -->7  通讯错误那么多 我怎么不相信
        while (waitCount > 0) {
            try {
                waitCount --;
                sleep(1000);
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("showFee"))); // 3s let inner for spend sort time
                logger.info("get showFee 本行代码已经执行,获取到成功标识");
                imagePath = "\\" + this.code + "\\" + id + "_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_check_page_.png";
                PcUtils.saveScreen(driver, imagePath);
                break;
            } catch (NullPointerException e) {

            } catch (TimeoutException e) {
                logger.info("wait element timeout exception:" + e.getMessage());
                break;
            } catch (Exception e) {
                logger.info("wait exception:" + e.getMessage());
            } catch (Throwable e){
                logger.info("wait Throwable:" + e.getMessage());
            }

        }

        PcUtils.captureScreen(this.code, "page_PSBC_showINFO_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        waitPageElement("showFee",15);
        charge = driver.executeScript("return $('#showFee').text()+' '  ").toString();
        logger.info("charge = " + charge);
        if (charge.length() > 3 && charge.length() < 7) { // 排除 selenium 返回的 [] 和 奇怪的随机值
            logger.info("charge = " + charge.split("元")[0]);
            taskLog.setCharge(charge.split("元")[0]);
        }
        logger.info("old balance=" + balance);
        BigDecimal clacBalance = balance.subtract(amount);
        if (checkTransfer(amount)) { // 这里的代码不能外面抛出错误  //会导致下面没有图
            taskLog.setStatus(TaskLog.SUCCESS);
            logger.info("new balance=" + balance);
            BigDecimal realCharge = clacBalance.subtract(balance);
            logger.info("realCharge=" + realCharge);
            if(realCharge.signum()>-1 && realCharge.subtract(new BigDecimal("10.00")).signum() == -1 ){
                taskLog.setCharge(realCharge.toString());
            }
            setMessage("check charge =" + taskLog.getCharge());
            imagePath = "\\" + this.code + "\\" + id + "_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_success_.png";
            PcUtils.saveScreen(driver, imagePath);
            taskLog.setStatus(TaskLog.SUCCESS);
            taskLog.setImg(imagePath);
        } else {
            logger.info("fail balance =" + balance);
            imagePath = "\\" + this.code + "\\" + id + "_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_usbPassword_error_.png";
            taskLog.setStatus(TaskLog.FAIL);
            taskLog.setImg(imagePath);

            //呼叫: 开启 声音提示
            PcUtils.sound();

            PcUtils.captureScreen(this.code, id + "_" + DATE_TIME_FORMATTER2.format(taskLog.getTime()) + "_usbPassword_error_.png");
            throw new BankException("usbPassword_error", taskLog);
        }

        return taskLog;
    }

    @Override
    public void queryTransaction() throws Exception {
        driver.switchTo().window(windowHandle);
    }


    private void setAutoFlush() {
        String js = " localStorage.setItem('run','true'); ";
        js += "setInterval(function(){";
        js += " if(localStorage.getItem('run') == 'true'){";
        js += " $('#firsrMenu').children('li:eq(2)').click();";
        js += " }";
        js += "},60000)";
        driver.executeScript(js);
    }

}
 