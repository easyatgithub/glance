package com.wlft.payment.swing2;

import static com.wlft.payment.common.FormatUtils.AMOUNT_FORMATTER;

import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class TaskDetailPanel extends JPanel {


	//	serialVersionUID
	private static final long serialVersionUID = -853426398180754684L;
	
	private JLabel requestTimeLabel = new JLabel();
	
	private JLabel priLabel = new JLabel();
	
	private JLabel amountLabel = new JLabel();
	
	private JLabel pendingLabel = new JLabel();
	
	private JLabel accountLabel = new JLabel();
	
	public TaskDetailPanel() {
    	JPanel subPanel = null;
    	FlowLayout flowLayout = new FlowLayout(FlowLayout.LEFT, 5, 5);

		//	設定布局
		setLayout(new GridLayout(2, 3, 5, 5));
		//	設定邊框
		setBorder(BorderFactory.createEtchedBorder());
		
		//	Request Time
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Request Time: "));
		subPanel.add(requestTimeLabel);
		add(subPanel);
		
		//	Pri
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Pri: "));
		subPanel.add(priLabel);
		add(subPanel);
		
		//	Amount
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Amount: "));
		subPanel.add(amountLabel);
		add(subPanel);
		
		//	Pending
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Pending: "));
		subPanel.add(pendingLabel);
		add(subPanel);
		
		//	Account
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Account: "));
		subPanel.add(accountLabel);
		add(subPanel);
	}
}
