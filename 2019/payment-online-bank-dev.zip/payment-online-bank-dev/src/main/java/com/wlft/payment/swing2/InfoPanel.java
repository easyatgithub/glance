package com.wlft.payment.swing2;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.math.BigDecimal;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import static com.wlft.payment.common.FormatUtils.*;

public class InfoPanel extends JPanel {

	//	serialVersionUID
	private static final long serialVersionUID = -853426398180754684L;
	
	private JLabel usernameLabel;
	
	private JLabel accountCodeLabel;
	
	private JLabel boBalanceLabel;
	
	private JLabel bankBalanceLabel;
	
	public InfoPanel(String username, String accountCode, BigDecimal boBalance, BigDecimal bankBalance) {
    	JPanel subPanel = null;
    	JButton changeBankButton = null;
    	JButton syncBankBalanceButton = null;
    	FlowLayout flowLayout = new FlowLayout(FlowLayout.LEFT, 5, 5);

		//	設定布局
		setLayout(new GridLayout(2, 2, 5, 5));
		//	設定邊框
		setBorder(BorderFactory.createEtchedBorder());
		
		//	username
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Username: "));
		subPanel.add(usernameLabel = new JLabel());
		add(subPanel);
		
		//	bo balance
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("BO Balance: "));
		subPanel.add(boBalanceLabel = new JLabel());
		add(subPanel);
		
		//	account code
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Account Code: "));
		subPanel.add(accountCodeLabel = new JLabel());
		changeBankButton = new JButton("Change");
		changeBankButton.setEnabled(false);
		changeBankButton.setPreferredSize(new Dimension(80,20));
		subPanel.add(changeBankButton);
		add(subPanel);
		
		//	bank balance
		subPanel = new JPanel();
		subPanel.setLayout(flowLayout);
		subPanel.add(new JLabel("Bank Balance: "));
		subPanel.add(bankBalanceLabel = new JLabel());
		syncBankBalanceButton = new JButton("Sync");
		syncBankBalanceButton.setEnabled(false);
		syncBankBalanceButton.setPreferredSize(new Dimension(80,20));
		subPanel.add(syncBankBalanceButton);
		add(subPanel);
		
		this.setUsername(username);
		this.setAccountCode(accountCode);
		this.setBoBalance(boBalance);
		this.setBankBalance(bankBalance);
	}
	
	public void setUsername(String username) {
		this.usernameLabel.setText(username);
	}
	
	public void setAccountCode(String accountCode) {
		this.accountCodeLabel.setText(accountCode != null ? accountCode + "  " : "  ");
	}
	
	public void setBoBalance(BigDecimal boBalance) {
		this.boBalanceLabel.setText(boBalance != null ? AMOUNT_FORMATTER.format(boBalance) : "");
	}
	
	public void setBankBalance(BigDecimal bankBalance) {
		this.bankBalanceLabel.setText(bankBalance != null ? AMOUNT_FORMATTER.format(bankBalance) + "  " : "  ");
	}
}
