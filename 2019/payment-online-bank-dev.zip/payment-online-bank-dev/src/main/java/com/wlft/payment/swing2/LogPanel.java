package com.wlft.payment.swing2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import org.apache.log4j.Logger;

import com.wlft.payment.swing.PaymentFrame;

public class LogPanel extends JPanel {

	//	serialVersionUID
	private static final long serialVersionUID = -3574559439578329383L;
	//	log
	private final Logger logger = Logger.getLogger(PaymentFrame.class);
	//	console log
    private final Logger consoleLogger = Logger.getLogger(getClass().getName() + ".log");
    //  file的日誌
    public static final String INFO = "info";
    //  file的錯誤日誌
    public static final String ERROR = "error";

	private JTextPane consolePane = new JTextPane();
	
	public LogPanel() {
    	JScrollPane scrollPane;
    	JButton button;
    	
    	setPreferredSize(new Dimension(PaymentFrame2.WIDTH, 120));
		setBorder(BorderFactory.createEtchedBorder());
        setLayout(new BorderLayout());
        
        //	Clean button
		button = new JButton("Clean");
		button.setBounds(PaymentFrame2.WIDTH - 80 - 3, 3, 80, 17);
		button.setPreferredSize(new Dimension(80,15));
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				consolePane.setText("");
			}
			
		});
		add(button);

        //  consolePane
        consolePane.setEditable(false);
        scrollPane = new JScrollPane(this.consolePane, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
        //	tabbedPane
        JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.add("Log", scrollPane);
		tabbedPane.setPreferredSize(new Dimension(PaymentFrame2.WIDTH, 130));
		add(tabbedPane);
	}

    /**
     *  顯示錯誤訊息
     * @param message - 訊息
     */
    public void setErrorMessage(String message){
        this.setMessage(ERROR, message, Color.RED, null);
    }


    /**
     *  顯示錯誤訊息
     * @param message - 訊息
     */
    public void setErrorMessage(String message, Throwable throwable){
        this.setMessage(ERROR, message, Color.RED, throwable);
    }

    /**
     * 顯示訊息
     * @param message - 訊息
     */
    public void setMessage(String message){
        this.setMessage(INFO, message, Color.BLACK, null);
    }

    /**
     * 顯示訊息
     * @param message - 訊息
     */
	public void setMessage(String level, String message, Color color, Throwable throwable){
        StyledDocument doc = this.consolePane.getStyledDocument();
        Style style = this.consolePane.addStyle("Color Style", null);
        StyleConstants.setForeground(style,color);
        try {
            doc.insertString(doc.getLength(), message + "\n", style);
            if(this.isVisible()) {
            	this.consolePane.setCaretPosition(doc.getLength());
            }
            if(level.equals(INFO)){
            	consoleLogger.info(message);
            }else if(level.equals(ERROR) && throwable != null){
            	consoleLogger.error(message);
            }else{
            	consoleLogger.error(message);
            }
        }catch (BadLocationException e) {
        	logger.error(e);
        }
    }
}
