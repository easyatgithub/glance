package com.wlft.payment.bank;

import java.util.Map;
import java.util.Date;
import java.util.HashMap;
import java.math.BigDecimal;

import com.wlft.payment.common.PressThread;
import org.openqa.selenium.*;
import org.openqa.selenium.By;
import org.apache.log4j.Logger;
import org.openqa.selenium.TimeoutException;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.wlft.payment.common.PcUtils;
import com.wlft.payment.common.TaskLog;
import com.wlft.payment.exception.BankException;

import static java.lang.Thread.sleep;
import static com.github.supermoonie.winio.VirtualKeyBoard.press;
import static com.wlft.payment.common.FormatUtils.DATE_TIME_FORMATTER2;

public class ABCOnlineBank extends OnlineBank {

    private static Logger logger = Logger.getLogger(ABCOnlineBank.class);
    private static final Map<String, String> BANK_MAPPING = new HashMap<String, String>();

    static {
        BANK_MAPPING.put("工商银行", "中国工商银行");
        BANK_MAPPING.put("上海浦东发展银行", "浦东发展银行");
        BANK_MAPPING.put("邮政储蓄", "中国邮政储蓄银行");
    }

    public ABCOnlineBank(Integer id, String accountCode, String hostname, Integer port) {
        super("ABC", id, accountCode, hostname, port);
    }

    @Override
    public void login(String username, String password, String queryPassword, String usbPassword) throws Exception {
        //  設定登錄帳號、密碼、交易密碼、U盾密碼
        this.setLoginInfo(username, password, queryPassword, usbPassword);
        //  初始化訊息框
        initMessageBox();
        // 有usbPassword，但是沒有U盾時
        if (StringUtils.isNotEmpty(usbPassword) && !checkKbao()) {
            this.close();
            throw new BankException("Please insert USB device");
        }
        //  1.有U盾則使用U盾登入
        //  2.沒有U盾則使用帳密登入
        if (StringUtils.isNotEmpty(usbPassword)) {
            loginByKbao();
        } else {
            loginByPassword();
        }

        //  初始化訊息框
        initMessageBox();

        //   clear Introduce
        driver.executeScript(" $('.intro-close').click(); ");
    }

    private void loginByPassword() throws Exception {

        setMessage("Type username");
        driver.executeScript(" $('[name=\"username\"]').focus()");
        press(this.username.trim().split(""), 1000, 200);

        setMessage("Type password");
        press(new String[]{"Tab"}, 1000, 200);
        press(password.trim().split(""), 1000, 200);

        setMessage("Type Captcha");
        press(new String[]{"Tab"}, 1000, 200);
        press("capc".trim().split(""), 1000, 200);

        setMessage("Click  登录");
        // driver.executeScript(" $('input.m-uersbtn').click()");
        sleep(3000);

        waiting();

        //  Check
        if (driver.getCurrentUrl().indexOf("login.do") == -1) {
            Object msg = "";

            msg = driver.executeScript("return $('#username-error').text();");
            if (StringUtils.isNotEmpty(msg.toString())) {
                throw new BankException(msg.toString());
            }

            msg = driver.executeScript("return $('#powerpass_ie_dyn_Msg').text();");
            if (StringUtils.isNotEmpty(msg.toString())) {
                throw new BankException(msg.toString());
            }

            msg = driver.executeScript(" return $('.logon-error').text();");
            if (StringUtils.isNotEmpty(msg.toString())) {
                throw new BankException(msg.toString());
            }

            throw new BankException("Unknown error");
        }
    }

    private void loginByKbao() throws Exception {
        int count = 60;
        logger.info("Open K宝登录");
        setMessage("Open K宝登录");
        driver.executeScript("$('.m-login-kbaoLink').trigger('click');");

        setMessage("Type password");
        driver.executeScript(" $('#m-kbbtn').click()");

        sleep(500);
        pressText(usbPassword);
        // 输入完密码后的全屏截图
        PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        sleep(1700);
        setMessage("Click  登录");
        driver.executeScript(" $('#m-kbbtn').click()");
        // 某些驅動 需要輸入一次UKey 密碼
        sleep(5000);
        pressText(usbPassword);
        press(new String[]{"Enter"}, 1000, 200);

        // 等待進入首頁
        waitPageElement("menuNav",20);

        //  Check
        if (!driver.getCurrentUrl().contains("login.do")) {
            Object msg = "";

            msg = driver.executeScript(" return $('#PowerEnterDiv_powerpass_2_Msg').text();");

            PcUtils.saveScreen(driver, "\\" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + "_fail_.png");

            if (StringUtils.isNotEmpty(msg.toString())) {
                throw new BankException(msg.toString());
            }

            msg = driver.executeScript(" return $('.logon-error').text();");
            if (StringUtils.isNotEmpty(msg.toString())) {
                throw new BankException(msg.toString());
            }

            throw new BankException("Unknown error");
        }
    }

    @Override
    public void logout() throws Exception {
        driver.executeScript(" $('#logout_a').click()");
        driver.switchTo().alert().accept();
        this.close();
    }

    @Override
    public void checkBalance(BigDecimal balance) throws Exception {
        //  跳回最外層，以保證之後的操作是正確的
        driver.switchTo().window(windowHandle);
        setMessage("Fetch balance");
        // 设置页面定时刷新 函数
        setAutoFlush();
        String bal = driver.switchTo().frame(0).findElement(By.id("dnormal")).getText();

        if (StringUtils.isEmpty(bal)) {
            setMessage("Not fetch Balance");
            this.balance = balance;
            return;
        }
        bal = bal.replaceAll(",", "");
        this.balance = new BigDecimal(bal);

        if (this.balance.compareTo(balance) != 0) {
            setMessage("Balance:" + bal + ". <span style=\"color:red;\">Different with payment 1.0. Please check</span>");
        } else {
            setMessage("Balance:" + bal);
        }
        logger.info("get banlance=" + bal);
    }

    @Override
    public BigDecimal getPageBalance() throws Exception {

        setMessage("Fetch balance");
        driver.switchTo().window(windowHandle);
        driver.executeScript("$('#menuNav').find('ul').children('li:eq(3)>ul:eq(0)>li:eq(0)').click();");
        driver.switchTo().frame("contentFrame");

        waiting();
        waitPageElement("fromAcctBalance",15);
        String bal = driver.findElement(By.id("fromAcctBalance")).getText();
        bal = bal.replaceAll(",", "");
        logger.info("getPageBalance() check bal =" + bal);
        // 设置页面定时刷新
        driver.switchTo().window(windowHandle);
        driver.executeScript("localStorage.setItem('run','true')");
        if (bal.length() > 0) {
            balance = new BigDecimal(bal);
            System.out.println(" balance= " + balance);
            return balance;
        } else {
            return this.getBalance();
        }
    }

    // 同金額同賬戶轉賬需要自動點擊確定按鈕
    void clearVerifyPopup() {

        String idName = "popupbox-confirm-sure-0";
        By id = By.id(idName);
        try {
            new WebDriverWait(driver, 3).until(ExpectedConditions.visibilityOfElementLocated(id));
            driver.executeScript(String.format("$('#%s').focus()", idName));
            press(new String[]{"Enter"}, 100, 60);
            driver.findElement(id).click();
        } catch (ScriptTimeoutException e) {
            logger.info("wait ScriptTimeoutException ");
        } catch (TimeoutException e) {
            logger.info("wait verify popup timeout ");
        } catch (NoSuchElementException e) {
            logger.info("wait verify popup NoSuchElementException");
        } catch (Exception e) {

        }
    }

    @Override
    public TaskLog transfer(BigDecimal id, String bankName, String accountNumber, String accountName, BigDecimal amount, String memberBankProvince, String memberBankCity, String memberBankBranch) throws Exception {

        TaskLog taskLog = new TaskLog(id, this.accountCode, new Date(), amount);
        String imagePath = "";
        String amountStr = amount.toString();
        //  初始化pending
        initPending();
        setMessage("Start transaction");
        //  跳轉至轉帳頁面
        driver.executeScript("localStorage.setItem('run','not')");
        driver.executeScript("$('#menuNav').find('ul').children('li:eq(3)>ul:eq(0)>li:eq(0)').click();");
        driver.switchTo().frame("contentFrame");
        waiting();


        //  加入遮照
        setMessage("Mask fields");
        driver.switchTo().frame("contentFrame");
        driver.executeScript("$('.right').css('position','relative');");
        driver.executeScript("$('.selectric-trn_fromAcctNo').after('<div class=\"payment-masker\" style=\"position:absolute; left:65px; top:14px; width:200px; height:32px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#toAcctNameKey').after('<div class=\"payment-masker\" style=\"position:absolute; left:30px;  width:100px !important; height:32px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        driver.executeScript("$('#toAcctNo').after('<div class=\"payment-masker\" style=\"position:absolute; left:50px; width:235px; height:32px; display: inline-block; z-index: 100; background:#000; color:#FFF; padding:5px; line-height:22px; cursor:pointer;\">Click to remove masker</div>');");
        //  加入移除遮照的事件
        driver.executeScript("$('.payment-masker').on('click', function(){var ans = prompt('Please enter password', ''); if(ans == 5201314){$('.payment-masker').remove();}})");

        //  設定轉帳參數
        setMessage("Set transaction fields");
        driver.switchTo().frame("contentFrame");

        //  收款方
        String js = "$('#toAcctNameKey').val('" + accountName + "')";
        String checkJs =      "return $('#toAcctNameKey').val()";
        tryToPutValue(js,checkJs,accountName);
        // 收款銀行
        String bank = (BANK_MAPPING.get(bankName) != null ? BANK_MAPPING.get(bankName) : bankName);
        js = "$('#bankKey').val('" + bank + "')";
        checkJs =      "return $('#bankKey').val()";
        tryToPutValue(js,checkJs,bank);
        //账户号
        js = "$('#toAcctNo').val('" + accountNumber + "').click()";
        checkJs =      "return $('#toAcctNo').val()";
        tryToPutValue(js,checkJs,accountNumber);

        logger.info("end put value");
        driver.executeScript("$('#transAmt').trigger('click').click()");
        driver.executeScript("$('#transAmt').focus()");
        driver.executeScript("$('#transAmt').val('" + amountStr + "').blur()" ); //页面元素没有提示失去焦点会触发大写的函数


        sleep(700);
        driver.executeScript("$('#toAcctNameKey').trigger('click').click()");
        driver.executeScript("$('#fromAcctBalance').after(\"<input  id='payment_input' style='width:10px'/>\")"); // 添加一個 小input
        sleep(500);
        driver.executeScript("$('#transAmt').blur();$('#payment_input').focus()");


        logger.info("=============================>>>>record get back of page value");
        logger.info(driver.executeScript( "return $('#toAcctNameKey').val()"));
        logger.info(driver.executeScript( "return $('#bankKey').val()"));
        logger.info(driver.executeScript( "return $('#toAcctNo').val()"));
        logger.info(driver.executeScript( "return $('#transAmt').val()"));
        logger.info(driver.executeScript( "return $('#bigTransAmt').html()"));

        driver.executeScript("$('#transAmt').val('" + amountStr + "').blur()"); //页面元素没有提示失去焦点会触发大写的函数
        sleep(700);
        click(100, 100);  // 只有触发 金额的大写 才能进入下一步 少数未触发情况下才会进入下一步
        driver.executeScript("$('#transAmt').blur();$('#payment_input').focus()");
        setMessage("Click 下一步");
        click(100, 100);
        driver.switchTo().frame("contentFrame");
        driver.executeScript("$('#transferNext').click()");

        logger.info("点击下一步后进入等待:");
        waiting();
        // 等待页面密码框div 出现
        waitPageElement("PowerEnterDiv",15);



        //取得 费用 charge
        String charge = driver.executeScript("return $('.trn_confirmBalance:eq(1)').html()+' ' ").toString().trim();
        charge = charge.substring(0, charge.indexOf(".") + 3);
        logger.info("//取得 费用 charge" + charge);
        setMessage("//取得 费用 charge" + charge);
        taskLog.setCharge(charge);

        // 添加一个小input
        driver.switchTo().window(windowHandle);
        driver.executeScript("localStorage.setItem('run','not')");
        driver.executeScript("$('body').contents().find(\"#contentFrame\").contents().find(\"#popupButton\").after(\"<input  id='payment_point' style='width:10px'/>\")");
        sleep(900);
        driver.executeScript("$('body').contents().find(\"#contentFrame\").contents().find(\"#payment_point\").focus()");
        // driver.switchTo().frame("contentFrame");
        press(new String[]{"Tab"}, 1000, 200);// tab 键盘 進入密碼框
        sleep(1000);
        pressText(queryPassword);
        PcUtils.captureScreen(this.code, "password_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        press(new String[]{"Tab"}, 1000, 200);
        press(new String[]{"Enter"}, 1000, 200);

        this.clearVerifyPopup();
        // 等待驅動 密碼框 box 並輸入密碼
        sleep(7000);
        PcUtils.captureScreen(this.code, "page_driver_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        pressText(usbPassword);
        sleep(2700); // leave time to cancle
        press(new String[]{"Enter"}, 200, 50);
        logger.info("输入完毕USB密码");

        PcUtils.sound();

        // 循环等待 操作人员按下
        boolean ok = false;
        String tag = "";
        int waitTime = 20;
        while (true) {
            try {
                sleep(1000);
                waitTime--;
                if (waitTime == 0) break;
                driver.switchTo().window(windowHandle);
                driver.switchTo().frame("contentFrame");
                tag = driver.findElement(By.className("m-serialnumberleft")).getText();
                if (tag.length() > 0) {
                    ok = true;
                    break;
                }
            } catch (Throwable x) {
                logger.info("ABC wait success catch Throwable");
            }
        }

        PcUtils.captureScreen(this.code, "page_" + id + "_" + DATE_TIME_FORMATTER2.format(System.currentTimeMillis()) + ".png");
        if (tag.length() > 0) {
            ok = true;
        }

        if (driver.executeScript("return $('#trnTips').text()+ ' '").toString().length() > 2) {
            ok = true;
            logger.info("获取到标志物 trnTips");
        }
        logger.info("get flag 获取到标志物 ok=" + ok );
        taskLog = checkTransfer(amount,taskLog,"10.00");
        return handleCheck(taskLog.getStatus().equals(TaskLog.SUCCESS) ||  ok,id,taskLog) ;

    }

    @Override
    public void queryTransaction() throws Exception {

        //  跳回最外層，以保證之後的操作是正確的
        driver.switchTo().window(windowHandle);
    }

    private boolean checkKbao() {
        return driver.findElement(By.id("cspName")).getText().equals("K宝已插入");
    }


    private void setAutoFlush() {
        String js = " localStorage.setItem('run','true'); ";
        js += " setInterval(function(){ ";
        js += " if(localStorage.getItem('run') == 'true'){ ";
        js += " $('#menuNav').find('ul').children('li:eq(3)>ul:eq(0)>li:eq(0)').click(); ";
        js += " } ";
        js += " },60000) ";
        driver.executeScript(js);
    }
}
