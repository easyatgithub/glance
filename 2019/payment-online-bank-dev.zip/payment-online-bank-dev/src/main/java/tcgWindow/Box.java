package tcgWindow;

import java.awt.Rectangle;
import org.apache.log4j.Logger;
import com.wlft.payment.common.PcUtils;
import tcg.windowDetecter.contracts.BankEnum;
import tcg.windowDetecter.models.BankWindowResult;
import tcg.windowDetecter.visual.BankDetecter;

public class Box {

    private static final Logger logger = Logger.getLogger(Box.class);

    public void printRect(String name, Rectangle rect) {
        System.out.println("Target: " + name + "\t point=(" + rect.x + "," + rect.y + ")");
    }

    public BoxPoint getPoints(BankEnum bankSlug, double deg) {
        BankDetecter bankDetecter = new BankDetecter();
        BankWindowResult bwr = bankDetecter.findWindow(bankSlug, PcUtils.getScreenBufferedImage(), deg);

        if (!bwr.found) {
            logger.info("Window was not being found,please check bank type");
            return new BoxPoint();
        }

        int boxX = bwr.getFrameRect().x;
        int boxY = bwr.getFrameRect().y;
        return new BoxPoint(boxX, boxY,
                boxX + bwr.getPasswordTextboxRect().x + 15,
                boxY + bwr.getPasswordTextboxRect().y + 15,
                boxX + bwr.getConfirmButtonRect().x + 5,
                boxY + bwr.getConfirmButtonRect().y + 5);
    }

}

 