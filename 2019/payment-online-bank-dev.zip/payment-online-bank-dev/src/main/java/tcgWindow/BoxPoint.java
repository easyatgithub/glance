package tcgWindow;

public class BoxPoint {
    public int boxX = 0;
    public int boxY = 0;
    public int passwordX = 0;
    public int passwordY = 0;
    public int buttonX = 0;
    public int buttonY = 0;

    public BoxPoint() {

    }

    public BoxPoint(int boxX, int boxY, int passwordX, int passwordY, int buttonX, int buttonY) {
        this.boxX = boxX;
        this.boxY = boxY;
        this.passwordX = passwordX;
        this.passwordY = passwordY;
        this.buttonX = buttonX;
        this.buttonY = buttonY;
    }
}
