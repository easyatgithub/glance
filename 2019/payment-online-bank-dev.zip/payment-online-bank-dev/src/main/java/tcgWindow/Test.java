package tcgWindow;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import javax.imageio.ImageIO;
import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;
import org.opencv.imgcodecs.Imgcodecs;
import tcg.windowDetecter.contracts.BankEnum;
import tcg.windowDetecter.models.BankWindowResult;
import tcg.windowDetecter.visual.BankDetecter;

public class Test {
    public static void main(String[] args) throws Exception {
        Robot robot = new Robot();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle screenRectangle = new Rectangle(screenSize);
        BufferedImage image = robot.createScreenCapture(screenRectangle);
        BoxPoint point = getPoints(image, BankEnum.CCB, 0.7);
        System.out.println(point.boxX);
        System.out.println(point.boxY);
        robot.mouseMove(point.buttonX, point.buttonY);
        robot.mousePress(InputEvent.BUTTON1_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_MASK);
    }

    private static void printRect(String name, Rectangle rect) {
        System.out.println("Target: " + name + "\t point=(" + rect.x + "," + rect.y + ")");
    }


    private static BoxPoint getPoints(BufferedImage image, BankEnum bankSlug, double deg) {
        BankDetecter bankDetecter = new BankDetecter();
        BankWindowResult bwr = bankDetecter.findWindow(bankSlug, image, deg);

        if (!bwr.found) {
            System.out.println("Window was not being found,please check bank type");
            return new BoxPoint();
        }

        System.out.println("Window is detected.");
        printRect("MAIN", bwr.getFrameRect());
        printRect("BUTTON", bwr.getConfirmButtonRect());
        printRect("INPUT", bwr.getPasswordTextboxRect());
        int boxX = bwr.getFrameRect().x;
        int boxY = bwr.getFrameRect().y;
        return new BoxPoint(boxX, boxY,
                boxX + bwr.getPasswordTextboxRect().x + 15,
                boxY + bwr.getPasswordTextboxRect().y + 7,
                boxX + bwr.getConfirmButtonRect().x + 15,
                boxY + bwr.getConfirmButtonRect().y + 7);
    }


    private static BufferedImage getImage(String path) {

        File img = new File(path);
        try {
            return ImageIO.read(img);
        } catch (Exception ex) {

        }
        return null;
    }


    private static BufferedImage ConvertMat2Image(Mat imgContainer) {
        MatOfByte byteMatData = new MatOfByte();
        //image formatting
        Imgcodecs.imencode(".jpg", imgContainer, byteMatData);
        // Convert to array
        byte[] byteArray = byteMatData.toArray();
        BufferedImage img = null;
        try {
            InputStream in = new ByteArrayInputStream(byteArray);
            //load image
            img = ImageIO.read(in);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return img;
    }

}

 