package tcgWindow;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import tcg.windowDetecter.contracts.BankEnum;
import tcg.windowDetecter.models.BankWindowResult;
import tcg.windowDetecter.visual.BankDetecter;

public class App {
    public static void main(String[] args) throws IOException {
        test("C:\\tmp\\test\\ccb.png", BankEnum.CCB, 0.8);
    }

    private static void printRect(String name, Rectangle rect) {
        System.out.println("Target: " + name + "\t point=(" + rect.x + "," + rect.y + ")");
    }


    private static void test(String testImagePath, BankEnum bankSlug, double deg) {


        BankDetecter bankDetecter = new BankDetecter();
        BankWindowResult bwr = bankDetecter.findWindow(bankSlug, getImage(testImagePath), deg);

        if (!bwr.found) {
            System.out.println("Window was not being found,please check bank type");
        }

        System.out.println("Window is detected.");
        printRect("MAIN", bwr.getFrameRect());
        printRect("BUTTON", bwr.getConfirmButtonRect());
        printRect("INPUT", bwr.getPasswordTextboxRect());


    }


    private static BufferedImage getImage(String path) {

        File img = new File(path);

        try {
            return ImageIO.read(img);
        } catch (Exception ex) {

        }
        return null;
    }


}
