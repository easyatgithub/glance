### FILE
<pre>
payment-online-bank                
├─.idea 
│  ├─artifacts
│  └─libraries
├─.settings
├─classes                              build 产生的jar 文件
│  └─artifacts
│      └─payment_online_bank_jar
├─src
│  └─main
│      ├─java
│      │  ├─com
│      │  │  └─wlft
│      │  │      └─payment           
│      │  │          ├─bank             各类银行  
│      │  │          ├─common           公用方法
│      │  │          ├─exception        自定义异常  
│      │  │          └─swing            界面绘制
│      │  └─META-INF
│      └─resources                      配置档相关
├─target                               
│  ├─classes                            
│  │  ├─com
│  │  │  └─wlft
│  │  │      └─payment
│  │  │          ├─bank
│  │  │          ├─common
│  │  │          ├─exception
│  │  │          └─swing
│  │  └─META-INF
│  ├─generated-sources
│  │  └─annotations
│  └─test-classes
└─WinIo                

</pre>
### bank
<pre>
ABC      U盾
ICBC     U盾
PSBC     U盾+短信    操作员输入验证码


</pre>
### 环境与打包的说明
windos with PS/2
1. winio4J https://github.com/supermoonie/winio4J
2. opencv  https://opencv.org/releases/
将 path\to\opencv\build\java\x64\opencv_java410.dll 复制到 系统盘( eg:C:\Windows)
3. 目前采用的打包是 IDEA Build 出jar文档  再由 jsmooth.exe 打包  exe 